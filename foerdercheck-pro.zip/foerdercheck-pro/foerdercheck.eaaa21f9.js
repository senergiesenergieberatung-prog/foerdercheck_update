(function(){

const ENDPOINT = (window.SFC_CFG||{}).endpoint || null;
const $ = id => document.getElementById(id);
const eur = n => Math.round(n).toLocaleString("de-DE") + " €";

// Stichtage der Reform vom 21.07.2026: Klimageschwindigkeitsbonus und Kostengrenze der 1. Wohneinheit
function stufe(d){
  const t = d.toISOString().slice(0,10);
  const s = [["2027-02-01",16,28000],["2027-08-01",12,27250],["2028-02-01",8,26500],["2028-08-01",4,25750]];
  for (const [bis,kb,cap] of s) if (t < bis) return {kb,cap};
  const halbj = Math.floor((d.getFullYear()-2028)*2 + (d.getMonth()>=7?1:0)); // ab 08/2028 weitere Absenkung
  return {kb:0,cap:Math.max(22000,25750-750*Math.max(0,halbj))};
}

function calc(){
  const we = Math.max(1, parseInt($("we").value)||1);
  const selbst = $("nutzung").value === "selbst";
  const neu = document.querySelector('input[name=neu]:checked').value;
  const alt = $("alt").value, funkt = $("funkt").checked;
  const kHeiz = Math.max(0, +$("kHeiz").value||0), kHuelle = $("keineHuelle").checked ? 0 : Math.max(0, +$("kHuelle").value||0);
  const isfpWahl = $("isfp").value, isfp = isfpWahl !== "nein";
  const begleitJa = $("begleit").value === "ja", kBegleit = begleitJa ? Math.max(0, +$("kBegleit").value||0) : 0;
  // Kinder unter 18 mindern das zvE einmalig um 10.000 €, also eine Stufe tiefer
  const z0 = +$("zve").value;
  const zve = $("kinder").value==="1" ? {30:30,40:30,50:40,60:50,99:99}[z0] : (z0===60 ? 99 : z0);
  const {kb,cap} = stufe(new Date());

  $("heizRow").style.display = $("funktRow").style.display = neu==="keine" ? "none" : "";
  $("einkFs").style.display = selbst ? "" : "none";
  $("huelleRow").style.display = $("begleitRow").style.display = $("keineHuelle").checked ? "none" : "";
  $("kBegleitRow").style.display = begleitJa ? "" : "none";

  const lines = [], tips = [];
  let total = 0;

  // KfW 458 Heizung
  if (neu !== "keine" && kHeiz > 0){
    const capAll = cap + Math.min(we-1,5)*15000 + Math.max(0,we-6)*8000;
    const foerderf = Math.min(kHeiz, capAll);
    {
      const klimaOk = selbst && funkt && ["oel","gas20","etage","nacht","kohle","bio20"].includes(alt);
      const eink = selbst ? ({30:40,40:30,50:10,99:0}[zve]) : 0;
      const deckel = selbst && zve===30 ? 80 : 70;
      const satzEigen = Math.min(deckel, 30 + (klimaOk?kb:0) + eink);
      // Klima- und Einkommensbonus nur für die selbst genutzte Wohneinheit: ihr Anteil = förderfähige Kosten / Wohneinheiten
      const anteil = (f, w) => selbst ? f / w : 0;
      const eigen = anteil(foerderf, we), rest = foerderf - eigen;
      const z = eigen*satzEigen/100 + rest*0.30;
      // dieselbe Rechnung mit Kostengrenze und Klimabonus der nächsten Stufe
      const zNach = (capN, kbN) => { const fN = Math.min(kHeiz, capN + capAll - cap), eN = anteil(fN, we);
        return eN*Math.min(deckel, 30 + (klimaOk?kbN:0) + eink)/100 + (fN-eN)*0.30; };
      total += z;
      const teile = ["30 % Grundförderung"]; if (klimaOk && kb) teile.push(kb+" % Klimabonus"); if (eink) teile.push(eink+" % Einkommensbonus");
      const boni = teile.slice(1).join(" + ") + (satzEigen<30+(klimaOk?kb:0)+eink ? `, gedeckelt auf ${deckel} % gesamt` : "");
      lines.push(["Heizungsförderung (KfW 458)", z, !eigen ? `30 % Grundförderung auf ${eur(foerderf)} förderfähige Kosten.`
        : !rest ? `${satzEigen} % auf ${eur(eigen)} förderfähige Kosten (${teile.join(", ")}${boni.includes("gedeckelt")?", gedeckelt":""}).`
        : `30 % Grundförderung auf ${eur(foerderf)} förderfähige Kosten, plus ${satzEigen-30} % Bonus (${boni}) auf ${eur(eigen)}: Das ist der Anteil der selbst genutzten Wohnung (förderfähige Kosten geteilt durch ${we} Wohneinheiten).`]);
      if (kHeiz > capAll) tips.push(`<b>Kostengrenze:</b> Von ${eur(kHeiz)} sind nur ${eur(capAll)} förderfähig. Der Rest ist Eigenanteil, den die KfW per Ergänzungskredit finanzieren kann.`);
      if (selbst && !klimaOk && kb && (alt==="gasjung" || alt==="biojung")) tips.push(`<b>Kein Klimabonus:</b> ${alt==="gasjung"?"Gasheizungen":"Biomasseheizungen"} bekommen ihn erst ab 20 Jahren Betriebszeit. Prüfen Sie das Datum der Inbetriebnahme.`);
      if (alt==="wp") tips.push(`<b>Wärmepumpe ersetzt Wärmepumpe:</b> Das wird derzeit noch gefördert, aber ohne Klimabonus. Ab dem ersten Quartal 2027 entfällt die Förderung, wenn die alte Anlage seit 2008 läuft. Bei älteren Anlagen sind dann nur noch 25 % der Kosten förderfähig. Beantragen Sie also möglichst noch 2026.`);
      if (/^bio/.test(alt)) tips.push(`<b>Alte Biomasseheizung: jetzt beantragen.</b> Ab dem ersten Quartal 2027 gibt es keine Förderung mehr, wenn die alte Anlage seit 2008 läuft. Das gilt auch, wenn die neue Heizung eine Wärmepumpe ist. Bei älteren Anlagen sind dann nur noch 25 % der Kosten förderfähig. Stellen Sie den Antrag deshalb möglichst noch 2026.`);
      if (klimaOk && kb===16) tips.push(`<b>Jetzt beantragen lohnt sich:</b> Ab dem 1. Februar 2027 sinkt der Klimabonus auf 12 % und die Kostengrenze auf 27.250 €. Das kostet Sie rund ${eur(z - zNach(27250, 12))}.`);
      if (neu==="wp") tips.push(`<b>Achtung 2027:</b> Ab dem ersten Quartal 2027 sinkt die Grundförderung für Wärmepumpen, die nicht in der EU hergestellt werden, auf 15 %. Für Geräte aus der EU bleibt es bei 30 %. Das ist in der Richtlinie beschlossen, ein genaues Datum steht noch aus. Fragen Sie Ihren Installateur nach dem Herstellungsort.`);
      if (we > 1) tips.push(`<b>Hinweis:</b> Die Kostengrenze für die Heizung gilt für das ganze Gebäude, nicht für jede Wohnung einzeln.`);
      // Partnerlink nur beim Heizungstausch (BEG Nr. 9.3: keine Vermittlung bei Vorhaben mit geförderter Baubegleitung)
      const partner = (window.SFC_CFG||{}).partner;
      if (partner) tips.push(`<span class="h">Anzeige</span><br><b>Angebote vergleichen:</b> Holen Sie kostenlos bis zu drei Angebote von Heizungsfachbetrieben in Ihrer Region ein. <a href="${partner}" target="_blank" rel="sponsored noopener">Jetzt Angebote anfordern</a>`);
    }
  }

  // BAFA BEG EM Gebäudehülle
  if (kHuelle > 0){
    const base = isfp ? 60000 : 30000;
    const capH = base + Math.min(we-1,5)*(isfp?30000:15000) + Math.max(0,we-6)*(isfp?15000:8000);
    const ohneCap = 30000 + Math.min(we-1,5)*15000 + Math.max(0,we-6)*8000;
    const f = Math.min(kHuelle, capH);
    const z = f*0.15 + (isfp ? Math.max(0, f-ohneCap)*0.05 : 0);
    total += z;
    lines.push(["Gebäudehülle (BAFA)", z, `15 % auf ${eur(f)}${isfp && f>ohneCap?`, plus 5 % iSFP-Bonus auf ${eur(f-ohneCap)}`:""}.`]);
    if (kHuelle > capH) tips.push(`<b>Kostengrenze:</b> Für Maßnahmen an der Gebäudehülle sind ${eur(capH)} je Gebäude und Kalenderjahr förderfähig. Größere Vorhaben lassen sich auf zwei Jahre verteilen.`);
    const steuer = Math.min(kHuelle,200000)*0.20;
    if (selbst && steuer > z) tips.push(`<b>Steuerbonus prüfen:</b> Über § 35c EStG wären es bis zu ${eur(Math.min(steuer,40000))} über drei Jahre, also ${eur(Math.min(steuer,40000)-z)} mehr als die BAFA. Gilt nur für selbst genutzte Häuser über zehn Jahre.`);
    if (!isfp && kHuelle > 30000) tips.push(`<b>Sanierungsfahrplan lohnt sich:</b> Mit iSFP wären bis zu ${eur(Math.min(kHuelle,60000))} förderfähig statt 30.000 €. Die Beratung wird zu 50 % gefördert.`);
    if (!begleitJa) tips.push(`<b>Energieeffizienz-Experte nötig:</b> Für Maßnahmen an der Gebäudehülle muss ein gelisteter Experte die technische Projektbeschreibung erstellen, bevor Sie den Antrag stellen. Seine Fachplanung und Baubegleitung wird zu 50 % gefördert.`);
    // Fachplanung und Baubegleitung: 50 % auf max. 5.000 € (bis 2 WE), darüber 2.000 € je WE, höchstens 20.000 €
    if (kBegleit > 0){
      const capB = we <= 2 ? 5000 : Math.min(2000*we, 20000), fB = Math.min(kBegleit, capB), zB = fB*0.5;
      total += zB;
      lines.push(["Fachplanung und Baubegleitung (BAFA)", zB, `50 % auf ${eur(fB)}${kBegleit>capB?` (von ${eur(kBegleit)} sind höchstens ${eur(capB)} förderfähig)`:""}.`]);
    }
  }

  // Zuschuss für die iSFP-Erstellung nur, wenn der Fahrplan noch erstellt wird
  if (isfpWahl === "geplant"){
    const ebw = we<=2 ? 650 : 850;
    lines.push(["Zuschuss iSFP-Erstellung (BAFA)", ebw, `50 % des Beraterhonorars, höchstens ${eur(ebw)}.`]);
    total += ebw;
  }
  if (["G","H"].includes($("klasse").value) && kHuelle>0) tips.push(`<b>Klasse ${$("klasse").value}:</b> Für Häuser mit sehr hohem Verbrauch gibt es ab dem ersten Quartal 2027 einen Zusatzbonus von 5 % für Dämmung (Worst-Performing-Building). Voraussetzung ist ein iSFP. Der Bonus gilt für höchstens drei Anträge.`);

  $("sum").textContent = eur(total);
  const ges = (neu!=="keine"?kHeiz:0) + kHuelle + (kHuelle>0?kBegleit:0);
  $("sumSub").textContent = ges ? `bei ${eur(ges)} Gesamtkosten, das sind ${Math.round(total/ges*100)} %` : "Geben Sie Ihre geplanten Kosten ein.";
  $("lines").innerHTML = lines.length ? lines.map(([t,v,d])=>`<div class="line"><b>${t}</b><span class="v">${eur(v)}</span><span class="d">${d}</span></div>`).join("") : `<div class="line"><span class="d">Wählen Sie eine Maßnahme aus.</span></div>`;
  $("tips").innerHTML = tips.map(t=>`<p class="tip">${t}</p>`).join("");
  return {total,lines,ges};
}

// Vorbelegung aus dem Hinweis-Streifen (?massnahme=heizung&kosten=30000)
const q = new URLSearchParams(location.search), qk = parseInt(q.get("kosten"), 10);
if (qk >= 0 && ["heizung","daemmung","fenster"].includes(q.get("massnahme"))) {
  $(q.get("massnahme")==="heizung" ? "kHeiz" : "kHuelle").value = qk;
  $(q.get("massnahme")==="heizung" ? "kHuelle" : "kHeiz").value = 0;
  document.querySelector(`input[name=huelle][value=${q.get("massnahme")==="heizung" ? "keine" : "ja"}]`).checked = true;
}

$("calc").addEventListener("input", calc);
$("toLead").addEventListener("click", ()=> $("lead").scrollIntoView({behavior:"smooth"}));

// Ergebnis mit Logo des Beraters drucken bzw. als PDF speichern
const esc = s => String(s).replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"})[c]);
$("toPdf").addEventListener("click", ()=>{
  const cfg = window.SFC_CFG || {}, r = calc();
  const daten = [...$("calc").querySelectorAll("select, input[type=number], input[type=checkbox], input[type=radio]:checked")]
    .filter(el => el.offsetParent !== null && el.closest("label")).map(el => {
      const lab = el.closest("label"), name = (lab.childNodes[0].textContent || lab.textContent).trim();
      if (el.type === "checkbox") return [lab.textContent.trim(), el.checked ? "ja" : "nein"];
      if (el.type === "radio") return [el.closest("fieldset")?.querySelector("legend")?.textContent.trim() || "Auswahl", lab.textContent.trim()];
      if (el.tagName === "SELECT") return [name, el.selectedOptions[0]?.text || ""];
      return [name, /€/.test(name) ? eur(+el.value || 0) : el.value];
    });
  let box = document.getElementById("sfcReport");
  if (!box){ box = document.createElement("div"); box.id = "sfcReport"; document.body.appendChild(box); }
  box.innerHTML = `<div class="rp-head">${cfg.logo ? `<img src="${esc(cfg.logo)}" alt="">` : `<b>${esc(cfg.firma||"")}</b>`}<span>${new Date().toLocaleDateString("de-DE")}</span></div>
    <h1>Ihre Förder-Ersteinschätzung</h1>
    <p class="rp-lbl">Möglicher Zuschuss</p><p class="rp-sum">${eur(r.total)}</p>
    <table>${r.lines.map(([t,v,d])=>`<tr><td><b>${esc(t)}</b><br><small>${esc(d)}</small></td><td>${eur(v)}</td></tr>`).join("")}<tr><td>Kosten gesamt</td><td>${eur(r.ges)}</td></tr></table>
    <h2>Ihre Angaben</h2><table>${daten.map(([k,v])=>`<tr><td>${esc(k)}</td><td>${esc(v)}</td></tr>`).join("")}</table>
    ${$("tips").innerHTML ? `<h2>Hinweise</h2><div class="rp-tips">${$("tips").innerHTML}</div>` : ""}
    <p class="rp-small">Alle Angaben ohne Gewähr. Das Ergebnis ist eine Schätzung auf Basis der veröffentlichten Förderbedingungen (KfW 458, BAFA BEG EM, Stand 21.07.2026) und ersetzt keine Beratung. Verbindlich sind allein die Merkblätter von KfW und BAFA.</p>
    <p class="rp-foot">${esc(cfg.firma||"")}${cfg.kontakt ? " · " + esc(cfg.kontakt) : ""}</p>`;
  document.documentElement.classList.add("sfc-printing");
  const done = ()=>{ document.documentElement.classList.remove("sfc-printing"); window.removeEventListener("afterprint", done); };
  window.addEventListener("afterprint", done);
  const imgs = [...box.querySelectorAll("img")].filter(i=>!i.complete);
  Promise.all(imgs.map(i=>new Promise(ok=>{i.onload=i.onerror=ok}))).then(()=>window.print());
});

$("leadForm").addEventListener("submit", async e=>{
  e.preventDefault();
  const err = $("leadErr"); err.hidden = true;
  const name=$("lName").value.trim(), mail=$("lMail").value.trim(), plz=$("lPlz").value.trim();
  if (!name || !/^\S+@\S+\.\S+$/.test(mail) || !/^\d{5}$/.test(plz) || !$("lOk").checked){
    err.textContent = "Bitte Name, gültige E-Mail, fünfstellige PLZ und die Einwilligung angeben."; err.hidden = false; return;
  }
  const r = calc();
  const data = {name,mail,tel:$("lTel").value.trim(),plz,wunsch:$("lWunsch").value,
    zuschuss:Math.round(r.total),kosten:r.ges,details:r.lines.map(l=>l[0]+": "+Math.round(l[1])+" €").join("; "),
    we:$("we").value,nutzung:$("nutzung").value,klasse:$("klasse").value,alt:$("alt").value,
    neu:document.querySelector('input[name=neu]:checked').value,isfp:$("isfp").value!=="nein", website:""};
  if (!ENDPOINT){
    $("leadForm").hidden = true; $("leadOk").hidden = false;
    $("leadOk").textContent = "Vorschau: In der Live-Version geht diese Anfrage jetzt per E-Mail an die Energieberatung."; return;
  }
  $("lSend").disabled = true;
  try{
    const res = await fetch(ENDPOINT,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)});
    if(!res.ok) throw 0;
    $("leadForm").hidden = true; $("leadOk").hidden = false;
    const j = await res.json().catch(()=>({}));
    if (j.gebiet==="aussen"){ // Einzugsgebiet (Pro 1.8.4): Hinweis auf die Expertenliste und eigene Angebote statt Anfrage
      const box = $("leadOk"), neu = (tag, txt) => { const e = document.createElement(tag); if (txt) e.textContent = txt; return e; };
      const link = (u, t) => { const a = neu("a", t); a.href = u; a.target = "_blank"; a.rel = "noopener"; return a; };
      box.textContent = ""; const p1 = neu("span", (j.hinweis || "Ihr Haus liegt außerhalb unseres Einzugsgebiets. Eine Energieberatung in Ihrer Nähe finden Sie hier:") + " ");
      p1.append(link("https://www.energie-effizienz-experten.de/", "Energieeffizienz-Expertenliste")); box.append(p1);
      if (j.text){ box.append(neu("br"), neu("br"), neu("span", j.text)); }
      if ((j.links||[]).length){ const d = neu("span"); d.className = "ez-links"; j.links.forEach(([t,u]) => d.append(link(u, t))); box.append(d); }
      return;
    }
    $("leadOk").textContent = `Danke, ${name}. Ihre Anfrage ist angekommen. Wir melden uns in Kürze bei ${mail}.`;
  }catch{
    err.textContent = "Die Anfrage konnte nicht gesendet werden. Bitte versuchen Sie es in ein paar Minuten noch einmal."; err.hidden = false; $("lSend").disabled = false;
  }
});
calc();

})();