(function(){

const ENDPOINT = (window.SFC_CFG||{}).endpoint || null;
const $ = id => document.getElementById(id);
const eur = n => Math.round(n).toLocaleString("de-DE") + " €";

// Stichtage der Reform vom 21.07.2026: Klimageschwindigkeitsbonus und Kostengrenze der 1. Wohneinheit
function stufe(d){
  const t = d.toISOString().slice(0,10);
  const s = [["2027-02-01",16,28000],["2027-08-01",12,27250],["2028-02-01",8,26500],["2028-08-01",4,25750]];
  for (const [bis,kb,cap] of s) if (t < bis) return {kb,cap};
  const halbj = Math.floor((d.getFullYear()-2028)*2 + (d.getMonth()>=7?1:0)); // ab 08/2028 weitere Absenkung
  return {kb:0,cap:Math.max(22000,25750-750*Math.max(0,halbj))};
}

function calc(){
  const we = Math.max(1, parseInt($("we").value)||1);
  const selbst = $("nutzung").value === "selbst";
  const neu = document.querySelector('input[name=neu]:checked').value;
  const alt = $("alt").value, funkt = $("funkt").checked;
  const kHeiz = Math.max(0, +$("kHeiz").value||0), kHuelle = Math.max(0, +$("kHuelle").value||0);
  const isfp = $("isfp").checked;
  // Kinder unter 18 mindern das zvE einmalig um 10.000 €, also eine Stufe tiefer
  const z0 = +$("zve").value;
  const zve = $("kinder").value==="1" ? {30:30,40:30,50:40,60:50,99:99}[z0] : (z0===60 ? 99 : z0);
  const {kb,cap} = stufe(new Date());

  $("heizRow").style.display = $("funktRow").style.display = neu==="keine" ? "none" : "";
  $("einkFs").style.display = selbst ? "" : "none";

  const lines = [], tips = [];
  let total = 0;

  // KfW 458 Heizung
  if (neu !== "keine" && kHeiz > 0){
    const capAll = cap + Math.min(we-1,5)*15000 + Math.max(0,we-6)*8000;
    const foerderf = Math.min(kHeiz, capAll);
    if (alt === "wp"){
      lines.push(["Heizungsförderung (KfW 458)",0,"Der Tausch einer bestehenden Wärmepumpe wird nicht mehr gefördert."]);
    } else {
      const klimaOk = selbst && funkt && ["oel","gas20","etage","nacht","kohle"].includes(alt);
      const eink = selbst ? ({30:40,40:30,50:10,99:0}[zve]) : 0;
      const deckel = selbst && zve===30 ? 80 : 70;
      const satzEigen = Math.min(deckel, 30 + (klimaOk?kb:0) + eink);
      // Boni nur für die selbst genutzte Wohneinheit (die erste)
      const eigen = Math.min(foerderf, cap), rest = foerderf - eigen;
      const z = eigen*satzEigen/100 + rest*0.30;
      total += z;
      const teile = ["30 % Grundförderung"]; if (klimaOk && kb) teile.push(kb+" % Klimabonus"); if (eink) teile.push(eink+" % Einkommensbonus");
      lines.push(["Heizungsförderung (KfW 458)", z, `${satzEigen} % auf ${eur(eigen)} förderfähige Kosten (${teile.join(", ")}${satzEigen<30+(klimaOk?kb:0)+eink?", gedeckelt":""})${rest?`, plus 30 % auf ${eur(rest)} für weitere Wohneinheiten`:""}.`]);
      if (kHeiz > capAll) tips.push(`<b>Kostengrenze:</b> Von ${eur(kHeiz)} sind nur ${eur(capAll)} förderfähig. Der Rest ist Eigenanteil, den die KfW per Ergänzungskredit finanzieren kann.`);
      if (selbst && !klimaOk && kb && (alt==="gasjung")) tips.push(`<b>Kein Klimabonus:</b> Gasheizungen bekommen ihn erst ab 20 Jahren Betriebszeit. Prüfen Sie das Datum der Inbetriebnahme.`);
      if (klimaOk && kb===16) tips.push(`<b>Jetzt beantragen lohnt sich:</b> Ab dem 1. Februar 2027 sinkt der Klimabonus auf 12 % und die Kostengrenze auf 27.250 €. Das kostet Sie rund ${eur(Math.min(kHeiz,28000)*0.04 + Math.max(0,Math.min(kHeiz,28000)-27250)*satzEigen/100)}.`);
      if (neu==="wp") tips.push(`<b>Achtung 2027:</b> Für Wärmepumpen ist eine Absenkung der Grundförderung auf 15 % plus 15 % Bonus für Geräte aus der EU angekündigt, aber noch nicht bestätigt.`);
    }
  }

  // BAFA BEG EM Gebäudehülle
  if (kHuelle > 0){
    const base = isfp ? 60000 : 30000;
    const capH = base + Math.min(we-1,5)*(isfp?30000:15000) + Math.max(0,we-6)*(isfp?15000:8000);
    const ohneCap = 30000 + Math.min(we-1,5)*15000 + Math.max(0,we-6)*8000;
    const f = Math.min(kHuelle, capH);
    const z = f*0.15 + (isfp ? Math.max(0, f-ohneCap)*0.05 : 0);
    total += z;
    lines.push(["Dämmung und Fenster (BAFA)", z, `15 % auf ${eur(f)}${isfp && f>ohneCap?`, plus 5 % iSFP-Bonus auf ${eur(f-ohneCap)}`:""}.`]);
    const steuer = Math.min(kHuelle,200000)*0.20;
    if (selbst && steuer > z) tips.push(`<b>Steuerbonus prüfen:</b> Über § 35c EStG wären es bis zu ${eur(Math.min(steuer,40000))} über drei Jahre, also ${eur(Math.min(steuer,40000)-z)} mehr als die BAFA. Gilt nur für selbst genutzte Häuser über zehn Jahre.`);
    if (!isfp && kHuelle > 30000) tips.push(`<b>Sanierungsfahrplan lohnt sich:</b> Mit iSFP wären bis zu ${eur(Math.min(kHuelle,60000))} förderfähig statt 30.000 €. Die Beratung wird zu 50 % gefördert.`);
    if (!isfp) tips.push(`<b>Energieeffizienz-Experte nötig:</b> Für Dämmung und Fenster muss ein gelisteter Experte die technische Projektbeschreibung erstellen, bevor Sie den Antrag stellen.`);
  }

  if (isfp){
    const ebw = we<=2 ? 650 : 850;
    lines.push(["Zuschuss Energieberatung (BAFA)", ebw, `50 % des Beraterhonorars, höchstens ${eur(ebw)}.`]);
    total += ebw;
  }
  if (["G","H"].includes($("klasse").value) && kHuelle>0) tips.push(`<b>Klasse ${$("klasse").value}:</b> Für Häuser mit sehr hohem Verbrauch ist ab 2027 ein Zusatzbonus von 5 % für Dämmung geplant. Voraussetzung ist eine geförderte Energieberatung.`);

  $("sum").textContent = eur(total);
  const ges = (neu!=="keine"?kHeiz:0) + kHuelle;
  $("sumSub").textContent = ges ? `bei ${eur(ges)} Gesamtkosten, das sind ${Math.round(total/ges*100)} %` : "Geben Sie Ihre geplanten Kosten ein.";
  $("lines").innerHTML = lines.length ? lines.map(([t,v,d])=>`<div class="line"><b>${t}</b><span class="v">${eur(v)}</span><span class="d">${d}</span></div>`).join("") : `<div class="line"><span class="d">Wählen Sie eine Maßnahme aus.</span></div>`;
  $("tips").innerHTML = tips.map(t=>`<p class="tip">${t}</p>`).join("");
  return {total,lines,ges};
}

// Vorbelegung aus dem Hinweis-Streifen (?massnahme=heizung&kosten=30000)
const q = new URLSearchParams(location.search), qk = parseInt(q.get("kosten"), 10);
if (qk >= 0 && ["heizung","daemmung","fenster"].includes(q.get("massnahme"))) {
  $(q.get("massnahme")==="heizung" ? "kHeiz" : "kHuelle").value = qk;
  $(q.get("massnahme")==="heizung" ? "kHuelle" : "kHeiz").value = 0;
}

$("calc").addEventListener("input", calc);
$("toLead").addEventListener("click", ()=> $("lead").scrollIntoView({behavior:"smooth"}));

// Ergebnis mit Logo des Beraters drucken bzw. als PDF speichern
const esc = s => String(s).replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"})[c]);
$("toPdf").addEventListener("click", ()=>{
  const cfg = window.SFC_CFG || {}, r = calc();
  const daten = [...$("calc").querySelectorAll("select, input[type=number], input[type=checkbox], input[type=radio]:checked")]
    .filter(el => el.offsetParent !== null && el.closest("label")).map(el => {
      const lab = el.closest("label"), name = (lab.childNodes[0].textContent || lab.textContent).trim();
      if (el.type === "checkbox") return [lab.textContent.trim(), el.checked ? "ja" : "nein"];
      if (el.type === "radio") return [el.closest("fieldset")?.querySelector("legend")?.textContent.trim() || "Auswahl", lab.textContent.trim()];
      if (el.tagName === "SELECT") return [name, el.selectedOptions[0]?.text || ""];
      return [name, /€/.test(name) ? eur(+el.value || 0) : el.value];
    });
  let box = document.getElementById("sfcReport");
  if (!box){ box = document.createElement("div"); box.id = "sfcReport"; document.body.appendChild(box); }
  box.innerHTML = `<div class="rp-head">${cfg.logo ? `<img src="${esc(cfg.logo)}" alt="">` : `<b>${esc(cfg.firma||"")}</b>`}<span>${new Date().toLocaleDateString("de-DE")}</span></div>
    <h1>Ihre Förder-Ersteinschätzung</h1>
    <p class="rp-lbl">Möglicher Zuschuss</p><p class="rp-sum">${eur(r.total)}</p>
    <table>${r.lines.map(([t,v,d])=>`<tr><td><b>${esc(t)}</b><br><small>${esc(d)}</small></td><td>${eur(v)}</td></tr>`).join("")}<tr><td>Kosten gesamt</td><td>${eur(r.ges)}</td></tr></table>
    <h2>Ihre Angaben</h2><table>${daten.map(([k,v])=>`<tr><td>${esc(k)}</td><td>${esc(v)}</td></tr>`).join("")}</table>
    ${$("tips").innerHTML ? `<h2>Hinweise</h2><div class="rp-tips">${$("tips").innerHTML}</div>` : ""}
    <p class="rp-small">Alle Angaben ohne Gewähr. Das Ergebnis ist eine Schätzung auf Basis der veröffentlichten Förderbedingungen (KfW 458, BAFA BEG EM, Stand 21.07.2026) und ersetzt keine Beratung. Verbindlich sind allein die Merkblätter von KfW und BAFA.</p>
    <p class="rp-foot">${esc(cfg.firma||"")}${cfg.kontakt ? " · " + esc(cfg.kontakt) : ""}</p>`;
  document.documentElement.classList.add("sfc-printing");
  const done = ()=>{ document.documentElement.classList.remove("sfc-printing"); window.removeEventListener("afterprint", done); };
  window.addEventListener("afterprint", done);
  const imgs = [...box.querySelectorAll("img")].filter(i=>!i.complete);
  Promise.all(imgs.map(i=>new Promise(ok=>{i.onload=i.onerror=ok}))).then(()=>window.print());
});

$("leadForm").addEventListener("submit", async e=>{
  e.preventDefault();
  const err = $("leadErr"); err.hidden = true;
  const name=$("lName").value.trim(), mail=$("lMail").value.trim(), plz=$("lPlz").value.trim();
  if (!name || !/^\S+@\S+\.\S+$/.test(mail) || !/^\d{5}$/.test(plz) || !$("lOk").checked){
    err.textContent = "Bitte Name, gültige E-Mail, fünfstellige PLZ und die Einwilligung angeben."; err.hidden = false; return;
  }
  const r = calc();
  const data = {name,mail,tel:$("lTel").value.trim(),plz,wunsch:$("lWunsch").value,
    zuschuss:Math.round(r.total),kosten:r.ges,details:r.lines.map(l=>l[0]+": "+Math.round(l[1])+" €").join("; "),
    we:$("we").value,nutzung:$("nutzung").value,klasse:$("klasse").value,alt:$("alt").value,
    neu:document.querySelector('input[name=neu]:checked').value,isfp:$("isfp").checked, website:""};
  if (!ENDPOINT){
    $("leadForm").hidden = true; $("leadOk").hidden = false;
    $("leadOk").textContent = "Vorschau: In der Live-Version geht diese Anfrage jetzt per E-Mail an die Energieberatung."; return;
  }
  $("lSend").disabled = true;
  try{
    const res = await fetch(ENDPOINT,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)});
    if(!res.ok) throw 0;
    $("leadForm").hidden = true; $("leadOk").hidden = false;
    $("leadOk").textContent = `Danke, ${name}. Ihre Anfrage ist angekommen. Wir melden uns in Kürze bei ${mail}.`;
  }catch{
    err.textContent = "Die Anfrage konnte nicht gesendet werden. Bitte versuchen Sie es in ein paar Minuten noch einmal."; err.hidden = false; $("lSend").disabled = false;
  }
});
calc();

})();