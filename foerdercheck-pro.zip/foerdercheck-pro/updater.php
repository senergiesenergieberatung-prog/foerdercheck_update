<?php
// Update-Prüfung: liest eine JSON-Datei (version, download_url, changelog) und meldet neue Versionen an WordPress.
// Der Server fragt nur diese Datei ab, Besucherdaten werden nicht übertragen.
if (!defined('ABSPATH')) exit;
if (!function_exists('sfc_updater')) {
  function sfc_updater($file, $json_url) {
    $basename = plugin_basename($file);
    $slug = dirname($basename);
    $key = 'sfc_upd_' . md5($json_url);
    $info = function () use ($json_url, $key) {
      $d = get_transient($key);
      if ($d === false) {
        $r = wp_remote_get($json_url, ['timeout' => 10]);
        $d = (!is_wp_error($r) && wp_remote_retrieve_response_code($r) === 200) ? json_decode(wp_remote_retrieve_body($r), true) : null;
        set_transient($key, is_array($d) ? $d : [], 6 * HOUR_IN_SECONDS);
      }
      return is_array($d) && !empty($d['version']) && !empty($d['download_url']) ? $d : null;
    };

    add_filter('pre_set_site_transient_update_plugins', function ($t) use ($info, $basename, $slug, $file) {
      if (!is_object($t) || empty($t->checked)) return $t;
      $d = $info();
      if (!$d) return $t;
      $cur = get_file_data($file, ['Version' => 'Version'])['Version'];
      $item = (object) ['id' => $basename, 'slug' => $slug, 'plugin' => $basename, 'new_version' => $d['version'],
        'package' => $d['download_url'], 'url' => $d['homepage'] ?? '', 'requires_php' => $d['requires_php'] ?? '7.4', 'tested' => $d['tested'] ?? ''];
      if (version_compare($d['version'], $cur, '>')) $t->response[$basename] = $item;
      else $t->no_update[$basename] = $item;
      return $t;
    });

    // Text für „Details ansehen“ im Update-Hinweis
    add_filter('plugins_api', function ($res, $action, $args) use ($info, $slug) {
      if ($action !== 'plugin_information' || ($args->slug ?? '') !== $slug) return $res;
      $d = $info();
      if (!$d) return $res;
      return (object) ['name' => $d['name'] ?? $slug, 'slug' => $slug, 'version' => $d['version'], 'download_link' => $d['download_url'],
        'requires_php' => $d['requires_php'] ?? '7.4', 'tested' => $d['tested'] ?? '', 'sections' => ['changelog' => $d['changelog'] ?? '']];
    }, 10, 3);

    add_action('upgrader_process_complete', function () use ($key) { delete_transient($key); });
  }
}
