<?php
/**
 * Plugin Name: Fördercheck Pro
 * Description: Förderrechner für Heizung, Dämmung und Fenster (BEG ab 21.07.2026) mit Anfrageformular für Energieberater. Einbinden mit dem Shortcode [foerdercheck]. Einstellungen unter Einstellungen → Fördercheck.
 * Plugin URI: https://s-energies.de/foerdercheck-fuer-energieberater/
 * Version: 1.5.2
 * Author: s-energies.de
 * Requires PHP: 7.4
 */
if (!defined('ABSPATH')) exit;

require_once __DIR__ . '/updater.php';
sfc_updater(__FILE__, 'https://raw.githubusercontent.com/senergiesenergieberatung-prog/foerdercheck_update/main/foerdercheck-pro.json');

// Logo aus den Einstellungen, sonst das Logo des Themes
function sfc_logo() {
  if (sfc_opt('logo_url')) return sfc_opt('logo_url');
  $id = get_theme_mod('custom_logo');
  return $id ? (string) wp_get_attachment_image_url($id, 'medium') : '';
}

function sfc_opt($k) {
  $o = get_option('sfc_settings', []);
  $d = ['empfaenger' => get_option('admin_email'), 'farbe' => '#0f6b55', 'firma' => get_bloginfo('name'), 'antwortzeit' => 'zwei Werktagen',
    'rechner_url' => home_url('/foerdercheck/'), 'streifen_titel' => 'Wie viel Zuschuss bekommen Sie für Heizung, Dämmung und Fenster?',
    'streifen_text' => 'Klimabonus sinkt ab 1. Februar 2027. In 2 Minuten wissen Sie, was Ihnen zusteht.', 'streifen_farbe' => '#f3d97a', 'streifen_rechner' => 1,
    'logo_url' => '', 'kontakt' => '', 'kopie_kunde' => 1];
  return $o[$k] ?? $d[$k];
}

add_action('admin_menu', function () {
  add_options_page('Fördercheck', 'Fördercheck', 'manage_options', 'sfc', function () {
    if (isset($_POST['sfc_save']) && check_admin_referer('sfc_save')) {
      update_option('sfc_settings', [
        'empfaenger' => sanitize_email($_POST['empfaenger'] ?? ''),
        'farbe' => sanitize_hex_color($_POST['farbe'] ?? '') ?: '#0f6b55',
        'firma' => sanitize_text_field($_POST['firma'] ?? ''),
        'antwortzeit' => sanitize_text_field($_POST['antwortzeit'] ?? ''),
        'rechner_url' => esc_url_raw(wp_unslash($_POST['rechner_url'] ?? '')),
        'streifen_titel' => sanitize_text_field(wp_unslash($_POST['streifen_titel'] ?? '')),
        'streifen_text' => sanitize_text_field(wp_unslash($_POST['streifen_text'] ?? '')),
        'streifen_farbe' => sanitize_hex_color($_POST['streifen_farbe'] ?? '') ?: '#f3d97a',
        'streifen_rechner' => empty($_POST['streifen_rechner']) ? 0 : 1,
        'logo_url' => esc_url_raw(wp_unslash($_POST['logo_url'] ?? '')),
        'kontakt' => sanitize_text_field(wp_unslash($_POST['kontakt'] ?? '')),
        'kopie_kunde' => empty($_POST['kopie_kunde']) ? 0 : 1,
      ]);
      echo '<div class="updated"><p>Gespeichert.</p></div>';
    }
    $f = fn($k, $l, $t = 'text') => sprintf('<tr><th><label for="%1$s">%2$s</label></th><td><input type="%3$s" id="%1$s" name="%1$s" value="%4$s" class="regular-text"></td></tr>', $k, $l, $t, esc_attr(sfc_opt($k)));
    echo '<div class="wrap"><h1>Fördercheck</h1><p>Einbinden mit dem Shortcode <code>[foerdercheck]</code> auf einer beliebigen Seite.</p><form method="post">';
    wp_nonce_field('sfc_save');
    echo '<table class="form-table">' . $f('firma', 'Firmenname') . $f('empfaenger', 'Anfragen an (E-Mail)', 'email') . $f('farbe', 'Akzentfarbe', 'color') . $f('antwortzeit', 'Antwort innerhalb von') . '</table>';
    echo '<h2>Ergebnis mit Ihrem Logo</h2><p>Besucher können ihr Ergebnis als PDF speichern. Wer eine Anfrage sendet, bekommt das Ergebnis zusätzlich per E-Mail. Beides trägt Ihr Logo und Ihre Kontaktdaten.</p>';
    echo '<table class="form-table">' . $f('logo_url', 'Logo (Bild-URL)', 'url') . $f('kontakt', 'Kontaktzeile, z. B. Telefon und Website')
      . sprintf('<tr><th>Kopie an Anfragende</th><td><label><input type="checkbox" name="kopie_kunde" value="1"%s> Anfragende erhalten ihr Ergebnis per E-Mail</label></td></tr>', checked(sfc_opt('kopie_kunde'), 1, false)) . '</table>';
    echo '<p class="description">Logo-URL: Medien → Bild anklicken → „URL in Zwischenablage kopieren“. Am besten PNG oder JPG, denn manche E-Mail-Programme zeigen WebP nicht an. Leer gelassen wird das Logo Ihres Themes verwendet.</p>';
    echo '<h2>Hinweis-Streifen für die Startseite</h2><p>Mit dem Shortcode <code>[foerdercheck_streifen]</code> zeigen Sie auf jeder Seite einen Streifen mit Button zum Rechner, z. B. direkt unter dem Kopfbereich Ihrer Startseite (Elementor: Widget „Shortcode“).</p>';
    echo '<table class="form-table">' . $f('rechner_url', 'Seite mit dem Rechner', 'url') . $f('streifen_titel', 'Überschrift') . $f('streifen_text', 'Text') . $f('streifen_farbe', 'Hintergrundfarbe', 'color')
      . sprintf('<tr><th>Schnellrechner</th><td><label><input type="checkbox" name="streifen_rechner" value="1"%s> Im Streifen eine Kurzberechnung anzeigen (Maßnahme und Kosten)</label></td></tr>', checked(sfc_opt('streifen_rechner'), 1, false)) . '</table>';
    echo '<p><button class="button button-primary" name="sfc_save" value="1">Speichern</button></p></form></div>';
  });
});

// Anfragen als eigener Beitragstyp, sichtbar im Admin-Menü
add_action('init', function () {
  register_post_type('sfc_anfrage', [
    'label' => 'Fördercheck-Anfragen',
    'labels' => ['singular_name' => 'Anfrage', 'menu_name' => 'Fördercheck'],
    'public' => false, 'show_ui' => true, 'menu_icon' => 'dashicons-calculator',
    'supports' => ['title', 'editor'], 'capability_type' => 'post',
    'capabilities' => ['create_posts' => 'do_not_allow'], 'map_meta_cap' => true,
  ]);
});

add_shortcode('foerdercheck', function ($atts = []) {
  // ueberschrift="h2", wenn die Seite schon eine H1 hat
  $a = shortcode_atts(['ueberschrift' => 'h1'], $atts);
  $htag = $a['ueberschrift'] === 'h2' ? 'h2' : 'h1';
  $dir = plugin_dir_path(__FILE__); $url = plugin_dir_url(__FILE__);
  wp_enqueue_style('sfc', $url . 'assets.css', [], '1.5.2');
  wp_enqueue_script('sfc', $url . 'foerdercheck.js', [], '1.5.2', true);
  wp_add_inline_style('sfc', '.sfc{--accent:' . sfc_opt('farbe') . '}');
  wp_add_inline_script('sfc', 'window.SFC_CFG=' . wp_json_encode(['endpoint' => rest_url('sfc/v1/anfrage'), 'logo' => sfc_logo(), 'firma' => sfc_opt('firma'), 'kontakt' => sfc_opt('kontakt')]) . ';', 'before');
  $html = file_get_contents($dir . 'markup.html');
  return strtr($html, ['{{DATENSCHUTZ}}' => esc_url(get_privacy_policy_url() ?: home_url('/datenschutz/')), '{{ANTWORTZEIT}}' => esc_html(sfc_opt('antwortzeit')), '{{HTAG}}' => $htag]);
});

// Hinweis-Streifen mit Button zum Rechner, z. B. für die Startseite, optional mit Kurzberechnung
add_shortcode('foerdercheck_streifen', function ($atts = []) {
  $a = shortcode_atts(['titel' => sfc_opt('streifen_titel'), 'text' => sfc_opt('streifen_text'), 'link' => sfc_opt('rechner_url'),
    'button' => 'Förderung berechnen', 'farbe' => sfc_opt('streifen_farbe'), 'rechner' => sfc_opt('streifen_rechner') ? 'ja' : 'nein'], $atts, 'foerdercheck_streifen');
  $bg = sanitize_hex_color($a['farbe']) ?: '#f3d97a';
  $btn = sprintf('<a class="sfc-band-btn" href="%s" style="display:inline-block;background:#222;color:%s;padding:14px 24px;font-weight:600;text-decoration:none;white-space:nowrap">%s</a>', esc_url($a['link']), esc_attr($bg), esc_html($a['button']));
  $rechts = $btn;
  if ($a['rechner'] !== 'nein') {
    $feld = 'height:48px;padding:0 12px;border:1px solid #222;background:#fff;color:#222;font:inherit;border-radius:0;box-sizing:border-box';
    $rechts = '<form class="sfc-band-calc" onsubmit="return false" style="flex:1 1 380px;display:flex;flex-wrap:wrap;gap:10px;align-items:flex-end;margin:0">'
      . '<label style="flex:1 1 170px;font-size:.85rem;color:#333">Maßnahme<select name="m" style="display:block;width:100%;' . $feld . '">'
      . '<option value="heizung">Neue Heizung</option><option value="daemmung">Dämmung</option><option value="fenster">Fenster und Türen</option></select></label>'
      . '<label style="flex:1 1 130px;font-size:.85rem;color:#333">Kosten (€)<input name="k" type="number" min="0" step="1000" value="30000" inputmode="numeric" style="display:block;width:100%;' . $feld . '"></label>'
      . '<p class="sfc-band-out" aria-live="polite" style="flex:1 1 100%;margin:4px 0 0;font-size:1.15rem;color:#222"></p>'
      . str_replace('class="sfc-band-btn"', 'class="sfc-band-btn" data-base="' . esc_url($a['link']) . '"', $btn) . '</form>';
  }
  static $js = false;
  $script = '';
  if ($a['rechner'] !== 'nein' && !$js) {
    $js = true;
    // Grobe Spanne nach BEG ab 21.07.2026: Heizung 30 bis 70 % auf max. 30.000 €, Gebäudehülle 15 % auf 30.000 € bis 20 % auf 60.000 € mit iSFP
    $script = '<script>(function(){var e=function(n){return Math.round(n/50)*50};var f=function(n){return n.toLocaleString("de-DE")+" €"};'
      . 'function r(c){var m=c.elements.m.value,k=Math.max(0,+c.elements.k.value||0),o=c.querySelector(".sfc-band-out"),b=c.querySelector(".sfc-band-btn"),lo,hi,t;'
      . 'if(m==="heizung"){lo=Math.min(k,30000)*.3;hi=Math.min(k,30000)*.7;t="je nach Einkommen und alter Heizung";}'
      . 'else{lo=Math.min(k,30000)*.15;hi=Math.min(k,60000)*.2;t="mit Sanierungsfahrplan mehr";}'
      . 'o.innerHTML=k?"Zuschuss etwa <strong>"+f(e(lo))+" bis "+f(e(hi))+"</strong> ("+t+")":"Kosten eingeben";'
      . 'var u=new URL(b.dataset.base,location.href);u.searchParams.set("massnahme",m);u.searchParams.set("kosten",k);b.href=u.toString();}'
      . 'document.querySelectorAll(".sfc-band-calc").forEach(function(c){c.addEventListener("input",function(){r(c)});r(c);});})();</script>';
  }
  return sprintf('<div class="sfc-band" style="background:%1$s;color:#222;padding:28px 16px"><div style="max-width:1080px;margin:0 auto;display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:16px 32px">'
    . '<div style="flex:1 1 420px"><p style="margin:0;font-size:clamp(1.3rem,2.4vw,1.8rem);line-height:1.25;font-weight:700;color:#222">%2$s</p>%3$s</div>%4$s</div></div>%5$s',
    esc_attr($bg), esc_html($a['titel']), $a['text'] !== '' ? '<p style="margin:6px 0 0;color:#333">' . esc_html($a['text']) . '</p>' : '', $rechts, $script);
});

add_action('rest_api_init', function () {
  register_rest_route('sfc/v1', '/anfrage', ['methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => 'sfc_anfrage']);
});

function sfc_anfrage(WP_REST_Request $r) {
  $d = $r->get_json_params();
  if (!is_array($d) || !empty($d['website'])) return new WP_REST_Response(['ok' => false], 400); // Honeypot
  $c = fn($k, $n = 200) => mb_substr(sanitize_text_field((string)($d[$k] ?? '')), 0, $n);
  $name = $c('name'); $mail = sanitize_email($d['mail'] ?? ''); $plz = $c('plz', 5);
  if ($name === '' || !is_email($mail) || !preg_match('/^\d{5}$/', $plz)) return new WP_REST_Response(['ok' => false], 422);

  // max. 5 Anfragen pro IP und Stunde
  $key = 'sfc_rl_' . md5($_SERVER['REMOTE_ADDR'] ?? '');
  $n = (int) get_transient($key);
  if ($n >= 5) return new WP_REST_Response(['ok' => false], 429);
  set_transient($key, $n + 1, HOUR_IN_SECONDS);

  $felder = ['Name' => $name, 'E-Mail' => $mail, 'Telefon' => $c('tel', 40), 'PLZ' => $plz, 'Anliegen' => $c('wunsch'),
    'Zuschuss (geschätzt)' => $c('zuschuss', 12) . ' €', 'Kosten gesamt' => $c('kosten', 12) . ' €', 'Aufteilung' => $c('details', 600),
    'Wohneinheiten' => $c('we', 4), 'Nutzung' => $c('nutzung', 20), 'Effizienzklasse' => $c('klasse', 3),
    'Heizung alt' => $c('alt', 20), 'Heizung neu' => $c('neu', 20), 'iSFP' => !empty($d['isfp']) ? 'ja' : 'nein'];
  $text = '';
  foreach ($felder as $k => $v) $text .= "$k: $v\n";

  wp_insert_post(['post_type' => 'sfc_anfrage', 'post_status' => 'private',
    'post_title' => "$plz – $name – " . $felder['Zuschuss (geschätzt)'], 'post_content' => nl2br(esc_html($text))]);
  wp_mail(sfc_opt('empfaenger'), "Fördercheck-Anfrage $plz: $name", "Neue Anfrage aus dem Fördercheck\n\n$text", ["Reply-To: $name <$mail>"]);
  if (sfc_opt('kopie_kunde')) sfc_kopie_kunde($name, $mail, $felder);
  return new WP_REST_Response(['ok' => true], 200);
}

// Ergebnis per E-Mail an die anfragende Person, mit Logo und Kontaktdaten des Beraters
function sfc_kopie_kunde($name, $mail, $felder) {
  // 12880 € → 12.880 €
  $e = fn($t) => esc_html(preg_replace_callback('/\d{4,}/', fn($m) => number_format((float) $m[0], 0, ',', '.'), (string) $t));
  $logo = sfc_logo();
  $zeilen = '';
  foreach (array_filter(explode('; ', $felder['Aufteilung'])) as $z) {
    [$t, $v] = array_pad(explode(': ', $z, 2), 2, '');
    $zeilen .= '<tr><td style="padding:6px 0;border-bottom:1px solid #e5e2d6">' . $e($t) . '</td><td style="padding:6px 0;border-bottom:1px solid #e5e2d6;text-align:right;white-space:nowrap">' . $e($v) . '</td></tr>';
  }
  $html = '<div style="font-family:Arial,sans-serif;color:#333;max-width:600px;margin:0 auto">'
    . ($logo ? '<p><img src="' . esc_url($logo) . '" alt="' . esc_attr(sfc_opt('firma')) . '" style="max-height:70px;max-width:240px"></p>' : '<p style="font-size:18px;font-weight:bold">' . $e(sfc_opt('firma')) . '</p>')
    . '<p>Guten Tag ' . $e($name) . ',</p><p>vielen Dank für Ihre Anfrage. Hier ist Ihr Ergebnis aus dem Fördercheck. Wir melden uns innerhalb von ' . $e(sfc_opt('antwortzeit')) . ' bei Ihnen.</p>'
    . '<p style="font-size:14px;margin:20px 0 4px">Ihr möglicher Zuschuss</p><p style="font-size:30px;font-weight:bold;margin:0 0 16px;color:' . esc_attr(sfc_opt('farbe')) . '">' . $e($felder['Zuschuss (geschätzt)']) . '</p>'
    . '<table style="width:100%;border-collapse:collapse;font-size:14px">' . $zeilen . '<tr><td style="padding:6px 0">Kosten gesamt</td><td style="padding:6px 0;text-align:right">' . $e($felder['Kosten gesamt']) . '</td></tr></table>'
    . '<p style="font-size:12px;color:#777;margin-top:20px">Alle Angaben ohne Gewähr. Das Ergebnis ist eine Schätzung auf Basis der veröffentlichten Förderbedingungen und ersetzt keine Beratung. Verbindlich sind allein die Merkblätter von KfW und BAFA.</p>'
    . '<p style="font-size:13px;border-top:1px solid #e5e2d6;padding-top:12px">' . $e(sfc_opt('firma')) . (sfc_opt('kontakt') ? '<br>' . $e(sfc_opt('kontakt')) : '') . '</p></div>';
  wp_mail($mail, 'Ihr Förder-Ergebnis von ' . sfc_opt('firma'), $html, ['Content-Type: text/html; charset=UTF-8', 'Reply-To: ' . sfc_opt('firma') . ' <' . sfc_opt('empfaenger') . '>']);
}

// Autoptimize nicht an das Rechner-Skript lassen: der Minifier entfernt Leerzeichen in den Texten
add_filter('autoptimize_filter_js_exclude', function ($ex) { return $ex . ', foerdercheck.js'; });
add_filter('autoptimize_filter_js_minify_excluded', function ($minify, $url = '') { return strpos((string) $url, 'foerdercheck.js') !== false ? false : $minify; }, 10, 2);
