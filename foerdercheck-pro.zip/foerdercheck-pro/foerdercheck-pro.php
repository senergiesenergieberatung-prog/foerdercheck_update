<?php
/**
 * Plugin Name: Fördercheck Pro
 * Description: Förderrechner für Heizung, Dämmung und Fenster (BEG ab 21.07.2026) mit Anfrageformular für Energieberater. Einbinden mit dem Shortcode [foerdercheck]. Einstellungen unter Einstellungen → Fördercheck.
 * Plugin URI: https://s-energies.de/foerdercheck-fuer-energieberater/
 * Version: 1.1.1
 * Author: s-energies.de
 * Requires PHP: 7.4
 */
if (!defined('ABSPATH')) exit;

require_once __DIR__ . '/updater.php';
sfc_updater(__FILE__, 'https://raw.githubusercontent.com/senergiesenergieberatung-prog/foerdercheck_update/main/foerdercheck-pro.json');

function sfc_opt($k) {
  $o = get_option('sfc_settings', []);
  $d = ['empfaenger' => get_option('admin_email'), 'farbe' => '#0f6b55', 'firma' => get_bloginfo('name'), 'antwortzeit' => 'zwei Werktagen'];
  return $o[$k] ?? $d[$k];
}

add_action('admin_menu', function () {
  add_options_page('Fördercheck', 'Fördercheck', 'manage_options', 'sfc', function () {
    if (isset($_POST['sfc_save']) && check_admin_referer('sfc_save')) {
      update_option('sfc_settings', [
        'empfaenger' => sanitize_email($_POST['empfaenger'] ?? ''),
        'farbe' => sanitize_hex_color($_POST['farbe'] ?? '') ?: '#0f6b55',
        'firma' => sanitize_text_field($_POST['firma'] ?? ''),
        'antwortzeit' => sanitize_text_field($_POST['antwortzeit'] ?? ''),
      ]);
      echo '<div class="updated"><p>Gespeichert.</p></div>';
    }
    $f = fn($k, $l, $t = 'text') => sprintf('<tr><th><label for="%1$s">%2$s</label></th><td><input type="%3$s" id="%1$s" name="%1$s" value="%4$s" class="regular-text"></td></tr>', $k, $l, $t, esc_attr(sfc_opt($k)));
    echo '<div class="wrap"><h1>Fördercheck</h1><p>Einbinden mit dem Shortcode <code>[foerdercheck]</code> auf einer beliebigen Seite.</p><form method="post">';
    wp_nonce_field('sfc_save');
    echo '<table class="form-table">' . $f('firma', 'Firmenname') . $f('empfaenger', 'Anfragen an (E-Mail)', 'email') . $f('farbe', 'Akzentfarbe', 'color') . $f('antwortzeit', 'Antwort innerhalb von') . '</table>';
    echo '<p><button class="button button-primary" name="sfc_save" value="1">Speichern</button></p></form></div>';
  });
});

// Anfragen als eigener Beitragstyp, sichtbar im Admin-Menü
add_action('init', function () {
  register_post_type('sfc_anfrage', [
    'label' => 'Fördercheck-Anfragen',
    'labels' => ['singular_name' => 'Anfrage', 'menu_name' => 'Fördercheck'],
    'public' => false, 'show_ui' => true, 'menu_icon' => 'dashicons-calculator',
    'supports' => ['title', 'editor'], 'capability_type' => 'post',
    'capabilities' => ['create_posts' => 'do_not_allow'], 'map_meta_cap' => true,
  ]);
});

add_shortcode('foerdercheck', function ($atts = []) {
  // ueberschrift="h2", wenn die Seite schon eine H1 hat
  $a = shortcode_atts(['ueberschrift' => 'h1'], $atts);
  $htag = $a['ueberschrift'] === 'h2' ? 'h2' : 'h1';
  $dir = plugin_dir_path(__FILE__); $url = plugin_dir_url(__FILE__);
  wp_enqueue_style('sfc', $url . 'assets.css', [], '1.1.1');
  wp_enqueue_script('sfc', $url . 'foerdercheck.js', [], '1.1.1', true);
  wp_add_inline_style('sfc', '.sfc{--accent:' . sfc_opt('farbe') . '}');
  wp_add_inline_script('sfc', 'window.SFC_CFG=' . wp_json_encode(['endpoint' => rest_url('sfc/v1/anfrage')]) . ';', 'before');
  $html = file_get_contents($dir . 'markup.html');
  return strtr($html, ['{{DATENSCHUTZ}}' => esc_url(get_privacy_policy_url() ?: home_url('/datenschutz/')), '{{ANTWORTZEIT}}' => esc_html(sfc_opt('antwortzeit')), '{{HTAG}}' => $htag]);
});

add_action('rest_api_init', function () {
  register_rest_route('sfc/v1', '/anfrage', ['methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => 'sfc_anfrage']);
});

function sfc_anfrage(WP_REST_Request $r) {
  $d = $r->get_json_params();
  if (!is_array($d) || !empty($d['website'])) return new WP_REST_Response(['ok' => false], 400); // Honeypot
  $c = fn($k, $n = 200) => mb_substr(sanitize_text_field((string)($d[$k] ?? '')), 0, $n);
  $name = $c('name'); $mail = sanitize_email($d['mail'] ?? ''); $plz = $c('plz', 5);
  if ($name === '' || !is_email($mail) || !preg_match('/^\d{5}$/', $plz)) return new WP_REST_Response(['ok' => false], 422);

  // max. 5 Anfragen pro IP und Stunde
  $key = 'sfc_rl_' . md5($_SERVER['REMOTE_ADDR'] ?? '');
  $n = (int) get_transient($key);
  if ($n >= 5) return new WP_REST_Response(['ok' => false], 429);
  set_transient($key, $n + 1, HOUR_IN_SECONDS);

  $felder = ['Name' => $name, 'E-Mail' => $mail, 'Telefon' => $c('tel', 40), 'PLZ' => $plz, 'Anliegen' => $c('wunsch'),
    'Zuschuss (geschätzt)' => $c('zuschuss', 12) . ' €', 'Kosten gesamt' => $c('kosten', 12) . ' €', 'Aufteilung' => $c('details', 600),
    'Wohneinheiten' => $c('we', 4), 'Nutzung' => $c('nutzung', 20), 'Effizienzklasse' => $c('klasse', 3),
    'Heizung alt' => $c('alt', 20), 'Heizung neu' => $c('neu', 20), 'iSFP' => !empty($d['isfp']) ? 'ja' : 'nein'];
  $text = '';
  foreach ($felder as $k => $v) $text .= "$k: $v\n";

  wp_insert_post(['post_type' => 'sfc_anfrage', 'post_status' => 'private',
    'post_title' => "$plz – $name – " . $felder['Zuschuss (geschätzt)'], 'post_content' => nl2br(esc_html($text))]);
  wp_mail(sfc_opt('empfaenger'), "Fördercheck-Anfrage $plz: $name", "Neue Anfrage aus dem Fördercheck\n\n$text", ["Reply-To: $name <$mail>"]);
  return new WP_REST_Response(['ok' => true], 200);
}
