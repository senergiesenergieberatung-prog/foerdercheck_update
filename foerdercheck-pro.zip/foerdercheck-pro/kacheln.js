(function(){
// Kachel-Ansicht des Fördercheck (ab 1.6.0): eine Frage pro Bildschirm, Annahmen statt Eingaben
const root = document.getElementById("sfk"); if (!root) return;
const CFG = window.SFC_CFG || {}, ENDPOINT = CFG.endpoint || null;
const $ = id => document.getElementById("sfk-"+id);
const I = {
  efh:'<svg viewBox="0 0 32 32"><path d="M5 15 16 6l11 9"/><path d="M8 13v13h16V13"/><path d="M14 26v-7h4v7"/></svg>',
  rh:'<svg viewBox="0 0 32 32"><path d="M2 15 9 9l7 6 7-6 7 6"/><path d="M4 14v12h24V14"/><path d="M16 15v11"/></svg>',
  zfh:'<svg viewBox="0 0 32 32"><path d="M5 12 16 5l11 7"/><path d="M8 11v16h16V11"/><path d="M8 19h16"/><path d="M12 14h3M17 14h3M12 23h3M17 23h3"/></svg>',
  mfh:'<svg viewBox="0 0 32 32"><rect x="7" y="4" width="18" height="23"/><path d="M11 9h3M18 9h3M11 14h3M18 14h3M11 19h3M18 19h3M14 27v-4h4v4"/></svg>',
  heiz:'<svg viewBox="0 0 32 32"><path d="M16 4c4 6 8 9 8 15a8 8 0 0 1-16 0c0-4 2-6 4-8 0 3 1 5 3 5 0-5-1-8 1-12z"/></svg>',
  huelle:'<svg viewBox="0 0 32 32"><path d="M4 15 16 5l12 10"/><path d="M7 13v13h18V13"/><path d="M4 18h3M25 18h3M4 22h3M25 22h3"/></svg>',
  beides:'<svg viewBox="0 0 32 32"><path d="M4 15 16 5l12 10"/><path d="M7 13v13h18V13"/><path d="M16 14c2 3 4 4 4 7a4 4 0 0 1-8 0c0-2 1-3 2-4 0 1 1 2 2 2 0-2-1-3 0-5z"/></svg>',
  oel:'<svg viewBox="0 0 32 32"><path d="M16 4c5 8 8 12 8 16a8 8 0 0 1-16 0c0-4 3-8 8-16z"/></svg>',
  gas:'<svg viewBox="0 0 32 32"><path d="M16 4c4 6 8 9 8 15a8 8 0 0 1-16 0c0-4 2-6 4-8 0 3 1 5 3 5 0-5-1-8 1-12z"/></svg>',
  etage:'<svg viewBox="0 0 32 32"><rect x="9" y="5" width="14" height="22"/><path d="M16 11c2 3 3 4 3 6a3 3 0 0 1-6 0c0-2 1-3 3-6z"/><path d="M12 23h8"/></svg>',
  strom:'<svg viewBox="0 0 32 32"><path d="M18 3 8 18h7l-2 11 11-16h-7z"/></svg>',
  kohle:'<svg viewBox="0 0 32 32"><path d="M6 22l5-9 7 2 6-6 3 8-4 9H9z"/></svg>',
  bio:'<svg viewBox="0 0 32 32"><path d="M7 25c0-11 7-18 19-18-1 12-8 19-19 18z"/><path d="M7 25 18 14"/></svg>',
  wp:'<svg viewBox="0 0 32 32"><rect x="4" y="8" width="24" height="17"/><circle cx="13" cy="16.5" r="5"/><path d="M13 11.5v10M8 16.5h10"/><path d="M22 12h3M22 16h3M22 20h3"/></svg>',
  fern:'<svg viewBox="0 0 32 32"><path d="M3 22h26M3 22v-6h8v6M21 22V12h8v10"/><path d="M11 18h10"/><circle cx="16" cy="10" r="3"/></svg>',
  sonne:'<svg viewBox="0 0 32 32"><circle cx="16" cy="16" r="5"/><path d="M16 4v4M16 24v4M4 16h4M24 16h4M7.5 7.5l2.8 2.8M21.7 21.7l2.8 2.8M7.5 24.5l2.8-2.8M21.7 10.3l2.8-2.8"/></svg>',
  frage:'<svg viewBox="0 0 32 32"><circle cx="16" cy="16" r="12"/><path d="M12.5 12.5a3.5 3.5 0 1 1 5 3.2c-1 .5-1.5 1.3-1.5 2.3v1"/><path d="M16 23v.5"/></svg>',
  dach:'<svg viewBox="0 0 32 32"><path d="M3 18 16 6l13 12"/><path d="M7 15l9-8 9 8"/></svg>',
  fassade:'<svg viewBox="0 0 32 32"><rect x="6" y="6" width="20" height="21"/><path d="M6 11h20M6 16h20M6 21h20M13 6v5M19 11v5M13 16v5M19 21v6"/></svg>',
  fenster:'<svg viewBox="0 0 32 32"><rect x="7" y="5" width="18" height="22"/><path d="M16 5v22M7 15h18"/></svg>',
  keller:'<svg viewBox="0 0 32 32"><path d="M4 12h24"/><path d="M4 16h24" stroke-dasharray="2 2"/><path d="M7 16v11h18V16"/></svg>'
};
const eur = n => Math.round(n).toLocaleString("de-DE") + " €";
const num = n => Math.round(n).toLocaleString("de-DE");
const BJ = {"vor1949":["vor 1949",190],"1949":["1949–1978",200],"1979":["1979–1994",150],"1995":["1995–2009",110],"2010":["ab 2010",65]};
const FUEL = {
  oel:{n:"Ölheizung",u:"Liter Heizöl",kwh:10,eta:.85,step:100},
  gas:{n:"Gasheizung",u:"kWh Gas",kwh:1,eta:.87,step:500},
  etage:{n:"Gasetagenheizung",u:"kWh Gas",kwh:1,eta:.87,step:500},
  strom:{n:"Nachtspeicher",u:"kWh Strom",kwh:1,eta:1,step:500},
  kohle:{n:"Kohle",u:"kg Briketts",kwh:5.5,eta:.7,step:100},
  bio:{n:"Holz/Pellets",u:"kg Pellets",kwh:4.8,eta:.85,step:100},
  wp:{n:"Wärmepumpe",u:"kWh Strom",kwh:1,eta:3,step:250},
  fern:{n:"Fernwärme",u:"kWh Wärme",kwh:1,eta:.95,step:500}
};
const HAUS = {efh:["Einfamilienhaus",1,140],rh:["Doppel- oder Reihenhaus",1,120],zfh:["Zweifamilienhaus",2,190],mfh:["Mehrfamilienhaus",3,0]};
const NEU = {wp:"Wärmepumpe",bio:"Pelletheizung",hack:"Hackschnitzelheizung",netz:"Wärmenetz",offen:"Beratung gewünscht"};
const HUELLE = {dach:["Dach",.75,180],fassade:["Fassade",1,200],fenster:["Fenster und Türen",.18,900],keller:["Kellerdecke",.6,60]};
// Name der gewählten Bauteile für Überschriften, z. B. „Dach und Fenster/Türen“ statt pauschal „Dämmung und Fenster“
const KURZ = {dach:"Dach",fassade:"Fassade",fenster:"Fenster/Türen",keller:"Kellerdecke"};
function huelleName(){ const a = Object.keys(S.bauteile).filter(k=>S.bauteile[k]).map(k=>KURZ[k]);
  return a.length < 2 ? (a[0] || "Gebäudehülle") : a.slice(0,-1).join(", ") + " und " + a[a.length-1]; }
const EINK = {30:"bis 30.000 €",40:"bis 40.000 €",50:"bis 50.000 €",60:"bis 60.000 €",90:"bis 90.000 €",99:"über 90.000 €",0:"keine Angabe"};
// Einkommensbonus je Stufe; mit Kindern unter 18 zählt die nächstniedrigere Stufe
const einkBonus = v => { const z = S.kinder ? {30:30,40:30,50:40,60:50,99:99}[v] : v; return {30:40,40:30,50:10}[z] || 0; };

const S = {vorhaben:null,haus:null,we:1,bj:null,flaeche:140,alt:null,alt20:null,verbrauch:null,voll:null,neu:null,
  holz:false,ster:5,solar:false,solarArt:null,zusatzKein:false,bauteile:{},nutzung:null,eink:null,kinder:null,isfp:false,kHeiz:null,kHuelle:null,kBegleit:null,kostenOffen:false,info:null,partnerOpen:false,unsicher:false,pdfForm:false,pdfOk:false};
let cur = 0;

const heiz = () => S.vorhaben !== "huelle";
const huelle = () => S.vorhaben !== "heiz";
// Wärme aus Holzofen (1.750 kWh je Ster Mischholz, 80 % Ofenwirkungsgrad) und Solarthermie (EFH: 1.500 kWh nur Warmwasser, 3.500 kWh mit Heizungsunterstützung)
const holzKwh = () => S.holz ? S.ster*1750*.8 : 0;
const solarKwh = () => S.solar ? (S.solarArt==="hz" ? 3500 : 1500) : 0;
const zusatz = () => holzKwh() + solarKwh();
// Typischer Wärmebedarf fürs Baujahr; der Hauptheizung bleibt, was Ofen und Sonne nicht liefern
const bedarf = () => BJ[S.bj][1]*S.flaeche*.85;
// Plausibler Bereich: Verbrauch im Verhältnis zum typischen Wert (der Zuheizen schon abzieht)
const PLAUS = [.75, 1.3];
function typVerbrauch(){ const f = FUEL[S.alt]; const q = Math.max(bedarf()-zusatz(), bedarf()*.2); return Math.round(q/(f.eta*f.kwh)/f.step)*f.step; }
function heizlast(){
  const f = FUEL[S.alt], typ = typVerbrauch();
  const v = (S.verbrauch == null || S.voll === false) ? typ : S.verbrauch;
  const q = v*f.kwh*f.eta + zusatz() - 12.5*S.flaeche;
  return {kw: Math.max(3, q/2000), v, typ, ratio: (S.verbrauch ?? typ)/typ};
}
// Richtpreise für die Schätzung: Grundkosten + Preis je kW Heizlast
// Grundkosten, Preis je kW, Mindestpreis (Stephan 29.10.2026: Wärmepumpe ab 30.000 €, Pellets und Hackschnitzel ab 35.000 €)
const PREIS = {wp:[24000,1500,30000,"Wärmepumpe"], offen:[24000,1500,30000,"Wärmepumpe"], bio:[24000,1500,35000,"Pelletheizung"], hack:[24000,1500,35000,"Hackschnitzelheizung"], netz:[10000,400,10000,"Wärmenetz-Anschluss"]};
function schaetzHeiz(){ const p = heizlast().kw, [g,kw,min] = PREIS[S.neu]; return Math.max(min, Math.round((g+kw*p)/500)*500); }
function schaetzHuelle(){ return Object.keys(S.bauteile).filter(k=>S.bauteile[k]).reduce((s,k)=>s+HUELLE[k][1]*HUELLE[k][2]*S.flaeche,0); }
const kostenHeiz = () => S.kHeiz ?? schaetzHeiz();
const kostenHuelle = () => S.kHuelle ?? schaetzHuelle();
const kostenBegleit = () => S.kBegleit ?? 3500;
function infoText(was){
  const fmt = n => n.toFixed(1).replace(".",",");
  if (was==="heiz"){ const h = heizlast(), [g,kw,min,n] = PREIS[S.neu], roh = g + h.kw*kw;
    return `<b>So schätzen wir:</b> ${n} mit ${eur(g)} Grundkosten (Gerät, Montage, Elektrik, Hydraulik) plus ${eur(kw)} je kW Heizlast. Ihre Heizlast: ${fmt(h.kw)} kW aus ${num(h.v)} ${FUEL[S.alt].u} im Jahr. Ergibt ${eur(g)} + ${fmt(h.kw)} × ${eur(kw)} ≈ ${eur(roh)}${roh < min ? `, wir setzen aber mindestens ${eur(min)} an, weil Angebote darunter kaum vorkommen` : ""}. Richtwerte 2026, im Einzelfall kann es deutlich teurer werden. Je nach Aufwand kommen Kosten für neue Heizkörper und die Entsorgung der alten Heizung hinzu.`; }
  if (was==="huelle") return `<b>So schätzen wir:</b> Richtpreise je Bauteil, bezogen auf ${num(S.flaeche)} m² Wohnfläche. `+Object.keys(S.bauteile).filter(k=>S.bauteile[k]).map(k=>{const [n,f,pr]=HUELLE[k];return `${n}: ${num(S.flaeche*f)} m² × ${eur(pr)} = ${eur(S.flaeche*f*pr)}`}).join("; ")+`. Die Bauteilfläche leiten wir aus der Wohnfläche ab (z. B. Fenster 18 %, Dach 75 %).`;
  if (was==="begleit") return `<b>So schätzen wir:</b> Pauschal 3.500 € für Fachplanung und Baubegleitung durch einen Energieeffizienz-Experten bei einem Einfamilienhaus. Der Zuschuss beträgt 50 %, höchstens auf 5.000 € (bis 2 Wohnungen).`;
}

// Stichtage der Reform vom 21.07.2026: Klimageschwindigkeitsbonus und Kostengrenze der 1. Wohneinheit (wie foerdercheck.js)
function stufe(d){
  const t = d.toISOString().slice(0,10);
  const s = [["2027-02-01",16,28000],["2027-08-01",12,27250],["2028-02-01",8,26500],["2028-08-01",4,25750]];
  for (const [bis,kb,cap] of s) if (t < bis) return {kb,cap};
  const halbj = Math.floor((d.getFullYear()-2028)*2 + (d.getMonth()>=7?1:0));
  return {kb:0,cap:Math.max(22000,25750-750*Math.max(0,halbj))};
}
// Endenergie je m² aus Verbrauch (ohne Verbrauchsangabe: typischer Wert fürs Baujahr), für den Hinweis auf Klasse G/H
function kennwert(){ if (!heiz() || !S.alt) return BJ[S.bj][1]; const f = FUEL[S.alt], v = heizlast().v; return S.alt==="wp" ? BJ[S.bj][1] : v*f.kwh/S.flaeche; }
function calc(){
  const {kb,cap} = stufe(new Date()), we = S.we, selbst = S.nutzung === "selbst";
  const z0 = S.eink || 99;
  const zve = S.kinder ? {30:30,40:30,50:40,60:50,90:99,99:99}[z0] : (z0===60 || z0===90 ? 99 : z0);
  const lines = [], tips = []; let total = 0, ges = 0;
  if (heiz()){
    const k = kostenHeiz(); ges += k;
    const capAll = cap + Math.min(we-1,5)*15000 + Math.max(0,we-6)*8000, ff = Math.min(k,capAll);
    const altKey = S.alt==="gas" ? (S.alt20?"gas20":"gasjung") : S.alt==="bio" ? (S.alt20?"bio20":"biojung") : S.alt;
    const klimaOk = selbst && ["oel","gas20","etage","strom","kohle","bio20"].includes(altKey);
    const eink = selbst ? ({30:40,40:30,50:10}[zve] || 0) : 0;
    const deckel = selbst && zve===30 ? 80 : 70;
    const satz = Math.min(deckel, 30 + (klimaOk?kb:0) + eink);
    const eigen = selbst ? ff/we : 0, z = eigen*satz/100 + (ff-eigen)*.3;
    total += z;
    const t = ["30 % Grundförderung"]; if (klimaOk) t.push(kb+" % Klimabonus"); if (eink) t.push(eink+" % Einkommensbonus");
    lines.push(["Heizung (KfW 458)", z, `${we>1?"Bonus nur für die selbst genutzte Wohnung. ":""}${t.join(" + ")}${satz<30+(klimaOk?kb:0)+eink?`, gedeckelt auf ${deckel} %`:""} auf ${eur(ff)} förderfähige Kosten.`]);
    if (k > capAll) tips.push(`<b>Kostengrenze:</b> Von ${eur(k)} sind nur ${eur(capAll)} förderfähig. Den Rest kann die KfW per Ergänzungskredit finanzieren.`);
    if (klimaOk && kb===16) tips.push("<b>Jetzt beantragen lohnt sich:</b> Ab 1. Februar 2027 sinkt der Klimabonus auf 12 % und die Kostengrenze auf 27.250 €.");
    if (selbst && !klimaOk && kb && (altKey==="gasjung" || altKey==="biojung")) tips.push(`<b>Kein Klimabonus:</b> ${altKey==="gasjung"?"Gasheizungen":"Holz- und Pelletheizungen"} bekommen ihn erst ab 20 Jahren Betriebszeit.`);
    if (S.neu==="wp" || S.neu==="offen") tips.push("<b>Achtung 2027:</b> Ab dem ersten Quartal 2027 sinkt die Grundförderung für Wärmepumpen, die nicht in der EU hergestellt werden, auf 15 %. Für Geräte aus der EU bleibt es bei 30 %. Fragen Sie Ihren Installateur nach dem Herstellungsort.");
    if (we > 1) tips.push("<b>Hinweis:</b> Die Kostengrenze für die Heizung gilt für das ganze Gebäude, nicht für jede Wohnung einzeln.");
    if (S.alt==="wp") tips.push("<b>Wärmepumpe ersetzt Wärmepumpe:</b> Das wird derzeit noch gefördert, aber ohne Klimabonus. Ab dem ersten Quartal 2027 entfällt die Förderung, wenn die alte Anlage seit 2008 läuft. Bei älteren Anlagen sind dann nur noch 25 % der Kosten förderfähig.");
    if (S.eink===0 && selbst) tips.push("<b>Einkommensbonus:</b> Ohne Angabe nicht eingerechnet. Er kann bis zu 40 % zusätzlich bringen.");
  }
  if (huelle()){
    const k = kostenHuelle();
    if (k > 0){
      ges += k;
      const base = S.isfp ? 60000 : 30000, capH = base + Math.min(we-1,5)*(S.isfp?30000:15000);
      const ohne = 30000 + Math.min(we-1,5)*15000, f = Math.min(k,capH);
      const z = f*.15 + (S.isfp ? Math.max(0,f-ohne)*.05 : 0);
      total += z;
      lines.push([`${huelleName()} (BAFA)`, z, `15 % auf ${eur(f)} förderfähige Kosten${S.isfp&&f>ohne?`, plus 5 % iSFP-Bonus auf ${eur(f-ohne)}`:""}.`]);
      const kB = kostenBegleit(), capB = we<=2 ? 5000 : Math.min(2000*we,20000), zB = Math.min(kB,capB)*.5;
      total += zB; ges += kB;
      lines.push(["Baubegleitung (BAFA)", zB, `50 % auf ${S.kBegleit==null?"geschätzte ":""}${eur(kB)}. Bei Maßnahmen an der Gebäudehülle ist sie Pflicht.`]);
      if (S.isfp){ const ebw = we<=2?650:850; total += ebw; lines.push(["Zuschuss iSFP-Erstellung", ebw, `50 % des Beraterhonorars, höchstens ${eur(ebw)}.`]); }
      if (k > capH) tips.push(`<b>Kostengrenze:</b> Für Maßnahmen an der Gebäudehülle sind ${eur(capH)} je Gebäude und Kalenderjahr förderfähig. Größere Vorhaben lassen sich auf zwei Jahre verteilen.`);
      const steuer = Math.min(Math.min(k,200000)*.2, 40000);
      if (selbst && steuer > z) tips.push(`<b>Steuerbonus prüfen:</b> Über § 35c EStG wären es bis zu ${eur(steuer)} über drei Jahre, also ${eur(steuer-z)} mehr als die BAFA. Gilt nur für selbst genutzte Häuser über zehn Jahre.`);
      if (!S.isfp && k > 30000*we) tips.push("<b>Sanierungsfahrplan lohnt sich:</b> Mit iSFP verdoppelt sich die Kostengrenze. Schalten Sie oben „Mit Sanierungsfahrplan rechnen“ ein, um den Unterschied zu sehen.");
      if (kennwert() >= 200) tips.push("<b>Hoher Verbrauch:</b> Ihr Haus liegt vermutlich in Klasse G oder H. Dafür gibt es ab dem ersten Quartal 2027 einen Zusatzbonus von 5 % für Dämmung (Worst-Performing-Building). Voraussetzung ist ein iSFP.");
    }
  }
  // KfW-Ergänzungskredit (Merkblatt 358/359, Stand 09/2026): finanziert den Eigenanteil, auch Kosten über der Kostengrenze des Zuschusses, höchstens 120.000 € je Wohneinheit.
  // 358 „Plus“ mit Zinsvergünstigung nur für selbst bewohnte Einfamilienhäuser bei Haushaltseinkommen bis 90.000 € (Kinder zählen hier nicht)
  if (total > 0){
    const efh = we === 1 && selbst;
    if (efh && S.eink && S.eink <= 90) tips.push("<b>Günstiger Kredit:</b> Ihren Eigenanteil können Sie über den KfW-Ergänzungskredit Plus (358) mit vergünstigtem Zins finanzieren, auch Kosten über der Kostengrenze des Zuschusses, bis 120.000 €. Voraussetzung sind die Zuschusszusage und ein Haushaltseinkommen bis 90.000 €.");
    else if (efh && S.eink === 0) tips.push("<b>Günstiger Kredit:</b> Liegt Ihr Haushaltseinkommen bei höchstens 90.000 €, können Sie Ihren Eigenanteil über den KfW-Ergänzungskredit Plus (358) mit vergünstigtem Zins finanzieren, bis 120.000 €. Sonst bleibt der normale Ergänzungskredit (359).");
    else tips.push(`<b>Finanzierung:</b> Mit der Zuschusszusage können Sie Ihren Eigenanteil über den KfW-Ergänzungskredit (359) finanzieren, auch Kosten über der Kostengrenze, bis 120.000 € je Wohneinheit. Den vergünstigten Zins (358) gibt es nur für selbst bewohnte Einfamilienhäuser bei einem Haushaltseinkommen bis 90.000 €.`);
  }
  return {total, ges, lines, tips};
}

const tile = (k,v,label,icon,sub) => `<button type="button" class="tile${icon?"":" row"}" data-k="${k}" data-v="${v}" aria-pressed="${k==="vorhaben" && S.unsicher ? v==="info" : String(S[k])===String(v)}">${icon?I[icon]:""}<span>${label}${sub?`<br><small>${sub}</small>`:""}</span></button>`;
const chip = (k,v,label) => `<button type="button" class="chip" data-k="${k}" data-v="${v}" aria-pressed="${String(S[k])===String(v)}">${label}</button>`;

const STEPS = [
  {id:"vorhaben", show:()=>true, html:()=>`<h2>Was haben Sie vor?</h2>
    <div class="tiles">${tile("vorhaben","heiz","Heizung tauschen","heiz")}${tile("vorhaben","huelle","Dämmen oder Fenster","huelle")}${tile("vorhaben","beides","Beides","beides")}${tile("vorhaben","info","Weiß ich noch nicht","frage","wir rechnen Heizung")}</div>`},
  {id:"haus", show:()=>true, html:()=>`<h2>Welches Haus ist es?</h2>
    <div class="tiles">${tile("haus","efh","Einfamilienhaus","efh")}${tile("haus","rh","Doppel- oder Reihenhaus","rh")}${tile("haus","zfh","Zweifamilienhaus","zfh")}${tile("haus","mfh","Mehrfamilienhaus","mfh")}</div>
    ${S.haus==="mfh"?`<div class="sub"><p>Wie viele Wohnungen?</p><div class="chips">${[3,4,5,6,8,10].map(n=>chip("we",n,n===10?"10 oder mehr":n)).join("")}</div></div>`:""}`, multi:()=>S.haus==="mfh"},
  {id:"bj", show:()=>true, html:()=>`<h2>Wann wurde es gebaut?</h2><p class="hint">Ungefähr reicht.</p>
    <div class="tiles one">${Object.entries(BJ).map(([k,[l]])=>tile("bj",k,l)).join("")}</div>`},
  {id:"flaeche", show:()=>true, html:()=>`<h2>Wie groß ist die Wohnfläche?</h2><p class="hint">Alle Wohnungen zusammen, grob geschätzt.</p>
    <div class="slider"><output id="sfk-flOut">${num(S.flaeche)} m²</output>
    <div class="flrow"><button type="button" class="chip" data-fl="-5" aria-label="5 m² weniger">−</button>
    <input type="range" id="sfk-fl" min="40" max="600" step="5" value="${S.flaeche}" aria-label="Wohnfläche">
    <button type="button" class="chip" data-fl="5" aria-label="5 m² mehr">+</button></div>
    <div class="skala"><span>40 m²</span><span>600 m²</span></div></div>
    <p class="hint">Vorbelegt mit einem typischen Wert für Ihren Haustyp.</p>`, multi:()=>true},
  {id:"alt", show:heiz, html:()=>`<h2>Womit heizen Sie heute?</h2>
    <div class="tiles">${Object.entries(FUEL).map(([k,f])=>tile("alt",k,f.n,k)).join("")}</div>
    ${["gas","bio"].includes(S.alt)?`<div class="sub"><p>Ist die Heizung 20 Jahre oder älter?</p><div class="chips">${chip("alt20",true,"Ja")}${chip("alt20",false,"Nein, jünger")}</div></div>`:""}`, multi:()=>["gas","bio"].includes(S.alt), ready:()=>S.alt20!=null},
  {id:"zusatz", show:heiz, html:()=>`<h2>Heizen Sie zusätzlich mit Holz oder Sonne?</h2><p class="hint">Wichtig für die Heizlast: Was Ofen oder Solaranlage liefern, fehlt sonst im Verbrauch.</p>
    <div class="tiles"><button type="button" class="tile" data-z="holz" aria-pressed="${S.holz}">${I.bio}<span>Holzofen oder Kamin</span></button><button type="button" class="tile" data-z="solar" aria-pressed="${S.solar}">${I.sonne}<span>Solarthermie</span></button></div>
    <div class="tiles one"><button type="button" class="tile row" data-z="kein" aria-pressed="${S.zusatzKein}"><span>Nichts davon</span></button></div>
    ${S.holz?`<div class="sub"><p>Wie viel Holz verheizen Sie ungefähr im Jahr?</p><div class="slider"><output id="sfk-sOut">${S.ster} Ster</output>
      <input type="range" id="sfk-st" min="1" max="30" step="1" value="${S.ster}" aria-label="Ster Holz im Jahr"><div class="skala"><span>1 Ster</span><span>30 Ster</span></div></div></div>`:""}
    ${S.solar?`<div class="sub"><p>Wofür ist die Solaranlage?</p><div class="chips">${chip("solarArt","ww","Nur Warmwasser")}${chip("solarArt","hz","Auch Heizungsunterstützung")}</div></div>`:""}`,
    multi:()=>S.holz||S.solar, ready:()=>S.zusatzKein || ((S.holz||S.solar) && (!S.solar || S.solarArt))},
  {id:"verbrauch", show:heiz, html:()=>{
    const f = FUEL[S.alt], typ = typVerbrauch(), v = S.verbrauch ?? typ, h = heizlast();
    const r = h.ratio, wenig = S.verbrauch!=null && r<PLAUS[0], ok = r>=PLAUS[0] && r<=PLAUS[1];
    return `<h2>Wie viel verbrauchen Sie im Jahr?</h2><p class="hint">Vorbelegt mit dem typischen Wert für Ihr Haus. Kennen Sie Ihren Verbrauch von der Abrechnung, stellen Sie ihn ein, sonst einfach weiter.</p>${zusatz()?`<p class="hint">Darin schon abgezogen: ${num(zusatz())} kWh aus ${[S.holz&&"Holzofen",S.solar&&"Solarthermie"].filter(Boolean).join(" und ")}.</p>`:""}
    <div class="slider"><output id="sfk-vOut">${num(v)} ${f.u}</output>
    <input type="range" id="sfk-vb" min="${f.step}" max="${Math.round(typ*2.5/f.step)*f.step}" step="${f.step}" value="${v}" aria-label="Jahresverbrauch">
    <div class="skala"><span>wenig</span><span>typisch: ${num(typ)}</span><span>viel</span></div></div>
    ${S.verbrauch==null?`<div class="check">Wir rechnen mit dem typischen Wert für ein Haus von ${BJ[S.bj][0]} mit ${num(S.flaeche)} m².</div>`:
      ok?`<div class="check">Passt zu Baujahr und Fläche.</div>`:
      r<PLAUS[0]?`<div class="check w">Deutlich weniger als üblich. Häufige Gründe: Haus nicht voll bewohnt, Zweitwohnsitz${S.holz?"":", ein Kaminofen (dann bitte einen Schritt zurück angeben)"} oder schon gedämmt.</div>`:
      `<div class="check w">Deutlich mehr als üblich. Bitte prüfen, ob Warmwasser, Pool oder ein Nebengebäude mit drin sind.</div>`}
    ${wenig?`<div class="sub"><p>War das Haus in den letzten Jahren voll bewohnt und normal beheizt?</p><div class="chips">${chip("voll",true,"Ja")}${chip("voll",false,"Nein oder unsicher")}</div></div>
      ${S.voll===false?`<p class="must">Dann rechnen wir mit dem typischen Wert weiter. Ein Verbrauch aus einem teilweise leeren Haus führt zu einer zu kleinen Heizung.</p>`:""}`:""}
    ${S.verbrauch!=null?`<button type="button" class="chip" id="sfk-vReset" style="align-self:flex-start">Zurück zum typischen Wert</button>`:""}`;}, multi:()=>true, ready:()=>S.verbrauch==null || heizlast().ratio>=PLAUS[0] || S.voll!=null},
  {id:"neu", show:heiz, html:()=>`<h2>Welche neue Heizung soll es werden?</h2>
    <div class="tiles">${tile("neu","wp","Wärmepumpe","wp")}${tile("neu","bio","Pellets","bio")}${tile("neu","hack","Hackschnitzel","kohle")}${tile("neu","netz","Wärmenetz","fern")}</div>
    <div class="tiles one">${tile("neu","offen","Beratung gewünscht","","wir rechnen vorerst mit einer Wärmepumpe")}</div>`},
  {id:"bauteile", show:huelle, html:()=>`<h2>Was soll gedämmt oder erneuert werden?</h2><p class="hint">Mehrere möglich.</p>
    <div class="tiles">${Object.entries(HUELLE).map(([k,[l]])=>`<button type="button" class="tile" data-b="${k}" aria-pressed="${!!S.bauteile[k]}">${I[k]}<span>${l}</span></button>`).join("")}</div>`, multi:()=>true, ready:()=>schaetzHuelle()>0},
  {id:"haushalt", show:()=>true, html:()=>`<h2>Wer wohnt im Haus?</h2>
    <div class="tiles">${tile("nutzung","selbst","Ich wohne selbst darin","efh")}${tile("nutzung","vermietet","Komplett vermietet","mfh")}</div>`},
  {id:"kinder", show:()=>S.nutzung==="selbst", html:()=>`<h2>Leben Kinder unter 18 im Haushalt?</h2><p class="hint">Mit Kindern gilt beim Einkommensbonus eine günstigere Stufe.</p>
    <div class="tiles">${tile("kinder",true,"Ja","",)}${tile("kinder",false,"Nein")}</div>`},
  {id:"eink", show:()=>S.nutzung==="selbst", html:()=>`<h2>Wie hoch ist Ihr Haushaltseinkommen?</h2><p class="hint">Das zu versteuernde Einkommen aus dem letzten Steuerbescheid. Es bringt bis zu 40 % Bonus.</p>
    <div class="tiles drei">${[30,40,50,60,90,99].map(v=>{ const b = einkBonus(v); return tile("eink",v,EINK[v],"",b?`+ ${b} % Bonus`:"kein Bonus"); }).join("")}</div>
    <div class="tiles one">${tile("eink",0,"Keine Angabe")}</div>`},
  {id:"ergebnis", show:()=>true, html:result}
];

function kostenBlock(){
  const rows = [
    heiz() && ["heiz","Kosten neue Heizung",S.kHeiz,schaetzHeiz()],
    huelle() && schaetzHuelle()>0 && ["huelle",`Kosten ${huelleName()}`,S.kHuelle,schaetzHuelle()],
    huelle() && schaetzHuelle()>0 && ["begleit","Kosten Baubegleitung",S.kBegleit,3500]
  ].filter(Boolean);
  const zeile = ([id,l,ist,sch]) => `<li class="krow"><span><b>${l}:</b> ${eur(ist ?? sch)} <em>${ist==null?"geschätzt":"Ihre Angabe"}</em>
      <button type="button" class="info" data-info="${id}" aria-expanded="${S.info===id}" aria-label="Wie wir schätzen">i</button></span>
      ${S.info===id?`<span class="infotxt">${infoText(id)}</span>`:""}
      ${S.kostenOffen?`<span class="kin"><input type="text" inputmode="numeric" id="sfk-k_${id}" placeholder="${num(sch)}" value="${ist==null?"":num(ist)}" aria-label="${l} in Euro"> €
        ${ist!=null?`<button type="button" class="chip" data-reset="${id}">Schätzung nehmen</button>`:""}</span>`:""}</li>`;
  return `<ul class="ass kosten">${rows.map(zeile).join("")}</ul>
  ${S.kostenOffen?`<button type="button" class="go" id="sfk-kOk">Mit diesen Kosten rechnen</button>`:`<button type="button" class="chip" id="sfk-kOpen" style="align-self:flex-start;margin-top:8px">Liegt schon ein Angebot vor? Tatsächliche Kosten eingeben</button>`}`;
}
function result(){
  const r = calc(), h = heiz() ? heizlast() : null;
  const bt = Object.keys(S.bauteile).filter(k=>S.bauteile[k]).map(k=>HUELLE[k][0]).join(", ");
  const gruppen = [
    ["Haus", "haus", [HAUS[S.haus][0] + (S.we>1?`, ${S.we} Wohnungen`:""), `Baujahr ${BJ[S.bj][0]}`, `${num(S.flaeche)} m² Wohnfläche`]],
    heiz() && ["Heizung", "alt", [`${FUEL[S.alt].n} → ${NEU[S.neu]}`,
      S.verbrauch==null||S.voll===false ? `Verbrauch: typischer Wert, ${num(h.typ)} ${FUEL[S.alt].u}` : `Verbrauch: ${num(S.verbrauch)} ${FUEL[S.alt].u}`,
      [S.holz && `Holzofen ${S.ster} Ster`, S.solar && `Solarthermie ${S.solarArt==="hz"?"mit Heizung":"für Warmwasser"}`].filter(Boolean).join(", ") || "Kein Zuheizen",
      `<em>Annahme: Die alte Heizung läuft noch</em>`]],
    huelle() && ["Gebäudehülle", "bauteile", [bt || "nichts gewählt"]],
    ["Haushalt", "haushalt", S.nutzung==="selbst" ? ["Selbst bewohnt", `Einkommen ${EINK[S.eink]}`, S.kinder ? "Mit Kindern unter 18" : "Ohne Kinder unter 18"] : ["Vermietet"]]
  ].filter(Boolean);
  const kw = h ? `${(h.kw*.9).toFixed(1).replace(".",",")}–${(h.kw*1.1).toFixed(1).replace(".",",")} kW` : "";
  return `<div class="sum">
    <p class="eyebrow" style="margin:0">Ihr möglicher Zuschuss</p><b>${eur(r.total)}</b>
    <div class="facts"><span><small>Kosten rund</small>${eur(r.ges)}</span><span><small>Förderquote</small>${r.ges?Math.round(r.total/r.ges*100):0} %</span>${h?`<span><small>Heizlast ca.</small>${kw}</span>`:""}</div>
    ${pdfBox()}
  </div>
  <div class="rgrid">
    <section class="box"><h3>So setzt sich der Zuschuss zusammen</h3>
      <div class="lines">${r.lines.map(([t,v,d])=>`<div class="ln"><b>${t}</b><span class="v">${eur(v)}</span><span class="d">${d}</span></div>`).join("")}</div>
      ${huelle()&&kostenHuelle()>0?`<label class="toggle" for="sfk-isfpSw">Mit Sanierungsfahrplan (iSFP) rechnen<input type="checkbox" class="sw" id="sfk-isfpSw" ${S.isfp?"checked":""}></label>`:""}
    </section>
    <section class="box"><h3>Kosten</h3>${kostenBlock()}</section>
    <section class="box wide"><h3>Ihre Angaben</h3><div class="groups">${gruppen.map(([t,go,z])=>`<div class="grp"><div class="grph"><b>${t}</b><button type="button" data-goto="${go}">ändern</button></div>${z.map(x=>`<span>${x}</span>`).join("")}</div>`).join("")}</div></section>
  </div>
  ${(()=>{ const t = [...r.tips];
    if (h) t.unshift(`<b>Heizlast ${kw}:</b> grobe Abschätzung aus dem Verbrauch${S.holz?`, Holzofen mit ${S.ster} Ster ≈ ${num(holzKwh())} kWh/Jahr berücksichtigt`:""}${S.solar?`, Solarthermie mit ca. ${num(solarKwh())} kWh/Jahr berücksichtigt`:""}. Sie gilt nur für ein voll bewohntes, dauerhaft beheiztes Haus. Für die Auslegung der neuen Heizung ist eine Heizlastberechnung nach DIN EN 12831 nötig.`);
    return `<section class="box tips"><h3>Gut zu wissen</h3><ul>${t.map(x=>`<li>${x}</li>`).join("")}</ul></section>`; })()}
  ${S.vorhaben==="heiz" && CFG.partner?`<div class="ad"><span class="tag">Anzeige</span><b>Angebote von Heizungsbetrieben vergleichen</b>
    ${S.partnerOpen?`<a href="${esc(CFG.partner)}" target="_blank" rel="sponsored noopener">Zum Angebotsvergleich</a>`:`<span>Kostenlos bis zu drei Angebote aus Ihrer Region.</span><button type="button" id="sfk-adBtn">Angebote anfordern</button>`}</div>`:""}
  <button type="button" class="neu" data-goto="vorhaben">Neu starten</button>`;
}
// Buttons im Ergebnis-Kopf; das PDF gibt es gegen Name, E-Mail und PLZ (geht als Anfrage „Ergebnis als PDF“ ein)
function pdfBox(){
  if (!S.pdfForm) return `${S.neu==="offen"&&heiz()?`<p class="wunsch">Sie wünschen eine Empfehlung für die neue Heizung. Wir rechnen vorerst mit einer Wärmepumpe und beraten Sie gern, was zu Ihrem Haus passt.</p>`:""}
    <div class="acts"><button type="button" class="go" id="sfk-toLead">${S.neu==="offen"&&heiz()?"Kostenlose Beratung anfordern":"Kostenlose Ersteinschätzung anfordern"}</button>
    <button type="button" class="ghost" id="sfk-toPdf">Ergebnis als PDF</button></div>`;
  return `<div class="pdff"><p><b>Fast geschafft.</b> Für Ihr PDF brauchen wir kurz Ihre Kontaktdaten. Danach können Sie es sofort speichern.</p>
    <div class="pf"><input type="text" id="sfk-pName" placeholder="Name" autocomplete="name" aria-label="Name">
    <input type="email" id="sfk-pMail" placeholder="E-Mail" autocomplete="email" aria-label="E-Mail">
    <input type="text" id="sfk-pPlz" placeholder="PLZ des Hauses" inputmode="numeric" maxlength="5" autocomplete="postal-code" aria-label="PLZ"></div>
    <label class="pok"><input type="checkbox" id="sfk-pOk"> <span>Ich bin einverstanden, dass meine Angaben und das Rechenergebnis gespeichert werden. Mehr in der <a href="${esc(CFG.datenschutz||"/datenschutz/")}" target="_blank">Datenschutzerklärung</a>.</span></label>
    <p class="perr" id="sfk-pErr" hidden></p>
    <div class="acts"><button type="button" class="go" id="sfk-pGo">PDF erstellen</button><button type="button" class="ghost" id="sfk-pX">Abbrechen</button></div></div>`;
}
async function pdfSenden(){
  const g = id => $(id), err = g("pErr"); err.hidden = true;
  const name = g("pName").value.trim(), mail = g("pMail").value.trim(), plz = g("pPlz").value.trim();
  if (!name || !/^\S+@\S+\.\S+$/.test(mail) || !/^\d{5}$/.test(plz) || !g("pOk").checked){
    err.textContent = "Bitte Name, gültige E-Mail, fünfstellige PLZ und die Einwilligung angeben."; err.hidden = false; return;
  }
  const r = calc();
  const data = {name,mail,tel:"",plz,wunsch:"Ergebnis als PDF",zuschuss:Math.round(r.total),kosten:Math.round(r.ges),
    details:r.lines.map(l=>l[0]+": "+Math.round(l[1])+" €").join("; "),we:S.we,nutzung:S.nutzung,klasse:"",alt:S.alt||"",neu:S.neu||"",isfp:S.isfp,
    angaben:angaben().map(([k,v])=>k+": "+v).join("; "),website:""};
  g("pGo").disabled = true;
  if (ENDPOINT){
    try{ const res = await fetch(ENDPOINT,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)}); if (!res.ok) throw 0; }
    catch{ err.textContent = "Das hat nicht geklappt. Bitte versuchen Sie es gleich noch einmal."; err.hidden = false; g("pGo").disabled = false; return; }
  }
  // Anfrageformular schon vorausfüllen
  for (const [a,b] of [["lName",name],["lMail",mail],["lPlz",plz]]){ const el = document.getElementById(a); if (el && !el.value) el.value = b; }
  S.pdfOk = true; S.pdfForm = false; render(); pdf();
}

const vis = () => STEPS.filter(s=>s.show());
function render(){
  const list = vis(); cur = Math.min(cur, list.length-1);
  const st = list[cur], scr = $("screen");
  scr.innerHTML = st.html() + (st.id!=="ergebnis" && st.multi && st.multi() ? `<button type="button" class="go" id="sfk-next" ${st.ready && !st.ready() ? "disabled":""}>Weiter</button>` : "");
  $("progI").style.width = Math.round(cur/(list.length-1)*100) + "%";
  $("stepN").textContent = st.id==="ergebnis" ? "fertig" : `${cur+1} / ${list.length-1}`;
  $("back").disabled = cur===0;
}
function next(){ cur++; render(); const t = root.getBoundingClientRect().top; if (t < 0) root.scrollIntoView({block:"start"}); }

$("screen").addEventListener("click", e=>{
  const b = e.target.closest("button"); if (!b) return;
  const st = vis()[cur];
  if (b.dataset.k){
    const k = b.dataset.k, raw = b.dataset.v, v = raw==="true"?true:raw==="false"?false:isNaN(+raw)?raw:+raw;
    S[k] = v;
    if (k==="haus"){ S.we = HAUS[v][1]; S.flaeche = v==="mfh" ? 75*Math.max(3,S.we) : HAUS[v][2]; }
    if (k==="we" && S.haus==="mfh") S.flaeche = 75*v;
    if (k==="alt" || k==="bj" || k==="haus") { S.verbrauch = null; S.voll = null; }
    
    // „Weiß ich noch nicht“ rechnet wie Heizung, bleibt aber als Auswahl markiert
    if (k==="vorhaben"){ S.unsicher = v==="info"; if (S.unsicher) S.vorhaben = "heiz"; }
    if (st.id==="ergebnis" || (st.multi && st.multi())) return render();
    render(); setTimeout(next, 220); return;
  }
  if (b.dataset.z){ const z = b.dataset.z;
    if (z==="kein"){ S.holz = S.solar = false; S.solarArt = null; S.zusatzKein = true; render(); setTimeout(next, 220); return; }
    S[z] = !S[z]; S.zusatzKein = !S.holz && !S.solar ? false : false; return render(); }
  if (b.dataset.b){ S.bauteile[b.dataset.b] = !S.bauteile[b.dataset.b]; return render(); }
  if (b.dataset.goto){ cur = vis().findIndex(s=>s.id===b.dataset.goto); return render(); }
  if (b.dataset.fl){ S.flaeche = Math.min(600, Math.max(40, S.flaeche + +b.dataset.fl)); S.verbrauch = null;
    $("fl").value = S.flaeche; $("flOut").textContent = num(S.flaeche)+" m²"; return; }
  if (b.id==="sfk-next") return next();
  if (b.id==="sfk-vReset"){ S.verbrauch = null; S.voll = null; return render(); }
  if (b.id==="sfk-adBtn"){ S.partnerOpen = true; return render(); }
  if (b.id==="sfk-toLead"){ const l = document.getElementById("lead"); l.hidden = false;
    const w = document.getElementById("lWunsch"); if (w && S.neu==="offen" && !w.querySelector("[data-hz]")){ const o = new Option("Beratung zur neuen Heizung"); o.dataset.hz = 1; w.prepend(o); w.value = o.value; } l.scrollIntoView({behavior:"smooth"}); return; }
  if (b.id==="sfk-toPdf"){ if (S.pdfOk) return pdf(); S.pdfForm = true; render(); $("pName").focus(); return; }
  if (b.id==="sfk-pX"){ S.pdfForm = false; return render(); }
  if (b.id==="sfk-pGo") return pdfSenden();
  if (b.dataset.info){ S.info = S.info===b.dataset.info ? null : b.dataset.info; return render(); }
  if (b.id==="sfk-kOpen"){ S.kostenOffen = true; render(); root.querySelector(".kin input")?.focus(); return; }
  if (b.dataset.reset){ const m = {heiz:"kHeiz",huelle:"kHuelle",begleit:"kBegleit"}[b.dataset.reset]; S[m] = null; return render(); }
  if (b.id==="sfk-kOk"){
    for (const [id,m] of [["heiz","kHeiz"],["huelle","kHuelle"],["begleit","kBegleit"]]){
      const el = $("k_"+id); if (!el) continue;
      const v = parseInt(el.value.replace(/\D/g,""),10); S[m] = v>0 ? v : null;
    }
    S.kostenOffen = false; render(); root.querySelector(".sum").scrollIntoView({block:"nearest"}); return;
  }
});
$("screen").addEventListener("input", e=>{
  const t = e.target;
  if (t.id==="sfk-fl"){ S.flaeche = +t.value; S.verbrauch = null; $("flOut").textContent = num(S.flaeche)+" m²"; }
  if (t.id==="sfk-st"){ S.ster = +t.value; $("sOut").textContent = S.ster+" Ster"; }
  if (t.id==="sfk-vb"){ S.verbrauch = +t.value; S.voll = null; $("vOut").textContent = num(S.verbrauch)+" "+FUEL[S.alt].u; }
  if (t.id==="sfk-isfpSw"){ S.isfp = t.checked; render(); }
});
$("screen").addEventListener("change", e=>{ if (e.target.id==="sfk-vb") render(); });
$("back").addEventListener("click", ()=>{ if (cur>0){ cur--; render(); } });
const esc = s => String(s).replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"})[c]);
const txt = h => { const d = document.createElement("div"); d.innerHTML = h; return d.textContent; };
function angaben(){
  const h = heiz() ? heizlast() : null;
  return [["Haus", `${HAUS[S.haus][0]}${S.we>1?`, ${S.we} Wohnungen`:""}`], ["Baujahr", BJ[S.bj][0]], ["Wohnfläche", num(S.flaeche)+" m²"],
    heiz() && ["Heizung", `${FUEL[S.alt].n} → ${NEU[S.neu]}`],
    heiz() && ["Verbrauch", S.verbrauch==null||S.voll===false ? `typischer Wert ${num(h.typ)} ${FUEL[S.alt].u}` : `${num(S.verbrauch)} ${FUEL[S.alt].u}`],
    heiz() && S.holz && ["Holzofen", `${S.ster} Ster/Jahr ≈ ${num(holzKwh())} kWh`],
    heiz() && S.solar && ["Solarthermie", S.solarArt==="hz" ? "mit Heizungsunterstützung" : "nur Warmwasser"],
    heiz() && ["Heizlast (Abschätzung)", `${(h.kw*.9).toFixed(1).replace(".",",")}–${(h.kw*1.1).toFixed(1).replace(".",",")} kW`],
    heiz() && ["Kosten Heizung", eur(kostenHeiz()) + (S.kHeiz==null?" (geschätzt)":"")],
    huelle() && ["Gebäudehülle", Object.keys(S.bauteile).filter(k=>S.bauteile[k]).map(k=>HUELLE[k][0]).join(", ")],
    huelle() && [`Kosten ${huelleName()}`, eur(kostenHuelle()) + (S.kHuelle==null?" (geschätzt)":"")],
    ["Nutzung", S.nutzung==="selbst" ? `selbst bewohnt, Einkommen ${EINK[S.eink]}${S.kinder?", mit Kindern":""}` : "vermietet"],
    ["Sanierungsfahrplan", S.isfp ? "ja" : "nein"]].filter(Boolean);
}
// Ergebnis mit Logo drucken bzw. als PDF speichern (Druckstile aus assets.css)
function pdf(){
  const r = calc();
  let box = document.getElementById("sfcReport");
  if (!box){ box = document.createElement("div"); box.id = "sfcReport"; document.body.appendChild(box); }
  box.innerHTML = `<div class="rp-head">${CFG.logo ? `<img src="${esc(CFG.logo)}" alt="">` : `<b>${esc(CFG.firma||"")}</b>`}<span>${new Date().toLocaleDateString("de-DE")}</span></div>
    <h1>Ihre Förder-Ersteinschätzung</h1>
    <p class="rp-lbl">Möglicher Zuschuss</p><p class="rp-sum">${eur(r.total)}</p>
    <table>${r.lines.map(([t,v,d])=>`<tr><td><b>${esc(t)}</b><br><small>${esc(d)}</small></td><td>${eur(v)}</td></tr>`).join("")}<tr><td>Kosten gesamt</td><td>${eur(r.ges)}</td></tr></table>
    <h2>Ihre Angaben und unsere Annahmen</h2><table>${angaben().map(([k,v])=>`<tr><td>${esc(k)}</td><td>${esc(v)}</td></tr>`).join("")}</table>
    ${r.tips.length ? `<h2>Hinweise</h2><div class="rp-tips">${r.tips.map(t=>`<p>${t}</p>`).join("")}</div>` : ""}
    <p class="rp-small">Alle Angaben ohne Gewähr. Kosten und Heizlast sind grobe Schätzungen. Die Heizlast gilt nur für ein voll bewohntes, dauerhaft beheiztes Gebäude und ersetzt keine Heizlastberechnung nach DIN EN 12831. Das Ergebnis beruht auf den veröffentlichten Förderbedingungen (KfW 458, BAFA BEG EM) und ersetzt keine Beratung.</p>
    <p class="rp-foot">${esc(CFG.firma||"")}${CFG.kontakt ? " · " + esc(CFG.kontakt) : ""}</p>`;
  document.documentElement.classList.add("sfc-printing");
  const done = ()=>{ document.documentElement.classList.remove("sfc-printing"); window.removeEventListener("afterprint", done); };
  window.addEventListener("afterprint", done);
  const imgs = [...box.querySelectorAll("img")].filter(i=>!i.complete);
  Promise.all(imgs.map(i=>new Promise(ok=>{i.onload=i.onerror=ok}))).then(()=>window.print());
}
const leadForm = document.getElementById("leadForm");
if (leadForm) leadForm.addEventListener("submit", async e=>{
  e.preventDefault();
  const g = id => document.getElementById(id), err = g("leadErr"); err.hidden = true;
  const name=g("lName").value.trim(), mail=g("lMail").value.trim(), plz=g("lPlz").value.trim();
  if (!name || !/^\S+@\S+\.\S+$/.test(mail) || !/^\d{5}$/.test(plz) || !g("lOk").checked){
    err.textContent = "Bitte Name, gültige E-Mail, fünfstellige PLZ und die Einwilligung angeben."; err.hidden = false; return;
  }
  const r = calc();
  const data = {name,mail,tel:g("lTel").value.trim(),plz,wunsch:g("lWunsch").value,
    zuschuss:Math.round(r.total),kosten:Math.round(r.ges),details:r.lines.map(l=>l[0]+": "+Math.round(l[1])+" €").join("; "),
    we:S.we,nutzung:S.nutzung,klasse:"",alt:S.alt||"",neu:S.neu||"",isfp:S.isfp,
    angaben:angaben().map(([k,v])=>k+": "+v).join("; "), website:""};
  if (!ENDPOINT){ leadForm.hidden = true; g("leadOk").hidden = false; g("leadOk").textContent = "Vorschau: In der Live-Version geht diese Anfrage jetzt per E-Mail an die Energieberatung."; return; }
  g("lSend").disabled = true;
  try{
    const res = await fetch(ENDPOINT,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)});
    if(!res.ok) throw 0;
    leadForm.hidden = true; g("leadOk").hidden = false;
    g("leadOk").textContent = `Danke, ${name}. Ihre Anfrage ist angekommen. Wir melden uns ${CFG.antwort || "innerhalb von zwei Werktagen"} bei ${mail}.`;
  }catch{
    err.textContent = "Die Anfrage konnte nicht gesendet werden. Bitte versuchen Sie es in ein paar Minuten noch einmal."; err.hidden = false; g("lSend").disabled = false;
  }
});
render();
})();
