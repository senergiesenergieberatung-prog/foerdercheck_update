# Fördercheck Pro installieren

1. WordPress → **Plugins → Installieren → Plugin hochladen** → `foerdercheck-pro.zip` → **Aktivieren**
2. **Einstellungen → Fördercheck**: zuerst unter „Ihr Abo“ die E-Mail-Adresse eintragen, mit der Sie das Abo bezahlt haben (ohne sie zeigt der Rechner kein Anfrageformular). Dann Firmenname, E-Mail für Anfragen, Akzentfarbe und Antwortzeit eintragen.
3. Neue Seite anlegen, Shortcode `[foerdercheck]` einfügen (Elementor: Widget „Shortcode“), veröffentlichen.
   - Ab Version 1.6: `[foerdercheck ansicht="kacheln"]` zeigt den Klick-Rechner mit großen Kacheln (eine Frage pro Bildschirm, ideal fürs Handy). Ohne Angabe bleibt das bisherige Formular.
4. Test-Anfrage senden. Anfragen erscheinen im Menü **Fördercheck** und kommen per E-Mail. Kommt keine Mail an, das Plugin „WP Mail SMTP“ einrichten.
5. In der Datenschutzerklärung das Anfrageformular ergänzen (Name, E-Mail, Telefon optional, PLZ, Anliegen, Rechenergebnis; Art. 6 Abs. 1 lit. b DSGVO).

Fragen und Updates: info@s-energies.de

## Neu in 1.2: Hinweis-Streifen
Mit `[foerdercheck_streifen]` erscheint ein farbiger Streifen mit Button „Förderung berechnen“, ideal direkt unter dem Kopfbereich der Startseite. Text, Farbe und Zielseite stellen Sie unter Einstellungen → Fördercheck ein. Einzelne Werte lassen sich auch direkt setzen, z. B. `[foerdercheck_streifen titel="Jetzt Förderung prüfen" farbe="#e0f0e8"]`.

## Neu in 1.3: Schnellrechner im Streifen
Der Streifen zeigt jetzt zwei Felder (Maßnahme und Kosten) und sofort eine Zuschuss-Spanne. Der Button öffnet den vollen Rechner mit diesen Werten vorbelegt. Abschalten unter Einstellungen → Fördercheck oder mit `[foerdercheck_streifen rechner="nein"]`.

## Neu in 1.4: Ergebnis mit Ihrem Logo
Unter dem Ergebnis gibt es den Button „Ergebnis als PDF speichern“. Das PDF zeigt Ihr Logo, das Ergebnis, die Angaben des Besuchers und Ihre Kontaktzeile. Wer eine Anfrage sendet, bekommt dasselbe Ergebnis per E-Mail. Logo-URL und Kontaktzeile tragen Sie unter Einstellungen → Fördercheck ein; ohne Logo-URL wird das Logo Ihres Themes genutzt. Bitte in der Datenschutzerklärung ergänzen, dass Anfragende eine Kopie ihres Ergebnisses per E-Mail erhalten.

## Neu in 1.7: Abo-Prüfung
Das Plugin fragt einmal am Tag bei s-energies.de, ob Ihr Abo läuft. Übertragen werden nur die E-Mail-Adresse Ihres Abos und die Adresse Ihrer Website. Endet das Abo, läuft der Rechner weiter, aber ohne Anfrageformular, PDF und Hinweis-Streifen, und Updates pausieren. Ist s-energies.de einmal nicht erreichbar, läuft Pro normal weiter.
