# Fördercheck Pro installieren

1. WordPress → **Plugins → Installieren → Plugin hochladen** → `foerdercheck-pro.zip` → **Aktivieren**
2. **Einstellungen → Fördercheck**: Firmenname, E-Mail für Anfragen, Akzentfarbe und Antwortzeit eintragen.
3. Neue Seite anlegen, Shortcode `[foerdercheck]` einfügen (Elementor: Widget „Shortcode“), veröffentlichen.
4. Test-Anfrage senden. Anfragen erscheinen im Menü **Fördercheck** und kommen per E-Mail. Kommt keine Mail an, das Plugin „WP Mail SMTP“ einrichten.
5. In der Datenschutzerklärung das Anfrageformular ergänzen (Name, E-Mail, Telefon optional, PLZ, Anliegen, Rechenergebnis; Art. 6 Abs. 1 lit. b DSGVO).

Fragen und Updates: info@s-energies.de
