<?php
// Lizenz: einmal am Tag bei s-energies.de nachfragen, ob das Abo zur eingetragenen E-Mail aktiv ist.
// Übertragen werden nur diese E-Mail-Adresse und die Adresse der Website. Ist s-energies.de nicht erreichbar, bleibt der letzte Stand.
if (!defined('ABSPATH')) exit;

const SFC_LIZ_URL = 'https://s-energies.de/wp-json/sfc/v1/lizenz';

function sfc_liz() {
  $l = get_option('sfc_lizenz', []);
  return is_array($l) ? $l + ['status' => 'unbekannt', 'geprueft' => 0, 'mail' => ''] : ['status' => 'unbekannt', 'geprueft' => 0, 'mail' => ''];
}

// Pro-Funktionen nur mit eingetragener E-Mail und ohne ausdrückliches „kein Abo“ vom Server
function sfc_aktiv() {
  $mail = (string) sfc_opt('lizenz_mail');
  if ($mail === '') return false;
  $l = sfc_liz();
  return !($l['mail'] === $mail && $l['status'] === 'inaktiv');
}

function sfc_liz_check($erzwingen = false) {
  $mail = (string) sfc_opt('lizenz_mail');
  if ($mail === '') return;
  $l = sfc_liz();
  if (!$erzwingen && $l['mail'] === $mail && time() - (int) $l['geprueft'] < DAY_IN_SECONDS) return;
  if (!$erzwingen && get_transient('sfc_liz_sperre')) return;
  set_transient('sfc_liz_sperre', 1, HOUR_IN_SECONDS); // bei Fehlern höchstens einmal pro Stunde neu versuchen
  $r = wp_remote_get(add_query_arg(['mail' => $mail, 'site' => home_url('/')], SFC_LIZ_URL), ['timeout' => 8]);
  if (is_wp_error($r) || wp_remote_retrieve_response_code($r) !== 200) return;
  $j = json_decode(wp_remote_retrieve_body($r), true);
  if (!is_array($j) || !array_key_exists('aktiv', $j) || $j['aktiv'] === null) return; // nicht prüfbar: alter Stand bleibt
  update_option('sfc_lizenz', ['status' => $j['aktiv'] ? 'aktiv' : 'inaktiv', 'geprueft' => time(), 'mail' => $mail]);
}

add_action('sfc_liz_cron', 'sfc_liz_check');
add_action('init', function () { if (!wp_next_scheduled('sfc_liz_cron')) wp_schedule_event(time() + 300, 'daily', 'sfc_liz_cron'); });
add_action('admin_init', function () { sfc_liz_check(); });
register_deactivation_hook(dirname(__FILE__) . '/foerdercheck-pro.php', function () { wp_clear_scheduled_hook('sfc_liz_cron'); });

add_action('admin_notices', function () {
  if (!current_user_can('manage_options') || sfc_aktiv()) return;
  $link = admin_url('options-general.php?page=sfc');
  $text = sfc_opt('lizenz_mail') === ''
    ? 'Bitte tragen Sie unter <a href="' . esc_url($link) . '">Einstellungen → Fördercheck</a> die E-Mail-Adresse Ihres Abos ein. Bis dahin zeigt der Rechner kein Anfrageformular und kein PDF.'
    : 'Zur E-Mail-Adresse ' . esc_html(sfc_opt('lizenz_mail')) . ' gibt es kein aktives Abo. Der Rechner läuft ohne Anfrageformular und PDF, Updates sind pausiert. <a href="https://s-energies.de/foerdercheck-fuer-energieberater/" target="_blank">Abo abschließen</a> oder <a href="' . esc_url($link) . '">E-Mail-Adresse prüfen</a>.';
  echo '<div class="notice notice-warning"><p><b>Fördercheck Pro:</b> ' . $text . '</p></div>';
});
