/* Fördercheck Pro 1.8: passt Farben, Schriften und Ecken des Rechners an das Design der Website an.
   Liest die Werte, die das Theme im Browser tatsächlich anwendet (funktioniert mit jedem Theme),
   und bevorzugt dabei die Farbpaletten bekannter Themes und Baukästen. Einstellungen aus
   „Einstellungen → Fördercheck“ (SFC_CFG.design) haben immer Vorrang. */
(function () {
  if (window.SFC_DESIGN_START) { window.SFC_DESIGN_START(); return; } // zweiter Rechner auf derselben Seite
  var CFG = window.SFC_DESIGN || {};

  function rgb(c) {
    if (!c) return null;
    c = String(c).trim();
    if (c.charAt(0) === '#') {
      var h = c.slice(1); if (h.length === 3) h = h.replace(/./g, '$&$&');
      if (!/^[0-9a-f]{6}/i.test(h)) return null;
      return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16), 1];
    }
    var m = c.match(/rgba?\(([^)]+)\)/);
    if (!m) return null;
    var p = m[1].split(/[\s,\/]+/).filter(Boolean).map(parseFloat);
    return [p[0], p[1], p[2], p.length > 3 ? p[3] : 1];
  }
  function hex(a) { return '#' + a.slice(0, 3).map(function (v) { return ('0' + Math.round(v).toString(16)).slice(-2); }).join(''); }
  function lum(a) { return a.slice(0, 3).map(function (v) { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); }).reduce(function (s, v, i) { return s + v * [.2126, .7152, .0722][i]; }, 0); }
  function kontrast(a, b) { var x = lum(a), y = lum(b); return (Math.max(x, y) + .05) / (Math.min(x, y) + .05); }
  function mix(a, b, t) { return [0, 1, 2].map(function (i) { return a[i] * t + b[i] * (1 - t); }).concat(1); }
  function satt(a) { var mx = Math.max(a[0], a[1], a[2]), mn = Math.min(a[0], a[1], a[2]); return mx === 0 ? 0 : (mx - mn) / mx; }
  function sichtbar(a) { return a && a[3] > .5; }

  var root = getComputedStyle(document.documentElement);
  function themeVar(namen) {
    for (var i = 0; i < namen.length; i++) {
      var v = rgb(root.getPropertyValue(namen[i]));
      if (!v && document.body) v = rgb(getComputedStyle(document.body).getPropertyValue(namen[i]));
      if (sichtbar(v)) return v;
    }
    return null;
  }

  // Probe-Elemente im Inhaltsbereich des Themes (dort, wo der Rechner steht), damit die Theme-Stile greifen
  function probe(ort, tag, cls) {
    var el = document.createElement(tag);
    if (cls) el.className = cls;
    el.textContent = 'Fördercheck';
    if (tag === 'a') el.href = '#';
    el.setAttribute('aria-hidden', 'true');
    el.style.cssText = 'position:absolute!important;left:-9999px!important;top:0!important;visibility:hidden!important';
    ort.appendChild(el);
    var s = getComputedStyle(el), r = { farbe: rgb(s.color), hg: rgb(s.backgroundColor), schrift: s.fontFamily, radius: s.borderTopLeftRadius, gewicht: s.fontWeight };
    el.remove();
    return r;
  }

  function hintergrund(el) {
    while (el && el !== document.documentElement) {
      var b = rgb(getComputedStyle(el).backgroundColor);
      if (sichtbar(b)) return b;
      el = el.parentElement;
    }
    var h = rgb(getComputedStyle(document.documentElement).backgroundColor);
    return sichtbar(h) ? h : [255, 255, 255, 1];
  }

  function anwenden(box) {
    var ort = box.parentElement || document.body;
    var B = rgb(CFG.hintergrund) || hintergrund(ort);
    var T = rgb(CFG.text) || rgb(getComputedStyle(ort).color) || [40, 40, 40, 1];
    var hell = lum(B) > .4;
    if (kontrast(T, B) < 3.5) T = hell ? [34, 34, 34, 1] : [240, 240, 240, 1];
    var h2 = probe(ort, 'h2'), link = probe(ort, 'a');
    var H = h2.farbe && kontrast(h2.farbe, B) >= 3 ? h2.farbe : T;

    // Akzent: Einstellung > Theme-Palette > Knopf des Themes > Linkfarbe
    var A = rgb(CFG.akzent) || themeVar(['--e-global-color-accent', '--e-global-color-primary', '--ast-global-color-0', '--global-palette1',
      '--wp--preset--color--primary', '--wp--preset--color--accent', '--theme-palette-color-1']) || rgb(CFG.theme_akzent);
    // Knopf des Themes: erster Probe-Knopf mit sichtbarem Hintergrund (liefert Farbe und Eckenradius)
    var knopf = null, knopfKlassen = ['wp-element-button', 'wp-block-button__link', 'elementor-button', 'button', 'btn'];
    for (var i = 0; i < knopfKlassen.length && !knopf; i++) {
      var k = probe(ort, 'a', knopfKlassen[i]);
      if (sichtbar(k.hg) && kontrast(k.hg, B) > 1.3) knopf = k;
    }
    if (!A && knopf && satt(knopf.hg) > .2 && kontrast(knopf.hg, B) > 1.6) A = knopf.hg;
    if (!A && link.farbe && satt(link.farbe) > .2) A = link.farbe;
    if (!A) A = rgb(CFG.ersatz) || [15, 107, 85, 1];
    var AI = kontrast([255, 255, 255, 1], A) >= kontrast([20, 20, 20, 1], A) ? [255, 255, 255, 1] : [20, 20, 20, 1];
    var AT = kontrast(A, B) >= 3 ? A : H; // Akzent als Schriftfarbe nur, wenn gut lesbar

    // Schrift und Ecken
    var body = CFG.schrift === 'system' ? 'system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif' : getComputedStyle(ort).fontFamily;
    var display = CFG.schrift === 'system' ? body : (h2.schrift || body);
    var r;
    if (CFG.ecken === 'eckig') r = 0;
    else if (CFG.ecken === 'rund') r = 10;
    else r = Math.min(knopf ? parseFloat(knopf.radius) || 0 : parseFloat(probe(ort, 'button', '').radius) || 0, 14);

    var v = {
      '--d-bg': hex(B), '--d-text': hex(T), '--d-ink': hex(H), '--d-accent': hex(A), '--d-accent-ink': hex(AI), '--d-accent-text': hex(AT),
      '--d-panel': hex(mix(T, B, .03)), '--d-field': hex(mix(T, B, hell ? .05 : .1)), '--d-line': hex(mix(T, B, .18)),
      '--d-muted': hex(mix(T, B, .68)), '--d-soft': hex(mix(A, B, .12)), '--d-box': hex(hell ? mix(T, B, 0) : mix(T, B, .05)),
      '--d-body': body, '--d-display': display, '--d-r': r + 'px', '--d-r-box': Math.round(r * 1.4) + 'px'
    };
    for (var n in v) box.style.setProperty(n, v[n]);
    box.classList.add('sfc-design');
  }

  var NAMEN = ['--d-bg', '--d-text', '--d-ink', '--d-accent', '--d-accent-ink', '--d-accent-text', '--d-panel', '--d-field', '--d-line', '--d-muted', '--d-soft', '--d-box', '--d-body', '--d-display', '--d-r', '--d-r-box'];
  function start() {
    document.querySelectorAll('.sfc').forEach(function (b) {
      NAMEN.forEach(function (n) { b.style.removeProperty(n); });
      b.classList.remove('sfc-design');
      var k = b.querySelector('.sfk');
      [b, k].forEach(function (x) { if (x) ['--accent', '--sel'].forEach(function (n) { x.style.removeProperty(n); }); });
      if (CFG.modus === 'aus') {
        // eigenes Design des Rechners, nur die Akzentfarbe aus den Einstellungen (in der Vorschau sofort sichtbar)
        if (CFG.vorschau && CFG.akzent) [b, k].forEach(function (x) { if (x) { x.style.setProperty('--accent', CFG.akzent); if (x === k) x.style.setProperty('--sel', CFG.akzent); } });
        return;
      }
      try { anwenden(b); } catch (e) {}
    });
  }
  // Vorschau in „Einstellungen → Fördercheck“: die Einstellungsseite schickt ungespeicherte Werte in den Vorschau-Rahmen
  window.addEventListener('message', function (e) {
    if (e.origin !== location.origin || !e.data || !e.data.sfcDesign) return;
    CFG = Object.assign({ theme_akzent: CFG.theme_akzent }, e.data.sfcDesign); start();
  });
  window.SFC_DESIGN_START = start;
  // läuft direkt nach dem Rechner (kein Aufblitzen der Standardfarben) und nach dem Laden noch einmal, falls das Theme spät Stile setzt
  start();
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  window.addEventListener('load', start);
})();
