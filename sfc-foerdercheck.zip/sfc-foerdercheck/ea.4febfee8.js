/* sENERGIEs Online-Verbrauchsausweis: Zulässigkeitsprüfung, Datenerfassung, Sofort-Ergebnis, Auftrag (Server baut daraus die EVEBI-Projektdatei .evea) */
(function () {
  const C = Object.assign({ preview: false, endpoint: '', adresse: '', anfrage: '', preis: '59 €', preis_express: '79 €', zahlungslink: '', zahlungslink_express: '', partnerlink: '', region: ['9054', '9055', '910', '912', '913', '954', '960'], datenschutz: '/datenschutzerklaerung/', bild: '' }, window.SEA_CFG || {});
  const $ = id => document.getElementById('sea-' + id);
  const q = (s, r = document) => r.querySelector(s);
  if (!$('f')) return;

  // Energieträger: Code wie in der EVEBI-Schnittstelle, Einheit auf der Abrechnung, Umrechnung in kWh (Heizwert)
  const ETR = {
    gas: ['Erdgas', 'BK_GAS', 'kWh', 1], oel: ['Heizöl', 'BK_OEL', 'Liter', 10], fluessig: ['Flüssiggas', 'BK_FLUESSIGGAS', 'Liter', 6.57],
    pellet: ['Holzpellets', 'BK_PELLET', 'kg', 4.9], holz: ['Scheitholz', 'BK_HOLZ', 'Ster', 1750], hhs: ['Hackschnitzel', 'BK_HHS', 'Schüttraummeter', 750],
    wp: ['Wärmepumpe (Strom)', 'BK_STROM', 'kWh', 1], strom: ['Strom direkt / Infrarot', 'BK_STROM', 'kWh', 1], nacht: ['Nachtspeicher', 'BK_NACHTSTR', 'kWh', 1],
    fw: ['Fernwärme', 'BK_NONE', 'kWh', 1]
  };

  const HEAD = 'BOM;ID;Anlass;PLZ;Ort;Straße;Hausnr;isGebaeudehuelle;Baujahr;Wohneinheiten;Wohnfläche;gebaeudeteil;Keller_beheizt;bilderStreams_0;bilderStreams_1;bilderStreams_2;Klimatisiert;kuehlWfl;passiveKuehlung;fernKuehlung;stromKuehlung;waermeKuehlung;kaiAnzahl;kaiDatum;baujahrHzErz;TW_Solar;HZ_Solar;TW_WP;HZ_WP;Fensterlüftung;Schachtlüftung;L_Mit_WRG;L_Ohne_WRG;Modernisierung;Dach1_Dämmung;Wand1_Dämmung;Boden1_Dämmung;bjFensterAustausch;ETr1_Kategorie;ETr1_Anteil_erneuerbar;ETr1_Anteil_KWK;ETr1_isFw;ETr1_gebaeudeNahErzeugt;ETr1_Jahr1_von;ETr1_Jahr1_bis;ETr1_Jahr1_Menge;ETr1_TWW;ETr1_Jahr1_Menge_TWW;ETr1_Jahr1_Leerstand;ETr1_Jahr2_von;ETr1_Jahr2_bis;ETr1_Jahr2_Menge;ETr1_Jahr2_Menge_TWW;ETr1_Jahr2_Leerstand;ETr1_Jahr3_von;ETr1_Jahr3_bis;ETr1_Jahr3_Menge;ETr1_Jahr3_Menge_TWW;ETr1_Jahr3_Leerstand;ETr1_PrimFaktor;ETr2_Kategorie;ETr2_Jahr1_von;ETr2_Jahr1_bis;ETr2_Jahr1_Menge;ETr2_TWW;ETr2_Jahr1_Menge_TWW;ETr2_Jahr1_Leerstand;ETr2_Jahr2_von;ETr2_Jahr2_bis;ETr2_Jahr2_Menge;ETr2_Jahr2_Menge_TWW;ETr2_Jahr2_Leerstand;ETr2_Jahr3_von;ETr2_Jahr3_bis;ETr2_Jahr3_Menge;ETr2_Jahr3_Menge_TWW;ETr2_Jahr3_Leerstand;ETr1_Heizung;ETr2_Heizung;ETr2_PrimFaktor;Gebäudetyp;Datenerhebung;BedarfVerbrauch;ETr2_Anteil_KWK;ETr2_Anteil_erneuerbar;ETr2_isFw;ETr2_gebaeudeNahErzeugt'.split(';');
  const KHEAD = ['Kunden_Anrede', 'Kunden_Vorname', 'Kunden_Nachname', 'Kunden_Straße', 'Kunden_Hausnr', 'Kunden_PLZ', 'Kunden_Ort', 'Kunden_email', 'Kunden_telefon'];
  // feste Werte wie in der Envisys-Musterdatei EA_Verbrauch_WG; Datenerhebung 0 = Eigentümer
  const DEF = { isGebaeudehuelle: '1', kuehlWfl: '0', passiveKuehlung: '0', fernKuehlung: '0', stromKuehlung: '0', waermeKuehlung: '0', kaiAnzahl: '0', kaiDatum: '00.01.1900', TW_WP: '0', HZ_WP: '0', ETr1_Anteil_erneuerbar: '0', ETr1_Anteil_KWK: '0', ETr1_gebaeudeNahErzeugt: '0', ETr1_Heizung: '1', ETr2_TWW: '1', ETr2_Jahr1_Menge_TWW: '-', ETr2_Jahr2_Menge_TWW: '-', ETr2_Jahr3_Menge_TWW: '-', ETr2_Heizung: '1', Gebäudetyp: '0', Datenerhebung: '0', BedarfVerbrauch: 'V', ETr2_Anteil_KWK: '#NV', ETr2_Anteil_erneuerbar: '#NV', ETr2_isFw: '#NV', ETr2_gebaeudeNahErzeugt: '#NV' };

  const num = s => { s = String(s ?? '').trim(); if (!s) return NaN; if (/,/.test(s)) s = s.replace(/\./g, '').replace(',', '.'); else if (/^\d{1,3}(\.\d{3})+$/.test(s)) s = s.replace(/\./g, ''); return parseFloat(s); };
  const de = (n, d = 0) => isFinite(n) ? (Math.round(n * 10 ** d) / 10 ** d).toString().replace('.', ',') : '';
  const pd = s => { const m = /^(\d{1,2})\.(\d{1,2})\.(\d{4})$/.exec(String(s).trim()); if (!m) return null; const d = new Date(+m[3], m[2] - 1, +m[1]); return d.getDate() === +m[1] ? d : null; };
  const fd = d => `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}.${d.getFullYear()}`;
  const tag = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
  const val = id => ($(id).value || '').trim();
  const radio = () => (q('input[name=sea-wsv]:checked') || {}).value;
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  // Kacheln: Knopf setzt den Wert des versteckten Felds (gleiche IDs wie früher die Auswahlfelder)
  const txt = id => { const b = q(`.sea-chips[data-for="sea-${id}"] [aria-pressed="true"]`); return b ? b.textContent : $(id).value; };
  function chipsSync() {
    document.querySelectorAll('.sea-chips').forEach(g => g.querySelectorAll('button').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.v === document.getElementById(g.dataset.for).value))));
    const fe = $('fenart').value === 'e'; $('fenjahr').hidden = !fe;
    ['ddach', 'dwand', 'dboden'].forEach(k => { const an = $(k + 'j').value === '1'; $(k).closest('label').hidden = !an; if (!an) $(k).value = ''; });
    const z2 = $('zw2').value; $('zweit').checked = z2 !== ''; if (z2) $('etr2').value = z2;
    if (typeof einheiten === 'function') einheiten();
    const so = $('sol').value; $('twsol').value = so === '0' ? '0' : '1'; $('hzsol').value = so === 'hz' ? '1' : '0';
  }
  document.addEventListener('click', ev => {
    const b = ev.target.closest('.sea-chips button'); if (!b || !b.closest('#sea')) return;
    const f = document.getElementById(b.parentElement.dataset.for); f.value = b.dataset.v;
    chipsSync();
    if (/^sea-d(dach|wand|boden)j$/.test(f.id) && f.value === '1' && !$(f.id.slice(4, -1)).value && typeof radAuf === 'function') radAuf($(f.id.slice(4, -1))); f.dispatchEvent(new Event('input', { bubbles: true })); f.dispatchEvent(new Event('change', { bubbles: true }));
  });
  // Pflichtfelder rot umranden: el = ID ohne „sea-“ oder Element; Häkchen/Optionsgruppen markieren ihre Zeile
  function markiere(sec, liste) {
    sec.querySelectorAll('.sea-err').forEach(x => x.classList.remove('sea-err'));
    const els = liste.map(x => typeof x === 'string' ? $(x) : x).filter(Boolean).map(x => x.type === 'checkbox' ? x.closest('label') : x);
    els.forEach(x => x.classList.add('sea-err'));
    if (els[0]) { const t = els[0].getBoundingClientRect().top + scrollY - 120; if (t < scrollY) scrollTo({ top: t }); if (els[0].focus && els[0].tagName === 'INPUT') els[0].focus({ preventScroll: true }); }
  }
  document.addEventListener('input', ev => { const x = ev.target; if (!x.closest || !x.closest('#sea')) return; x.classList.remove('sea-err'); const l = x.closest('.sea-err'); if (l) l.classList.remove('sea-err'); }, true);
  document.addEventListener('change', ev => { const x = ev.target; if (!x.closest || !x.closest('#sea')) return; x.classList.remove('sea-err'); const l = x.closest('.sea-err'); if (l) l.classList.remove('sea-err'); }, true);
  const imRegion = plz => C.region.some(p => plz.startsWith(p));
  let step = 1;

  if (C.preview) { $('tag').hidden = false; $('vorschau').hidden = false; }
  if (C.bild) q('.sea-kopf').style.backgroundImage = `linear-gradient(rgba(44,41,39,.78),rgba(44,41,39,.78)),url("${C.bild}")`;
  $('preis').textContent = C.preis;
  const eur = s => parseFloat(String(s).replace(/[^\d,]/g, '').replace(',', '.')) || 0;
  $('xauf').textContent = de(eur(C.preis_express) - eur(C.preis)) + ' €';
  $('pn').textContent = C.preis; $('px').textContent = C.preis_express;
  if (C.zahlungslink && !C.zahlungslink_express) { $('tx').hidden = true; $('kx').hidden = true; }
  document.querySelectorAll('input[name="sea-lief"]').forEach(r => r.addEventListener('change', () => {
    $('express').checked = r.value === 'x' && r.checked;
    $('preis').textContent = $('express').checked ? C.preis_express : C.preis;
    $('lief-t').textContent = $('express').checked ? 'Express: innerhalb von 24 Stunden an Werktagen' : 'Standard-Lieferung';
  }));
  $('dslink').href = $('dslink2').href = C.datenschutz;

  // ---------- Schritt 1: Zulässigkeit (GModG) ----------
  function pruefung() {
    const we = +val('we') || 0, bj = +val('bj') || 0, plz = val('lplz');
    const alt = we > 0 && we < 5 && bj > 0 && bj < 1978;
    $('f77').hidden = !alt;
    const r = radio();
    let grund = '';
    if ($('art').value === 'nwg') grund = 'Online biete ich den Verbrauchsausweis nur für Wohngebäude an.';
    else if ($('anlass').value === 'AG_NEUBAU') grund = 'Für einen Neubau ist immer ein Bedarfsausweis nötig.';
    else if ($('3j').value === '0') grund = 'Für einen Verbrauchsausweis braucht es die Verbrauchswerte von 3 zusammenhängenden Jahren. Ohne diese ist ein Bedarfsausweis nötig.';
    else if (alt && r === '0') grund = 'Für Ihr Haus schreibt das Gebäudemodernisierungsgesetz (GModG) einen Bedarfsausweis vor. Dafür ist ein Termin vor Ort nötig.';
    const fertig = we > 0 && bj > 1800 && (!alt || r !== undefined);
    $('lplzw').hidden = !grund || $('art').value === 'nwg';
    const u = $('urteil');
    if ($('art').value === 'nwg') {
      u.hidden = false; u.className = 'sea-urteil no'; $('lead').hidden = true;
      u.innerHTML = '<b>Online leider nicht möglich.</b> Für Gewerbe-, Büro- und andere Nichtwohngebäude biete ich den Online-Ausweis nicht an. ' + (C.partnerlink
        ? `<br><small>Anzeige</small><br>Ein Energieberater in Ihrer Nähe erstellt den Ausweis: <a href="${esc(C.partnerlink)}" target="_blank" rel="sponsored noopener">kostenlos Angebote anfordern</a>.`
        : 'Einen passenden Energieberater finden Sie in der <a href="https://www.energie-effizienz-experten.de/" target="_blank" rel="noopener">Energieeffizienz-Expertenliste</a>.');
      return false;
    }
    if (!grund && !fertig) { u.hidden = true; $('lead').hidden = true; return false; }
    u.hidden = false;
    if (!grund) { u.className = 'sea-urteil'; u.innerHTML = '<b>Passt.</b> Ein Verbrauchsausweis ist für Ihr Gebäude zulässig.'; $('lead').hidden = true; return true; }
    u.className = 'sea-urteil no';
    const reg = /^\d{5}$/.test(plz) && imRegion(plz);
    u.innerHTML = '<b>Online leider nicht möglich.</b> ' + grund + ' ' + (reg
      ? 'Ihr Haus liegt in meinem Einzugsgebiet, ich erstelle den Bedarfsausweis gern vor Ort.'
      : (/^\d{5}$/.test(plz) ? 'Ihr Haus liegt außerhalb meines Einzugsgebiets. ' + (C.partnerlink
        ? `<br><small>Anzeige</small><br>Ein Energieberater in Ihrer Nähe erstellt den Bedarfsausweis: <a href="${esc(C.partnerlink)}" target="_blank" rel="sponsored noopener">kostenlos Angebote anfordern</a>.`
        : 'Einen Energieberater in Ihrer Nähe finden Sie in der <a href="https://www.energie-effizienz-experten.de/" target="_blank" rel="noopener">Energieeffizienz-Expertenliste</a>.') : 'Bitte geben Sie unten noch die Postleitzahl des Gebäudes an.'));
    $('lead').hidden = !reg;
    return false;
  }
  ['art', 'anlass', 'we', 'bj', 'lplz', '3j'].forEach(id => $(id).addEventListener('input', pruefung));
  document.querySelectorAll('input[name=sea-wsv]').forEach(x => x.addEventListener('change', pruefung));

  $('lsend').addEventListener('click', async () => {
    const m = $('lmsg'); m.className = 'sea-msg';
    if (!val('lname') || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(val('lmail'))) { m.textContent = 'Bitte Name und E-Mail angeben.'; return; }
    if (!$('lds').checked) { m.textContent = 'Bitte der Speicherung zustimmen.'; return; }
    const angaben = `Bedarfsausweis nötig (Online-Verbrauchsausweis): ${txt('art')}, ${val('we')} WE, Baujahr ${val('bj')}, Anlass ${txt('anlass')}, 3 Jahre Verbrauch: ${$('3j').value === '1' ? 'ja' : 'nein'}, WSchV 77: ${radio() === '1' ? 'ja' : radio() === 'n' ? 'Bauantrag ab 11/1977' : 'nein/unklar'}`;
    if (!C.anfrage) { m.className = 'sea-msg gut'; m.textContent = 'Vorschau: Diese Anfrage ginge jetzt an info@s-energies.de. ' + angaben; return; }
    $('lsend').disabled = true;
    try {
      const r = await fetch(C.anfrage, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: val('lname'), mail: val('lmail'), tel: val('ltel'), plz: val('lplz'), wunsch: 'Bedarfsausweis', angaben, website: val('hp') }) });
      if (!r.ok) throw 0;
      m.className = 'sea-msg gut'; m.textContent = 'Danke! Ihre Anfrage ist angekommen, ich melde mich innerhalb von zwei Werktagen.';
    } catch (e) { m.textContent = 'Das hat leider nicht geklappt. Bitte schreiben Sie an info@s-energies.de.'; $('lsend').disabled = false; }
  });

  // ---------- Schritt 2 ----------
  function check2() {
    const f = [];
    const e = [];
    if (!val('str') || !val('hnr') || !val('ort') || !/^\d{5}$/.test(val('plz'))) { f.push('Adresse des Gebäudes'); e.push(...['str', 'hnr', 'ort'].filter(k => !val(k)), ...(/^\d{5}$/.test(val('plz')) ? [] : ['plz'])); }
    if (!(+val('bjhz') > 1900)) { f.push('Baujahr der Heizung'); e.push('bjhz'); }
    ['ddach', 'dwand', 'dboden'].forEach(k => { if ($(k + 'j').value === '1' && !(+val(k) > 0)) { f.push('Dämmstärke'); e.push(k); } });
    { const x = $('foto1').files[0]; if (x && x.size > 8e6) { f.push('Foto vom Typenschild ist größer als 8 MB'); e.push('foto1'); } }
    const w = num(val('wfl')), we = +val('we') || 1;
    if (!(w > 0)) { f.push('Wohnfläche'); e.push('wfl'); }
    if ($('fenart').value === 'e' && !(+val('bjfen') > 1900)) { f.push('Jahr des Fenstertauschs (ungefähr reicht)'); e.push('bjfen'); }
    markiere(q('section[data-step="2"]'), e);
    $('msg2').textContent = f.length ? 'Bitte ergänzen: ' + f.join(', ') + '.' : '';
    if (!f.length && (w / we < 20 || w / we > 400)) $('msg2').textContent = `Hinweis: ${de(w / we)} m² pro Wohnung ist ungewöhnlich. Bitte die Wohnfläche prüfen.`;
    return !f.length;
  }

  // ---------- Schritt 3: Verbrauch ----------
  function perioden() {
    const tb = $('perioden'), j = new Date().getFullYear() - 1;
    tb.innerHTML = [0, 1, 2].map(i => `<tr><td class="sea-jt" colspan="5">Jahr ${i + 1}</td></tr><tr>
      <td data-l="von"><input id="sea-von${i}" value="01.01.${j - 2 + i}" placeholder="TT.MM.JJJJ" aria-label="Zeitraum ${i + 1} von"></td>
      <td data-l="bis"><input id="sea-bis${i}" value="31.12.${j - 2 + i}" placeholder="TT.MM.JJJJ" aria-label="Zeitraum ${i + 1} bis"></td>
      <td data-l="Verbrauch" class="sea-m1"><input id="sea-m${i}" inputmode="decimal" aria-label="Verbrauch Zeitraum ${i + 1}"></td>
      <td class="sea-z2" data-l="2. Wärmequelle" hidden><input id="sea-n${i}" inputmode="decimal" aria-label="Zweite Heizung Zeitraum ${i + 1}"></td>
      <td data-l="Leerstand %"><input id="sea-l${i}" inputmode="decimal" placeholder="0" aria-label="Leerstand Zeitraum ${i + 1}"></td></tr>`).join('');
    [0, 1].forEach(i => $('bis' + i).addEventListener('change', () => {
      const b = pd(val('bis' + i)); if (!b) return;
      const v = tag(b, 1); $('von' + (i + 1)).value = fd(v);
      $('bis' + (i + 1)).value = fd(tag(new Date(v.getFullYear() + 1, v.getMonth(), v.getDate()), -1));
      $('bis' + (i + 1)).dispatchEvent(new Event('change'));
    }));
    $('von0').addEventListener('change', () => { const v = pd(val('von0')); if (v) { $('bis0').value = fd(tag(new Date(v.getFullYear() + 1, v.getMonth(), v.getDate()), -1)); $('bis0').dispatchEvent(new Event('change')); } });
  }
  function einheiten() {
    $('einheit').textContent = ETR[$('etr').value][2];
    const z = $('zweit').checked;
    $('th2').hidden = !z; $('name2').textContent = ETR[$('etr2').value][0];
    document.querySelectorAll('.sea-m1').forEach(td => td.dataset.l = `${ETR[$('etr').value][0]} (${ETR[$('etr').value][2]})`);
    document.querySelectorAll('.sea-z2').forEach(td => td.dataset.l = `${ETR[$('etr2').value][0]} (${ETR[$('etr2').value][2]})`);
    document.querySelectorAll('.sea-z2').forEach(td => td.hidden = !z);
    $('einheit2').textContent = ETR[$('etr2').value][2];
  }
  ['etr', 'etr2', 'zweit'].forEach(id => $(id).addEventListener('change', einheiten));

  function check3() {
    const f = [], e = []; let prev = null;
    const z = $('zweit').checked;
    for (let i = 0; i < 3; i++) {
      const a = pd(val('von' + i)), b = pd(val('bis' + i)), m = num(val('m' + i)), l = num(val('l' + i) || '0');
      if (!(m > 0)) { f.push(`Zeitraum ${i + 1}: Verbrauch fehlt.`); e.push('m' + i); }
      if (z && !(num(val('n' + i)) >= 0)) { f.push(`Zeitraum ${i + 1}: Verbrauch der zweiten Wärmequelle fehlt (0 ist erlaubt).`); e.push('n' + i); }
      if (!(l >= 0 && l <= 100)) { f.push(`Zeitraum ${i + 1}: Leerstand zwischen 0 und 100 %.`); e.push('l' + i); }
      if (!a || !b) { f.push(`Zeitraum ${i + 1}: Datum bitte als TT.MM.JJJJ.`); e.push(...(a ? [] : ['von' + i]), ...(b ? [] : ['bis' + i])); continue; }
      if (b <= a) { f.push(`Zeitraum ${i + 1}: „bis“ liegt vor „von“.`); e.push('bis' + i); }
      const tage = (b - a) / 864e5 + 1;
      if (tage < 300 || tage > 430) { f.push(`Zeitraum ${i + 1} sollte etwa ein Jahr umfassen.`); e.push('bis' + i); }
      if (prev && Math.round((a - prev) / 864e5) !== 1) { f.push(`Zeitraum ${i + 1} schließt nicht direkt an Zeitraum ${i} an.`); e.push('von' + i); }
      prev = b;
    }
    if (prev && (Date.now() - prev) / 864e5 > 548) { f.push('Der letzte Zeitraum endet vor mehr als 18 Monaten. Bitte die neueste Abrechnung verwenden.'); e.push('bis2'); }
    markiere(q('section[data-step="3"]'), e);
    let hinweis = '';
    if (!f.length) {
      const e = ETR[$('etr').value], e2 = ETR[$('etr2').value], wfl = num(val('wfl'));
      const kwh = [0, 1, 2].reduce((s, i) => s + num(val('m' + i)) * e[3] + (z ? num(val('n' + i)) * e2[3] : 0), 0) / 3 / wfl;
      const min = $('etr').value === 'wp' ? 8 : 30;
      if (kwh < min || kwh > 400) hinweis = `Hinweis: ${Math.round(kwh)} kWh pro m² und Jahr ist ungewöhnlich. Bitte Menge und Einheit prüfen. Sie können trotzdem weitermachen.`;
    }
    $('msg3').textContent = f.length ? f.join(' ') : hinweis;
    ergebnis(f.length ? null : kennwert());
    return !f.length;
  }

  // ---------- Sofort-Ergebnis: vorläufiger Kennwert ohne Klimabereinigung ----------
  // Bezugsfläche wie im Verbrauchsausweis: AN = 1,2 × Wohnfläche (1,35 bei 1–2 Wohnungen mit beheiztem Keller)
  const KL = [['A+', 30, '#1a8a3a'], ['A', 50, '#3fa535'], ['B', 75, '#8cbf26'], ['C', 100, '#c6d21c'], ['D', 130, '#f0e216'], ['E', 160, '#f6b915'], ['F', 200, '#ef8a1b'], ['G', 250, '#e2531f'], ['H', Infinity, '#c8191f']];
  function kennwert() {
    const e = ETR[$('etr').value], e2 = ETR[$('etr2').value], z = $('zweit').checked, wfl = num(val('wfl')), we = +val('we') || 1;
    const an = wfl * (we <= 2 && $('keller').value === '1' ? 1.35 : 1.2);
    let sum = 0;
    for (let i = 0; i < 3; i++) {
      const l = Math.min(num(val('l' + i) || '0') || 0, 90) / 100;
      sum += (num(val('m' + i)) * e[3] + (z ? (num(val('n' + i)) || 0) * e2[3] : 0)) / (1 - l);
    }
    let k = sum / 3 / an;
    if ($('tww').value === '0') k += 20; // Warmwasser getrennt: Pauschale 20 kWh/(m²·a)
    if (!isFinite(k) || k <= 0) return null;
    const i = KL.findIndex(x => k < x[1]);
    return { k, kl: KL[i][0], i };
  }
  function empfehlung() {
    const jahr = new Date().getFullYear(), bj = +val('bj') || 0, hz = +(val('bjhz') || val('hzper')) || 0, fe = $('fenart').value === 'e' ? (+val('bjfen') || 0) : 0;
    const fossil = ['gas', 'oel', 'fluessig'].includes($('etr').value), alt = bj && bj < 1995;
    const dach = +val('ddach') > 0, wand = +val('dwand') > 0, boden = +val('dboden') > 0;
    if (fossil && hz && jahr - hz >= 20) return `Die Heizung ist ${jahr - hz} Jahre alt: Umstieg auf erneuerbare Wärme planen, Förderung bis zu 70 %.`;
    if (alt && !dach) return 'Empfehlung: oberste Geschossdecke bzw. Dach dämmen, das senkt den Verbrauch mit wenig Aufwand.';
    if (alt && fe && fe < 1995) return `Empfehlung: Fenster von ${fe} gegen Dreifachverglasung tauschen.`;
    if (alt && !boden) return 'Empfehlung: Kellerdecke dämmen, das senkt den Verbrauch mit wenig Aufwand.';
    if (alt && !wand) return 'Empfehlung: Außenwand dämmen, am besten zusammen mit anderen Arbeiten an der Fassade.';
    if (fossil) return 'Empfehlung: hydraulischen Abgleich prüfen; beim nächsten Heizungstausch auf erneuerbare Wärme umsteigen.';
    return 'Für die nächsten Schritte empfehle ich einen individuellen Sanierungsfahrplan (iSFP).';
  }
  function skala(r) {
    return `<div class="sea-skala">${KL.map((x, j) => `<span style="background:${x[2]}"${j === r.i ? ' class="on"' : ''}>${x[0]}</span>`).join('')}</div>`;
  }
  function ergebnis(r) {
    const b = $('sofort'); if (!b) return;
    if (!r) { b.hidden = true; return; }
    b.hidden = false;
    b.innerHTML = `<b>Ihr vorläufiges Ergebnis</b>${skala(r)}<p>Endenergieverbrauch rund <b>${de(r.k)} kWh pro m² und Jahr</b>, das entspricht etwa Klasse <b>${r.kl}</b>.</p><p>${esc(empfehlung())}</p><p class="sea-hint">Vorläufig, ohne Klimabereinigung. Im fertigen Ausweis rechne ich mit den Klimafaktoren des Deutschen Wetterdienstes für Ihren Standort, dadurch kann sich die Klasse noch um eine Stufe verschieben.</p>`;
  }
  ['m0', 'm1', 'm2', 'n0', 'n1', 'n2', 'l0', 'l1', 'l2'].forEach(id => document.addEventListener('input', ev => { if (ev.target.id === 'sea-' + id) { const ok = [0, 1, 2].every(i => num(val('m' + i)) > 0); ergebnis(ok ? kennwert() : null); } }));

  // ---------- Schritt 4 ----------
  function check4() {
    const f = [], e = [];
    if (!val('nachname')) { f.push('Name'); e.push('nachname'); }
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(val('email'))) { f.push('gültige E-Mail'); e.push('email'); }
    if (!val('tel')) { f.push('Telefon'); e.push('tel'); }
    if ($('andere').checked && (!val('kstr') || !/^\d{5}$/.test(val('kplz')) || !val('kort'))) { f.push('Rechnungsadresse'); e.push(...['kstr', 'kort'].filter(k => !val(k)), ...(/^\d{5}$/.test(val('kplz')) ? [] : ['kplz'])); }
    if (!C.preview && !$('foto0').files[0]) { f.push('Foto der Hausansicht'); e.push('foto0'); }
    [0, 1].forEach(i => { const x = $('foto' + i).files[0]; if (x && x.size > 8e6) f.push(`Foto ${i + 1} ist größer als 8 MB`); });
    const bl = [...$('belege').files];
    if (bl.length > 5) f.push('höchstens 5 Abrechnungen');
    if (bl.some(x => x.size > 8e6)) f.push('Abrechnungen einzeln höchstens 8 MB');
    const ges = [0, 1].reduce((t, i) => t + ($('foto' + i).files[0]?.size || 0), 0) + bl.reduce((t, x) => t + x.size, 0);
    if (ges > 20e6) f.push('alle Dateien zusammen höchstens 20 MB (Fotos bitte kleiner speichern)');
    if (!$('wahr').checked) { f.push('Bestätigung der Angaben'); e.push('wahr'); }
    if (!$('ds').checked) { f.push('Datenschutz'); e.push('ds'); }
    if (!$('widerruf').checked) { f.push('Zustimmung zum Beginn vor Ende der Widerrufsfrist'); e.push('widerruf'); }
    markiere(q('section[data-step="4"]'), e);
    $('msg4').textContent = f.length ? 'Bitte ergänzen: ' + f.join(', ') + '.' : '';
    return !f.length;
  }

  // ---------- CSV ----------
  const clean = s => String(s ?? '').replace(/[;\r\n\t"]/g, ' ').replace(/^[=+@]+/, '').trim();
  function daten() {
    const k = $('etr').value, e = ETR[k], z = $('zweit').checked, e2 = ETR[$('etr2').value], l = $('lueft').value;
    const id = 'VA' + new Date().toISOString().slice(2, 10).replace(/-/g, '') + '-' + Math.random().toString(36).slice(2, 6).toUpperCase();
    const ext = i => { const x = $('foto' + i) && $('foto' + i).files[0]; return x ? `${id}_${['ansicht', 'heizung', 'fenster'][i]}.${/png$/i.test(x.name) ? 'png' : 'jpg'}` : ''; };
    const v = Object.assign({}, DEF, {
      ID: id, Anlass: $('anlass').value, PLZ: val('plz'), Ort: val('ort'), Straße: val('str'), Hausnr: val('hnr'),
      Baujahr: val('bj'), Wohneinheiten: val('we'), Wohnfläche: de(num(val('wfl')), 2), gebaeudeteil: $('teil').value, Keller_beheizt: $('keller').value,
      bilderStreams_0: ext(0), bilderStreams_1: ext(1), bilderStreams_2: ext(2),
      Klimatisiert: $('klima').value, baujahrHzErz: val('bjhz') || val('hzper'), TW_Solar: $('twsol').value, HZ_Solar: $('hzsol').value,
      HZ_WP: k === 'wp' ? '1' : '0', TW_WP: k === 'wp' && $('tww').value === '1' ? '1' : '0',
      Fensterlüftung: l === 'fenster' ? '1' : '0', Schachtlüftung: l === 'schacht' ? '1' : '0', L_Mit_WRG: l === 'wrg' ? '1' : '0', L_Ohne_WRG: l === 'owrg' ? '1' : '0',
      Modernisierung: val('modern') || '0', Dach1_Dämmung: val('ddach') || '0', Wand1_Dämmung: val('dwand') || '0', Boden1_Dämmung: val('dboden') || '0', bjFensterAustausch: $('fenart').value === 'e' ? (val('bjfen') || '0') : '0',
      ETr1_Kategorie: e[1], ETr1_isFw: k === 'fw' ? '1' : '0', ETr1_TWW: $('tww').value
    });
    [0, 1, 2].forEach(i => {
      const n = i + 1, ls = de((num(val('l' + i)) || 0) / 100, 3);
      v[`ETr1_Jahr${n}_von`] = val('von' + i); v[`ETr1_Jahr${n}_bis`] = val('bis' + i);
      v[`ETr1_Jahr${n}_Menge`] = de(num(val('m' + i)) * e[3]); v[`ETr1_Jahr${n}_Leerstand`] = ls;
      if (z) { v[`ETr2_Jahr${n}_von`] = val('von' + i); v[`ETr2_Jahr${n}_bis`] = val('bis' + i); v[`ETr2_Jahr${n}_Menge`] = de(num(val('n' + i)) * e2[3]); v[`ETr2_Jahr${n}_Leerstand`] = ls; }
    });
    if (z) Object.assign(v, { ETr2_Kategorie: e2[1], ETr2_TWW: '0', ETr2_Anteil_KWK: '0', ETr2_Anteil_erneuerbar: '0', ETr2_isFw: '0', ETr2_gebaeudeNahErzeugt: '0' });
    const a = $('andere').checked;
    const kd = [$('anrede').value, val('vorname'), val('nachname'), a ? val('kstr') : val('str'), a ? val('khnr') : val('hnr'), a ? val('kplz') : val('plz'), a ? val('kort') : val('ort'), val('email'), val('tel')];
    KHEAD.forEach((h, i) => v[h] = kd[i]);
    const kopf = [...HEAD, ...KHEAD], zeile = kopf.map(h => clean(v[h]));
    const roh = [0, 1, 2].map(i => `${val('von' + i)}–${val('bis' + i)}: ${val('m' + i)} ${e[2]} ${e[0]}` + (z ? `, ${val('n' + i) || 0} ${e2[2]} ${e2[0]}` : '') + `, Leerstand ${val('l' + i) || 0} %`);
    const zusatz = { 'Gebäudeart': txt('art'), 'Wärmeschutz 1977': $('f77').hidden ? 'nicht relevant' : ({ '1': 'ja, modernisiert', 'n': 'Bauantrag ab 1.11.1977', '0': 'nein' })[radio()] || '', 'Originalwerte': roh.join(' | '), 'Lieferung': $('express').checked ? 'EXPRESS 24 Stunden (' + C.preis_express + ')' : 'normal (' + C.preis + ')' };
    return { id, v, csv: '﻿' + kopf.join(';') + '\r\n' + zeile.join(';') + '\r\n', zusatz, fotos: [0, 1, 2].map(ext) };
  }

  function uebersicht(d) {
    const e = ETR[$('etr').value];
    $('sum').innerHTML = [['Gebäude', `${val('str')} ${val('hnr')}, ${val('plz')} ${val('ort')}`], ['Baujahr / Wohnungen', `${val('bj')} / ${val('we')}`], ['Wohnfläche', `${val('wfl')} m²`], ['Heizung', e[0] + ($('zweit').checked ? ' + ' + ETR[$('etr2').value][0] : '')], ['Verbrauch', [0, 1, 2].map(i => val('m' + i)).join(' / ') + ' ' + e[2]], ['Kontakt', `${val('vorname')} ${val('nachname')}, ${val('email')}`]]
      .map(([a, b]) => `<dt>${a}</dt><dd>${esc(b)}</dd>`).join('');
    const r = kennwert(); $('sum2').innerHTML = r ? `${skala(r)}<p class="sea-hint">Vorläufig rund ${de(r.k)} kWh/(m²·a), Klasse ${r.kl}. ${esc(empfehlung())}</p>` : '';
    if (C.preview) {
      $('csv').value = d.csv.slice(1);
      $('umrech').textContent = e[3] === 1 ? 'Mengen unverändert in kWh übernommen.' : `Umgerechnet: ${e[2]} × ${de(e[3], 2)} kWh (Heizwert).`;
    }
  }
  $('dl').addEventListener('click', () => {
    const d = daten(); const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([d.csv], { type: 'text/csv;charset=utf-8' })); a.download = d.id + '.csv'; document.body.appendChild(a); a.click(); a.remove();
  });

  $('pay').addEventListener('click', async () => {
    const m = $('msg5'); m.className = 'sea-msg';
    if (!C.endpoint) { m.className = 'sea-msg gut'; m.textContent = 'Vorschau: Hier geht es im Live-Betrieb zur Stripe-Zahlung. Der Auftrag geht als EVEBI-Datei (.evea) mit Fotos und Abrechnungen an info@s-energies.de.'; return; }
    const d = daten(), fd = new FormData();
    fd.append('daten', JSON.stringify({ v: d.v, zusatz: d.zusatz, express: $('express').checked, website: val('hp') }));
    [0, 1].forEach(i => { const x = $('foto' + i).files[0]; if (x) fd.append('foto' + i, x, d.fotos[i]); });
    [...$('belege').files].slice(0, 5).forEach((x, i) => fd.append('beleg' + i, x, x.name));
    $('pay').disabled = true; m.className = 'sea-msg gut'; m.textContent = 'Auftrag wird übertragen …';
    try {
      const r = await fetch(C.endpoint, { method: 'POST', body: fd }); const j = await r.json();
      if (!r.ok || !j.ok) throw new Error(j.fehler || '');
      const z = $('express').checked && C.zahlungslink_express ? C.zahlungslink_express : C.zahlungslink;
      if (z) { m.textContent = 'Weiter zur Zahlung …'; location.href = z + (z.includes('?') ? '&' : '?') + 'client_reference_id=' + encodeURIComponent(j.id) + '&prefilled_email=' + encodeURIComponent(val('email')); return; }
      $('fertig').textContent = `Ihre Auftragsnummer ist ${j.id}. Ich melde mich per E-Mail mit dem Zahlungslink.`; show(6);
    } catch (e) { m.className = 'sea-msg'; m.textContent = (e.message || 'Die Übertragung hat nicht geklappt.') + ' Bitte versuchen Sie es noch einmal oder schreiben Sie an info@s-energies.de.'; $('pay').disabled = false; }
  });

  // ---------- Navigation ----------
  function show(n) {
    step = n;
    document.querySelectorAll('#sea [data-step]').forEach(s => s.hidden = +s.dataset.step !== n);
    document.querySelectorAll('#sea-steps li').forEach((li, i) => li.classList.toggle('on', i < n));
    if (n === 5) uebersicht(daten());
    if (n === 2 && !val('plz') && /^\d{5}$/.test(val('lplz'))) $('plz').value = val('lplz');
    if (n === 2) ortVorschlag();
    const top = $('f').getBoundingClientRect().top + scrollY - 90; if (scrollY > top) scrollTo({ top });
  }
  // ---------- Adressprüfung über den eigenen Server (OpenStreetMap), nur als Hinweis ----------
  let adrOk = '';
  const norm = x => x.toLowerCase().replace(/ß/g, 'ss').replace(/str\.?\b/g, 'strasse').replace(/[^a-z0-9äöü]/g, '');
  async function adresse(nur) {
    if (!C.adresse) return null;
    const p = new URLSearchParams(nur ? { plz: val('plz') } : { plz: val('plz'), ort: val('ort'), str: val('str'), hnr: val('hnr') });
    try { const r = await fetch(C.adresse + (C.adresse.includes('?') ? '&' : '?') + p); return r.ok ? await r.json() : null; } catch (e) { return null; }
  }
  async function pruefeAdresse() {
    const key = [val('plz'), val('ort'), val('str'), val('hnr')].join('|');
    if (!C.adresse || adrOk === key) return true;
    const b = q('section[data-step="2"] [data-next]'); b.disabled = true;
    const r = await adresse(false); b.disabled = false;
    if (!r || !r.treffer) return true; // Dienst nicht erreichbar: nicht aufhalten
    adrOk = key; // beim zweiten Klick geht es in jedem Fall weiter
    const m = $('msg2'), sec = q('section[data-step="2"]');
    if (r.treffer === 'keiner') { markiere(sec, ['plz']); m.textContent = `Zur Postleitzahl ${val('plz')} haben wir keinen Ort gefunden. Bitte prüfen Sie die Postleitzahl. Stimmt alles, klicken Sie noch einmal auf „Weiter“.`; return false; }
    if (r.ort && !norm(r.ort).includes(norm(val('ort'))) && !norm(val('ort')).includes(norm(r.ort))) { markiere(sec, ['ort']); m.textContent = `Zur Postleitzahl ${val('plz')} gehört laut Karte „${r.ort}“. Bitte den Ort prüfen. Stimmt alles, klicken Sie noch einmal auf „Weiter“.`; return false; }
    if (r.treffer === 'plz') { markiere(sec, ['str']); m.textContent = `Die Straße „${val('str')}“ haben wir in ${val('plz')} ${r.ort || val('ort')} nicht gefunden. Bitte die Schreibweise prüfen. Stimmt alles, klicken Sie noch einmal auf „Weiter“.`; return false; }
    return true;
  }
  let ortGeholt = '';
  async function ortVorschlag() {
    if (val('ort') || ortGeholt === val('plz')) return;
    ortGeholt = val('plz'); const r = await adresse(true);
    if (r && r.ort && !val('ort')) $('ort').value = r.ort;
  }

  $('f').addEventListener('click', async ev => {
    const t = ev.target;
    if (t.matches('[data-back]')) show(step - 1);
    if (t.matches('[data-next]')) {
      if (step === 1 && !pruefung()) {
        const s1 = q('section[data-step="1"]'), we = +val('we') || 0, bj = +val('bj') || 0;
        if ($('art').value !== 'nwg') markiere(s1, [!(we > 0) && 'we', !(bj > 1800) && 'bj', !$('f77').hidden && radio() === undefined && q('#sea-f77 .sea-radio')].filter(Boolean));
        if ($('urteil').hidden) { $('urteil').hidden = false; $('urteil').className = 'sea-urteil no'; $('urteil').textContent = 'Bitte alle Fragen beantworten.'; } return; }
      if (step === 2 && (!check2() || !(await pruefeAdresse()))) return;
      if (step === 3 && !check3()) return;
      if (step === 4 && !check4()) return;
      show(step + 1);
    }
  });
  $('plz').addEventListener('input', () => { if (/^\d{5}$/.test(val('plz'))) ortVorschlag(); });

  // ---------- Jahres-Rad: antippen, wischen, übernehmen ----------
  const RH = 44, rad = document.createElement('div');
  rad.className = 'sea-rad'; rad.hidden = true;
  rad.innerHTML = '<div class="sea-rad-p" role="dialog" aria-modal="true" aria-label="Jahr wählen"><div class="sea-rad-t"></div><div class="sea-rad-l" tabindex="0"></div><div class="sea-rad-n"><button type="button" class="sea-sec" data-radx>Abbrechen</button><button type="button" data-radok>Übernehmen</button></div></div>';
  document.getElementById('sea').appendChild(rad);
  const rl = rad.querySelector('.sea-rad-l');
  let radFeld = null, radVon = 0, radRaf = 0;
  const radIdx = () => Math.max(0, Math.min(rl.children.length - 1, Math.round(rl.scrollTop / RH)));
  const radMark = () => { const i = radIdx(); [...rl.children].forEach((x, k) => x.classList.toggle('on', k === i)); };
  rl.addEventListener('scroll', () => { cancelAnimationFrame(radRaf); radRaf = requestAnimationFrame(radMark); });
  function radAuf(inp) {
    radFeld = inp; radVon = +inp.dataset.von; const bis = +inp.dataset.bis || new Date().getFullYear(), einh = inp.dataset.einheit || '';
    rl.innerHTML = Array.from({ length: bis - radVon + 1 }, (_, i) => `<div data-j="${radVon + i}">${radVon + i}${einh}</div>`).join('');
    rad.querySelector('.sea-rad-t').textContent = ((inp.closest('.sea-frage') && inp.closest('.sea-frage').querySelector('.sea-fl')) || inp.closest('label')).firstChild.textContent.trim();
    rad.hidden = false;
    const start = Math.min(bis, Math.max(radVon, +inp.value || +inp.dataset.rad));
    rl.scrollTop = (start - radVon) * RH; radMark(); rl.focus({ preventScroll: true });
  }
  function radZu(ok) {
    if (ok && radFeld) { radFeld.value = radVon + radIdx(); radFeld.dispatchEvent(new Event('input', { bubbles: true })); radFeld.dispatchEvent(new Event('change', { bubbles: true })); }
    rad.hidden = true; radFeld = null;
  }
  document.querySelectorAll('#sea [data-rad]').forEach(inp => {
    inp.addEventListener('click', () => radAuf(inp));
    inp.addEventListener('keydown', ev => { if (ev.key === 'Enter' || ev.key === ' ' || ev.key === 'ArrowDown') { ev.preventDefault(); radAuf(inp); } });
  });
  rl.addEventListener('click', ev => { const d = ev.target.closest('[data-j]'); if (!d) return; const i = +d.dataset.j - radVon; if (i === radIdx()) radZu(true); else rl.scrollTo({ top: i * RH, behavior: 'smooth' }); });
  rl.addEventListener('keydown', ev => {
    if (ev.key === 'ArrowDown' || ev.key === 'ArrowUp') { ev.preventDefault(); rl.scrollTop = (radIdx() + (ev.key === 'ArrowDown' ? 1 : -1)) * RH; }
    if (ev.key === 'Enter') { ev.preventDefault(); radZu(true); }
  });
  rad.addEventListener('keydown', ev => { if (ev.key === 'Escape') radZu(false); });
  rad.addEventListener('click', ev => { if (ev.target === rad || ev.target.matches('[data-radx]')) radZu(false); if (ev.target.matches('[data-radok]')) radZu(true); });

  $('andere').addEventListener('change', e => $('kadr').hidden = !e.target.checked);
  $('f').addEventListener('submit', e => e.preventDefault());
  perioden(); einheiten(); chipsSync();

  // Testdaten nur in der Vorschau
  if (C.preview) {
    const b = document.createElement('button'); b.type = 'button'; b.className = 'sea-sec'; b.textContent = 'Testdaten einfügen';
    b.style.cssText = 'margin-left:10px;padding:2px 10px;font-size:12px;color:#f2f1e5;border-color:rgba(242,241,229,.4)';
    $('tag').after(b);
    b.addEventListener('click', () => {
      const s = { we: 2, bj: 1984, plz: '91301', str: 'Musterstraße', hnr: '12', ort: 'Forchheim', wfl: '186,5', bjhz: 2009, fenart: 'e', bjfen: 1998, ddachj: '1', ddach: 14, dwandj: '0', dbodenj: '0', m0: '2650', m1: '2480', m2: '2590', vorname: 'Anna', nachname: 'Muster', email: 'anna.muster@example.de', tel: '09191 123456' };
      Object.entries(s).forEach(([k, x]) => $(k).value = x);
      $('etr').value = 'oel'; ['wahr', 'ds', 'widerruf'].forEach(k => $(k).checked = true); einheiten(); chipsSync(); pruefung();
    });
  }
})();
