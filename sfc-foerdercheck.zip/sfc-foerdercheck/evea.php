<?php
// Baut aus den Formulardaten eine EVEBI-Projektdatei (.evea): ZIP mit projekt.xml, Bildern (blob_{GUID}.jpg) und file-hashes (sha1).
// Grundlage ist ein leeres Verbrauchsausweis-Projekt aus EVEBI 14.3.8 (vorlage-projekt.xml, ohne Logo und Unterschrift).
// $v: Felder wie in der CSV (ETr1_Kategorie, ETr1_Jahr1_Menge in kWh, Leerstand als Bruch …), $fotos: Dateipfade, erstes = Hausansicht.
if (!defined('ABSPATH') && PHP_SAPI !== 'cli') exit;

function sfc_ea_guid() {
  $h = bin2hex(random_bytes(16));
  return strtoupper(sprintf('{%s-%s-%s-%s-%s}', substr($h, 0, 8), substr($h, 8, 4), substr($h, 12, 4), substr($h, 16, 4), substr($h, 20, 12)));
}

// Wert setzen; $manuell = wie eine Eingabe in EVEBI (auto="false", man="…")
function sfc_ea_setze(DOMXPath $x, $pfad, $wert, $manuell = false, $kontext = null) {
  $n = $kontext ? $x->query($pfad, $kontext)->item(0) : $x->query($pfad)->item(0);
  if (!$n) return;
  $n->nodeValue = '';
  $n->appendChild($n->ownerDocument->createTextNode((string) $wert));
  if ($manuell && $n->hasAttribute('auto')) { $n->setAttribute('auto', 'false'); $n->setAttribute('man', (string) $wert); }
  elseif ($n->hasAttribute('calc')) $n->setAttribute('calc', (string) $wert);
}

function sfc_ea_iso($d) { return preg_match('/^(\d{1,2})\.(\d{1,2})\.(\d{4})$/', trim((string) $d), $m) ? sprintf('%04d-%02d-%02d', $m[3], $m[2], $m[1]) : ''; }
function sfc_ea_zahl($s) { $s = trim((string) $s); if ($s === '' || $s === '-') return 0.0; return (float) str_replace(',', '.', str_replace('.', '', $s)); }
function sfc_ea_dez($f) { return number_format((float) $f, 7, '.', ''); }

// Bundesland grob aus den ersten zwei Ziffern der PLZ (Leitregionen); Grenzfälle prüft der Aussteller
function sfc_ea_bundesland($plz) {
  $p = (int) substr($plz, 0, 2);
  $map = [1 => 'SN', 2 => 'SN', 3 => 'BB', 4 => 'SN', 6 => 'ST', 7 => 'TH', 8 => 'SN', 9 => 'SN', 10 => 'BE', 12 => 'BE', 13 => 'BE', 14 => 'BB', 15 => 'BB', 16 => 'BB', 17 => 'MV', 18 => 'MV', 19 => 'MV',
    20 => 'HH', 21 => 'NI', 22 => 'HH', 23 => 'SH', 24 => 'SH', 25 => 'SH', 26 => 'NI', 27 => 'NI', 28 => 'HB', 29 => 'NI', 30 => 'NI', 31 => 'NI', 32 => 'NW', 33 => 'NW', 34 => 'HE', 35 => 'HE', 36 => 'HE', 37 => 'NI', 38 => 'NI', 39 => 'ST',
    40 => 'NW', 41 => 'NW', 42 => 'NW', 44 => 'NW', 45 => 'NW', 46 => 'NW', 47 => 'NW', 48 => 'NW', 49 => 'NI', 50 => 'NW', 51 => 'NW', 52 => 'NW', 53 => 'NW', 54 => 'RP', 55 => 'RP', 56 => 'RP', 57 => 'NW', 58 => 'NW', 59 => 'NW',
    60 => 'HE', 61 => 'HE', 63 => 'HE', 64 => 'HE', 65 => 'HE', 66 => 'SL', 67 => 'RP', 68 => 'BW', 69 => 'BW', 70 => 'BW', 71 => 'BW', 72 => 'BW', 73 => 'BW', 74 => 'BW', 75 => 'BW', 76 => 'BW', 77 => 'BW', 78 => 'BW', 79 => 'BW',
    80 => 'BY', 81 => 'BY', 82 => 'BY', 83 => 'BY', 84 => 'BY', 85 => 'BY', 86 => 'BY', 87 => 'BY', 88 => 'BW', 89 => 'BY', 90 => 'BY', 91 => 'BY', 92 => 'BY', 93 => 'BY', 94 => 'BY', 95 => 'BY', 96 => 'BY', 97 => 'BY', 98 => 'TH', 99 => 'TH'];
  return 'BL_' . ($map[$p] ?? 'BY');
}

// Verbrauchszeiträume eines Energieträgers (ETr1/ETr2) in dessen VerbraeucheListe schreiben
function sfc_ea_verbraeuche(DOMDocument $d, DOMElement $liste, array $v, $etr) {
  while ($liste->firstChild) $liste->removeChild($liste->firstChild);
  foreach ([1, 2, 3] as $j) {
    $von = sfc_ea_iso($v["{$etr}_Jahr{$j}_von"] ?? ''); $bis = sfc_ea_iso($v["{$etr}_Jahr{$j}_bis"] ?? '');
    if (!$von || !$bis) continue;
    $leer = sfc_ea_zahl($v["{$etr}_Jahr{$j}_Leerstand"] ?? '0') * 100;
    $xml = '<item GUID="' . sfc_ea_guid() . '">'
      . "<von>$von</von><bis>$bis</bis>"
      . '<Leerstand unit="%">' . sfc_ea_dez($leer) . '</Leerstand><LeerstandStrom unit="%">0.0000000</LeerstandStrom><Bemerkung></Bemerkung>'
      . '<Klimafaktor auto="true" man="0.0000000" calc="1.0000000" unit="-">1.0000000</Klimafaktor>'
      . '<Brennstoffmenge unit="TODO">' . sfc_ea_dez(sfc_ea_zahl($v["{$etr}_Jahr{$j}_Menge"] ?? '0')) . '</Brennstoffmenge>'
      . '<Anteil_Warmwasser auto="true" man="0.0000000" calc="0.0000000" unit="-">0.0000000</Anteil_Warmwasser>'
      . '<Anteil_Kaelte auto="true" man="0.0000000" calc="0.0000000" unit="-">0.0000000</Anteil_Kaelte>'
      . '<Anteil_NHS auto="true" man="0.0000000" calc="0.0000000" unit="kWh">0.0000000</Anteil_NHS></item>';
    $f = $d->createDocumentFragment(); $f->appendXML($xml); $liste->appendChild($f);
  }
}

function sfc_ea_nutzung(DOMDocument $d, DOMElement $set, array $items) {
  while ($set->firstChild) $set->removeChild($set->firstChild);
  foreach ($items as $i) $set->appendChild($d->createElement('item', $i));
}

// Ergänzende Erläuterungen: ein kurzer Empfehlungssatz (max. 120 Zeichen) aus den Gebäudedaten, wichtigste Maßnahme zuerst
function sfc_ea_erlaeuterung(array $v) {
  $jahr = (int) date('Y'); $bj = (int) ($v['Baujahr'] ?? 0); $hz = (int) ($v['baujahrHzErz'] ?? 0); $fe = (int) ($v['bjFensterAustausch'] ?? 0);
  $fossil = in_array($v['ETr1_Kategorie'] ?? '', ['BK_GAS', 'BK_OEL', 'BK_FLUESSIGGAS'], true);
  $dach = sfc_ea_zahl($v['Dach1_Dämmung'] ?? '0') > 0; $wand = sfc_ea_zahl($v['Wand1_Dämmung'] ?? '0') > 0; $boden = sfc_ea_zahl($v['Boden1_Dämmung'] ?? '0') > 0;
  $alt = $bj && $bj < 1995;
  if ($fossil && $hz && $jahr - $hz >= 20) $s = 'Die Heizung ist ' . ($jahr - $hz) . ' Jahre alt: Umstieg auf erneuerbare Wärme planen, Förderung bis zu 80 %.';
  elseif ($alt && !$dach) $s = 'Empfehlung: oberste Geschossdecke bzw. Dach dämmen, das senkt den Verbrauch mit wenig Aufwand.';
  elseif ($alt && $fe && $fe < 1995) $s = "Empfehlung: Fenster von $fe gegen Dreifachverglasung tauschen.";
  elseif ($alt && !$boden) $s = 'Empfehlung: Kellerdecke dämmen, das senkt den Verbrauch mit wenig Aufwand.';
  elseif ($alt && !$wand) $s = 'Empfehlung: Außenwand dämmen, am besten zusammen mit anderen Arbeiten an der Fassade.';
  elseif ($fossil) $s = 'Empfehlung: hydraulischen Abgleich prüfen; beim nächsten Heizungstausch auf erneuerbare Wärme umsteigen.';
  else $s = 'Für die nächsten Schritte empfehle ich einen individuellen Sanierungsfahrplan (iSFP).';
  return mb_substr($s, 0, 120);
}

function sfc_ea_evea(array $v, array $fotos, $vorlage, $ziel) {
  $d = new DOMDocument(); $d->preserveWhiteSpace = true;
  $d->loadXML(file_get_contents($vorlage));
  $x = new DOMXPath($d);
  $heute = date('Y-m-d');

  // neues Projekt: eigene Projekt-GUID, sonst hält EVEBI zwei Aufträge für dasselbe Projekt
  $alt = $d->documentElement->getAttribute('GUID'); $neu = sfc_ea_guid();
  foreach ($x->query('//*[@GUID="' . $alt . '"] | //prjID') as $n) {
    if ($n->hasAttribute('GUID') && $n->getAttribute('GUID') === $alt) $n->setAttribute('GUID', $neu);
    if ($n->nodeName === 'prjID' && $n->nodeValue === $alt) $n->nodeValue = $neu;
  }

  $h = '/Projekt/hdr';
  // Gebäude
  foreach (['Plz' => 'PLZ', 'Ort' => 'Ort', 'Strasse' => 'Straße', 'Hausnr' => 'Hausnr'] as $tag => $k) sfc_ea_setze($x, "$h/objektAdr/$tag", $v[$k] ?? '');
  sfc_ea_setze($x, "$h/bundesland", sfc_ea_bundesland($v['PLZ'] ?? ''));
  sfc_ea_setze($x, "$h/name", trim("Wohngebäude {$v['Ort']}, {$v['Straße']} {$v['Hausnr']}"));
  sfc_ea_setze($x, "$h/baujahr", (int) ($v['Baujahr'] ?? 0));
  sfc_ea_setze($x, "$h/we", (int) ($v['Wohneinheiten'] ?? 0), true);
  sfc_ea_setze($x, "$h/wfl", sfc_ea_dez(sfc_ea_zahl($v['Wohnfläche'] ?? '0')), true);
  sfc_ea_setze($x, "$h/keller_beheizt", ($v['Keller_beheizt'] ?? '0') === '1' ? 'true' : 'false');
  sfc_ea_setze($x, "$h/bjBrennerTausch", (int) ($v['baujahrHzErz'] ?? 0));
  sfc_ea_setze($x, "$h/bjFensterAustausch", (int) ($v['bjFensterAustausch'] ?? 0));
  sfc_ea_setze($x, "$h/sanierungsjahr", (int) ($v['Modernisierung'] ?? 0));
  foreach (['dach' => 'Dach1_Dämmung', 'wand' => 'Wand1_Dämmung', 'keller' => 'Boden1_Dämmung'] as $t => $k) sfc_ea_setze($x, "$h/nachtraeglDaemmung_$t", sfc_ea_dez(sfc_ea_zahl($v[$k] ?? '0')));
  sfc_ea_setze($x, "$h/datenErfasserEigentuemer", 'true');
  sfc_ea_setze($x, "$h/datenErfasserAussteller", 'false');
  sfc_ea_setze($x, "$h/eavHatTwSolar", ($v['TW_Solar'] ?? '0') === '1' ? 'true' : 'false');
  sfc_ea_setze($x, "$h/eavHatHzSolar", ($v['HZ_Solar'] ?? '0') === '1' ? 'true' : 'false');
  sfc_ea_setze($x, "$h/eavHatTwWaermepumpe", ($v['TW_WP'] ?? '0') === '1' ? 'true' : 'false');
  sfc_ea_setze($x, "$h/eavHatHzWaermepumpe", ($v['HZ_WP'] ?? '0') === '1' ? 'true' : 'false');
  if (($v['Fensterlüftung'] ?? '0') === '1') sfc_ea_nutzung($d, $x->query("$h/EA_LueftungSet")->item(0), ['EAL_FENSTER']);

  // Auftraggeber
  $frau = ($v['Kunden_Anrede'] ?? '') === 'Frau';
  $k = ['Anrede' => $v['Kunden_Anrede'] ?: 'Herr', 'Vorname' => $v['Kunden_Vorname'] ?? '', 'Nachname' => $v['Kunden_Nachname'] ?? '',
    'Plz' => $v['Kunden_PLZ'] ?? '', 'Ort' => $v['Kunden_Ort'] ?? '', 'Strasse' => $v['Kunden_Straße'] ?? '', 'Hausnr' => $v['Kunden_Hausnr'] ?? '',
    'Telefon' => $v['Kunden_telefon'] ?? '', 'eMail' => $v['Kunden_email'] ?? '',
    'Briefanrede' => ($v['Kunden_Anrede'] ?? '') === '' ? 'Guten Tag,' : ($frau ? 'Sehr geehrte Frau ' : 'Sehr geehrter Herr ') . ($v['Kunden_Nachname'] ?? '') . ','];
  foreach ($k as $tag => $w) sfc_ea_setze($x, "$h/kundenAdr/$tag", $w);

  // Energieausweis
  $ea = '/Projekt/eing/ea';
  sfc_ea_setze($x, "$ea/ausstellgrund", $v['Anlass'] ?? 'AG_VERMIETUNG');
  sfc_ea_setze($x, "$ea/gebaeudeteil", $v['gebaeudeteil'] ?? 'GT_GANZES_GEB');
  sfc_ea_setze($x, "$ea/ausstelldatum", $heute);
  sfc_ea_setze($x, "$ea/baujahr", (int) ($v['Baujahr'] ?? 0));
  if (!empty($v['baujahrHzErz'])) sfc_ea_setze($x, "$ea/baujahrHzErz", (int) $v['baujahrHzErz'], true);
  sfc_ea_setze($x, "$ea/ergaenzendeErlaeuterungen", $v['Erlaeuterungen'] ?? sfc_ea_erlaeuterung($v));

  // Energieträger: Vorlage hat [0] Strom (Licht) und [1] Erdgas; [1] wird zum Hauptenergieträger, ein zweiter wird davon kopiert
  $etl = $x->query('/Projekt/eing/ETraegerListe')->item(0);
  $haupt = $x->query('item', $etl)->item(1);
  $zweit = !empty($v['ETr2_Kategorie']) ? $haupt->cloneNode(true) : null;
  $namen = ['BK_GAS' => 'Erdgas', 'BK_OEL' => 'Heizöl EL', 'BK_FLUESSIGGAS' => 'Flüssiggas', 'BK_PELLET' => 'Holzpellets', 'BK_HOLZ' => 'Holz', 'BK_HHS' => 'Holzhackschnitzel', 'BK_STROM' => 'Strom', 'BK_NACHTSTR' => 'Nachtstrom', 'BK_NONE' => 'Fernwärme'];
  $traeger = function (DOMElement $it, $etr) use ($d, $x, $v, $namen) {
    $kat = $v["{$etr}_Kategorie"];
    sfc_ea_setze($x, 'BrStKategorie', $kat, false, $it);
    sfc_ea_setze($x, 'name', $namen[$kat] ?? $kat, false, $it);
    sfc_ea_setze($x, 'preisermittlung', 'EHK_ABRECHNUNG', false, $it);
    sfc_ea_setze($x, 'isFw', ($v["{$etr}_isFw"] ?? '0') === '1' ? 'true' : 'false', false, $it);
    sfc_ea_nutzung($d, $x->query('NutzungSet', $it)->item(0), ($v["{$etr}_TWW"] ?? '0') === '1' ? ['NUTZ_HZ', 'NUTZ_WW'] : ['NUTZ_HZ']);
    sfc_ea_verbraeuche($d, $x->query('VerbraeucheListe', $it)->item(0), $v, $etr);
  };
  // Strom-Eintrag wie in EVEBI: nur Beleuchtung, Abrechnung
  $strom = $x->query('item', $etl)->item(0);
  sfc_ea_setze($x, 'preisermittlung', 'EHK_ABRECHNUNG', false, $strom);
  sfc_ea_nutzung($d, $x->query('NutzungSet', $strom)->item(0), ['NUTZ_LICHT']);
  $traeger($haupt, 'ETr1');
  if ($zweit) {
    foreach ((new DOMXPath($d))->query('.//@GUID', $zweit) as $a) $a->value = sfc_ea_guid();
    $zweit->setAttribute('GUID', sfc_ea_guid());
    sfc_ea_setze($x, 'ID', 3, false, $zweit);
    $etl->appendChild($zweit);
    $traeger($zweit, 'ETr2');
  }

  // Fotos: erstes Bild = Hausansicht
  $bilder = [];
  $liste = $x->query('/Projekt/bilderStreamsListe')->item(0);
  foreach ($fotos as $pfad) {
    if (!$pfad || !is_file($pfad)) continue;
    $g = sfc_ea_guid(); $ext = preg_match('/\.png$/i', $pfad) ? 'png' : 'jpg';
    $name = "blob_$g.$ext"; $bilder[$name] = $pfad;
    $f = $d->createDocumentFragment();
    $f->appendXML('<item GUID="' . $g . '"><stream Content_Disposition="attachment" Content_Disposition_Filename="' . $name . '"/><titel></titel><beschreibung></beschreibung><name></name><quelle></quelle><aufnahmedatum></aufnahmedatum></item>');
    $liste->appendChild($f);
  }

  $xml = $d->saveXML();
  $z = new ZipArchive();
  if ($z->open($ziel, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) return false;
  $z->addFromString('projekt.xml', $xml);
  $hashes = 'projekt.xml=sha1:' . sha1($xml) . "\n";
  foreach ($bilder as $name => $pfad) { $z->addFile($pfad, $name); $hashes .= "$name=sha1:" . sha1_file($pfad) . "\n"; }
  $z->addFromString('file-hashes', $hashes);
  return $z->close();
}
