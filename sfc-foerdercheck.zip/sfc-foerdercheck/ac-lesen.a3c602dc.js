/* Liest aus dem Text eines Angebots (Zeilen) Gewerk, System, Größe, Preis und Mehrwertsteuer heraus. Läuft im Browser, nichts wird übertragen. */
window.sacLesen = function (zeilen) {
  const T = zeilen.join('\n'), t = T.toLowerCase();
  const zahl = s => parseFloat(String(s).replace(/\./g, '').replace(',', '.'));
  const n = re => (t.match(re) || []).length;
  const mode = arr => { const c = {}; arr.forEach(x => c[x] = (c[x] || 0) + 1); let best = null; for (const k in c) if (best === null || c[k] > c[best] || (c[k] === c[best] && +k > +best)) best = k; return best === null ? null : +best; };
  // Gewerk
  const sc = {
    'Photovoltaik': n(/photovoltaik|kwp|pv-anlage|pv-modul|wechselrichter/g) * 2,
    'Heizung': n(/wärmepumpe|waermepumpe|pellet|hackschnitzel|scheitholz|heizkessel|holzvergaser|solarthermie|kollektor|heizlast|hydraulischer abgleich/g),
    'Dach / oberste Geschossdecke': n(/aufsparren|aufdach|zwischensparren|untersparren|dacheindeckung|dachziegel|dachstein|lattung|geschossdecke/g),
    'Außenwand / Fassade': n(/wdvs|wärmedämmverbund|fassadendämm|vorgehängt|einblasdämm|kerndämm/g) * 2,
    'Fenster und Außentüren': n(/\bfenster\b|kunststofffenster|holzfenster|haustür|hebeschiebe|uw[- ]?wert|\buw\b/g),
    'Kellerdecke / Bodenplatte': n(/kellerdecke|kellerdeckendämm/g) * 3,
    'Lüftungsanlage': n(/lüftungsanlage|lüftungsgerät|wärmerückgewinnung|komfortlüftung/g) * 2 };
  let gewerk = Object.keys(sc).reduce((a, b) => sc[b] > sc[a] ? b : a);
  if (!sc[gewerk]) gewerk = '';
  // System
  let sys = '';
  if (gewerk === 'Heizung') {
    const h = { wp: n(/wärmepumpe|waermepumpe|monoblock|außeneinheit/g), wpe: n(/erdsonde|sole[- /]?wasser|flächenkollektor|tiefenbohrung|grundwasser-?wärmepumpe/g) * 3,
      hack: n(/hackschnitzel|hackgut/g), scheit: n(/scheitholz|holzvergaser/g), pellet: n(/pellet/g), solar: n(/solarthermie|flachkollektor|röhrenkollektor|solarstation/g) };
    if (h.scheit && h.pellet && /kombi/.test(t)) sys = 'kombi';
    else { sys = Object.keys(h).reduce((a, b) => h[b] > h[a] ? b : a); if (!h[sys]) sys = ''; }
    if (sys === 'wp' && h.wpe) sys = 'wpe';
  }
  const HUE = ['Dach / oberste Geschossdecke', 'Außenwand / Fassade', 'Fenster und Außentüren', 'Kellerdecke / Bodenplatte'];
  const gewerke = HUE.includes(gewerk) ? HUE.filter(g => g === gewerk || sc[g] >= 3) : gewerk ? [gewerk] : [];
  const bau = [];
  if (gewerke.includes('Dach / oberste Geschossdecke')) {
    // mehrere Bausteine möglich
    bau.push(/aufsparren|aufdach|dacheindeckung|neueindeckung|dachziegel|dachstein|konterlattung/.test(t) && 'auf', /zwischensparren|untersparren|klemmfilz/.test(t) && 'innen',
      /geschossdecke/.test(t) && 'ogd', /gaube/.test(t) && 'gaube');
  }
  if (gewerke.includes('Außenwand / Fassade')) bau.push(/vorgehängt/.test(t) ? 'vhf' : /kerndämm|einblas|innendämm/.test(t) ? 'kern' : 'wdvs');
  if (gewerke.includes('Kellerdecke / Bodenplatte')) bau.push('kd');
  if (gewerke.length && HUE.includes(gewerk)) sys = bau.filter(Boolean).join(',');
  else if (gewerk === 'Photovoltaik') sys = /speicher|batterie|akku/.test(t) ? 'pvs' : 'pv';
  else if (gewerk === 'Außenwand / Fassade') sys = /vorgehängt/.test(t) ? 'vhf' : /kerndämm|einblas|innendämm/.test(t) ? 'kern' : 'wdvs';
  else if (gewerk === 'Kellerdecke / Bodenplatte') sys = 'kd';
  else if (gewerk === 'Lüftungsanlage') sys = /dezentral/.test(t) ? 'dl' : 'zl';
  // Größe: nur eindeutig beschriftete Werte, sonst trägt der Kunde sie selbst ein
  let gr = null;
  const alle = (re, min, max) => [...T.matchAll(re)].map(m => zahl(m[m.length - 1])).filter(x => x >= min && x <= max);
  if (gewerk === 'Photovoltaik') { const k = alle(/(?<!max[^\n]{0,30})(\d{1,3}(?:,\d{1,3})?)\s*kWp/gi, 1, 100); gr = mode(k); }
  else if (gewerk === 'Heizung' && sys !== 'solar') { const k1 = alle(/heizlast[^\n]{0,40}?(\d{1,3}(?:,\d{1,2})?)\s*kW(?![a-zA-Z])/gi, 3, 150), k2 = alle(/(?:nennleistung|nennwärmeleistung|wärmenennleistung)[^\n]{0,40}?(\d{1,3}(?:,\d{1,2})?)\s*kW(?![a-zA-Z])/gi, 3, 150); gr = k1.length ? k1[0] : k2.length ? k2[0] : null; }
  else if (sys === 'solar') { const k = alle(/(?:kollektorfläche|bruttofläche|aperturfläche|gesamtfläche)[^\n]{0,40}?(\d{1,2}(?:,\d{1,2})?)\s*(?:m²|m2|qm)/gi, 2, 80); gr = k.length ? Math.max(...k) : null; }
  else if (gewerk && gewerk !== 'Lüftungsanlage' && gewerk !== 'Fenster und Außentüren') { const k = alle(/(\d{1,4}(?:\.\d{3})?(?:,\d{1,2})?)\s*(?:m²|m2|qm)(?![a-zA-Z])/g, 5, 5000); gr = mode(k); }

  // Preis
  const betr = s => [...s.matchAll(/(\d{1,3}(?:\.\d{3})+,\d{2}|\d{3,6},\d{2})/g)].map(m => zahl(m[1]));
  let brutto = 0, netto = 0;
  zeilen.forEach((z, i) => {
    const l = z.toLowerCase(), b = betr(z).concat(betr(zeilen[i + 1] || '').slice(0, 1));
    if (!b.length) return;
    if (/brutto|gesamtbetrag|endbetrag|endsumme|zu zahlen|angebotsbetrag|angebotssumme|gesamtsumme|gesamtpreis inkl|inkl\.? ?(mwst|ust)|summe inkl/.test(l)) brutto = Math.max(brutto, ...b);
    else if (/netto|summe exkl|exkl\.? ?(mwst|ust)|zzgl/.test(l) && !/zzgl\.? ?\d/.test(l)) netto = Math.max(netto, ...b.slice(0, 1));
  });
  const nullSteuer = zeilen.some(z => /ust|mwst|umsatzsteuer|mehrwertsteuer/i.test(z) && /(^|[^\d,.])0(,00?)?\s*%/.test(z));
  if (netto && brutto && brutto < netto) brutto = 0;
  let preis = null, mwst = 'brutto';
  if (brutto) preis = brutto; else if (netto) { preis = netto; mwst = 'netto'; }
  // Fenster: Flügel zählen (z. B. „2-flg.“), bodentief = Türen, Balkon-/Terrassentüren oder Höhe ab 1,90 m; Dachfenster und Hebeschiebeanlagen nur erkennen
  let fl = 0, bt = 0;
  if (gewerk === 'Fenster und Außentüren') zeilen.forEach((z, i) => {
    const m = z.match(/(\d)\s*-?\s*fl(?:g|ügel)/i); if (!m) return;
    const umf = ((zeilen[i - 1] || '') + ' ' + z).toLowerCase(), h = [...z.matchAll(/\d{3,4}\s*[x×]\s*(\d{3,4})\s*mm/gi)].map(x => +x[1]);
    if (/haustür|hauseingang|nebeneingang|\bnt\b|dach/.test(umf)) return;
    if (/tür|balkon|terrass|bodentief/.test(umf) || h.some(x => x >= 1900)) bt += +m[1]; else fl += +m[1];
  });
  const dachfenster = gewerk === 'Fenster und Außentüren' && /dachfenster|dachflächenfenster|velux|wohndachfenster/.test(t);
  const hebeschiebe = gewerk === 'Fenster und Außentüren' && /hebe-?\s?schiebe|\bhst\b|hebeschiebetür/.test(t);
  if (gewerke.includes('Fenster und Außentüren')) {
    const fb = [(fl + bt > 0 || dachfenster || hebeschiebe || n(/kunststofffenster|holzfenster|alufenster|fensterelement|dreh-?kipp/g)) && 'fen', n(/haustür|hauseingangstür|haustuer/g) && 'tuer'].filter(Boolean);
    sys = [...sys.split(',').filter(Boolean), ...(fb.length ? fb : ['fen'])].join(',');
  }
  // Zusatzleistungen im Heizungsangebot, nur als Vorschlag
  const zus = gewerk === 'Heizung' ? [/fußbodenheizung|fussbodenheizung|flächenheizung|fräsen.{0,20}heiz|heizestrich/.test(t) && 'fbh',
    /neue heizkörper|heizkörper liefern|heizkörpertausch|austausch (der |von )?heizkörper|(plan|kompakt|niedertemperatur)-?heizkörper/.test(t) && 'hk',
    /zählerschrank|zaehlerschrank|zählerplatz/.test(t) && 'el',
    /schornsteinsanierung|abgasanlage|edelstahlschornstein|edelstahlkamin|kaminsanierung/.test(t) && 'kamin'].filter(Boolean) : [];
  const wallbox = false; // Wallbox steht in Angeboten oft nur als Option oder Ausschluss, daher wählt der Kunde selbst
  return { gewerk, gewerke, sys, gr, preis, mwst, nullSteuer, wallbox, fl, bt, dachfenster, hebeschiebe, zus };
};
