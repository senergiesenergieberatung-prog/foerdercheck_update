# Fördercheck auf s-energies.de einbauen (ca. 5 Minuten)

1. In WordPress anmelden: s-energies.de/wp-admin
2. **Plugins → Installieren → Plugin hochladen** → `sfc-foerdercheck.zip` auswählen → **Jetzt installieren** → **Aktivieren**
3. **Seiten → Erstellen**, Titel: `Fördercheck 2026 – Wie viel Zuschuss bekommen Sie?`
   - In Elementor: Widget **Shortcode** (oder „Text-Editor“) einfügen, Inhalt: `[foerdercheck]`
   - Ab Version 1.6: `[foerdercheck ansicht="kacheln"]` zeigt den Klick-Rechner mit großen Kacheln (eine Frage pro Bildschirm, ideal fürs Handy). Ohne Angabe bleibt das bisherige Formular.
   - Permalink: `/foerdercheck/`
4. Veröffentlichen. Den Menüpunkt **Fördercheck** ins Hauptmenü aufnehmen (Design → Menüs) und auf der Startseite einen Button „Förderung berechnen“ darauf verlinken.
5. Test: Rechner ausfüllen, Anfrage mit deiner eigenen Adresse senden.
   - Die Anfrage erscheint im WordPress-Menü **Fördercheck**.
   - Zusätzlich kommt eine E-Mail an info@s-energies.de. Kommt keine an: Plugin „WP Mail SMTP“ installieren und mit deinem IONOS-Postfach verbinden (SMTP-Server smtp.ionos.de, Port 587, TLS, Benutzer = volle E-Mail-Adresse).

## Datenschutz
In deiner Datenschutzerklärung einen Absatz ergänzen: Anfrageformular Fördercheck, verarbeitete Daten (Name, E-Mail, Telefon optional, PLZ, Anliegen, Rechenergebnis), Zweck Bearbeitung der Anfrage, Rechtsgrundlage Art. 6 Abs. 1 lit. b DSGVO, Speicherung in WordPress bis zur Erledigung. Der Rechner selbst überträgt nichts. Das Plugin lädt keine externen Schriften oder Skripte.

## Pflege
Die Förderwerte stehen in `foerdercheck.js` (Funktion `stufe` und `calc`). Stichtage 01.02.2027 usw. sind schon eingebaut. Bei neuen Regeln liefert Claude eine neue Version.

## Updates
Ab v1.2 sucht das Plugin selbst nach neuen Versionen (GitHub, Repository foerdercheck_update). Unter **Plugins** bei „sENERGIEs Fördercheck“ einmal **Automatische Updates aktivieren** klicken, dann spielt WordPress neue Versionen von allein ein.
