/* sENERGIEs Online-Verbrauchsausweis: Zulässigkeitsprüfung, Datenerfassung, CSV für den EVEBI-Import (Datei → Datenimport → CSV) */
(function () {
  const C = Object.assign({ preview: false, endpoint: '', anfrage: '', preis: '69 €', zahlungslink: '', partnerlink: '', region: ['9054', '9055', '910', '912', '913', '954', '960'], datenschutz: '/datenschutzerklaerung/', bild: '' }, window.SEA_CFG || {});
  const $ = id => document.getElementById('sea-' + id);
  const q = (s, r = document) => r.querySelector(s);
  if (!$('f')) return;

  // Energieträger: Code wie in der EVEBI-Schnittstelle, Einheit auf der Abrechnung, Umrechnung in kWh (Heizwert)
  const ETR = {
    gas: ['Erdgas', 'BK_GAS', 'kWh', 1], oel: ['Heizöl', 'BK_OEL', 'Liter', 10], fluessig: ['Flüssiggas', 'BK_FLUESSIGGAS', 'Liter', 6.57],
    pellet: ['Holzpellets', 'BK_PELLET', 'kg', 4.9], holz: ['Scheitholz', 'BK_HOLZ', 'Ster', 1750], hhs: ['Hackschnitzel', 'BK_HHS', 'Schüttraummeter', 750],
    wp: ['Wärmepumpe (Strom)', 'BK_STROM', 'kWh', 1], strom: ['Strom direkt / Infrarot', 'BK_STROM', 'kWh', 1], nacht: ['Nachtspeicher', 'BK_NACHTSTR', 'kWh', 1],
    fw: ['Fernwärme', 'BK_NONE', 'kWh', 1]
  };
  const opt = (keys) => keys.map(k => `<option value="${k}">${ETR[k][0]} (${ETR[k][2]})</option>`).join('');
  $('etr').innerHTML = opt(Object.keys(ETR));
  $('etr2').innerHTML = opt(['holz', 'pellet', 'oel', 'gas', 'fluessig', 'strom']);

  const HEAD = 'BOM;ID;Anlass;PLZ;Ort;Straße;Hausnr;isGebaeudehuelle;Baujahr;Wohneinheiten;Wohnfläche;gebaeudeteil;Keller_beheizt;bilderStreams_0;bilderStreams_1;bilderStreams_2;Klimatisiert;kuehlWfl;passiveKuehlung;fernKuehlung;stromKuehlung;waermeKuehlung;kaiAnzahl;kaiDatum;baujahrHzErz;TW_Solar;HZ_Solar;TW_WP;HZ_WP;Fensterlüftung;Schachtlüftung;L_Mit_WRG;L_Ohne_WRG;Modernisierung;Dach1_Dämmung;Wand1_Dämmung;Boden1_Dämmung;bjFensterAustausch;ETr1_Kategorie;ETr1_Anteil_erneuerbar;ETr1_Anteil_KWK;ETr1_isFw;ETr1_gebaeudeNahErzeugt;ETr1_Jahr1_von;ETr1_Jahr1_bis;ETr1_Jahr1_Menge;ETr1_TWW;ETr1_Jahr1_Menge_TWW;ETr1_Jahr1_Leerstand;ETr1_Jahr2_von;ETr1_Jahr2_bis;ETr1_Jahr2_Menge;ETr1_Jahr2_Menge_TWW;ETr1_Jahr2_Leerstand;ETr1_Jahr3_von;ETr1_Jahr3_bis;ETr1_Jahr3_Menge;ETr1_Jahr3_Menge_TWW;ETr1_Jahr3_Leerstand;ETr1_PrimFaktor;ETr2_Kategorie;ETr2_Jahr1_von;ETr2_Jahr1_bis;ETr2_Jahr1_Menge;ETr2_TWW;ETr2_Jahr1_Menge_TWW;ETr2_Jahr1_Leerstand;ETr2_Jahr2_von;ETr2_Jahr2_bis;ETr2_Jahr2_Menge;ETr2_Jahr2_Menge_TWW;ETr2_Jahr2_Leerstand;ETr2_Jahr3_von;ETr2_Jahr3_bis;ETr2_Jahr3_Menge;ETr2_Jahr3_Menge_TWW;ETr2_Jahr3_Leerstand;ETr1_Heizung;ETr2_Heizung;ETr2_PrimFaktor;Gebäudetyp;Datenerhebung;BedarfVerbrauch;ETr2_Anteil_KWK;ETr2_Anteil_erneuerbar;ETr2_isFw;ETr2_gebaeudeNahErzeugt'.split(';');
  const KHEAD = ['Kunden_Anrede', 'Kunden_Vorname', 'Kunden_Nachname', 'Kunden_Straße', 'Kunden_Hausnr', 'Kunden_PLZ', 'Kunden_Ort', 'Kunden_email', 'Kunden_telefon'];
  // feste Werte wie in der Envisys-Musterdatei EA_Verbrauch_WG; Datenerhebung 0 = Eigentümer
  const DEF = { isGebaeudehuelle: '1', kuehlWfl: '0', passiveKuehlung: '0', fernKuehlung: '0', stromKuehlung: '0', waermeKuehlung: '0', kaiAnzahl: '0', kaiDatum: '00.01.1900', TW_WP: '0', HZ_WP: '0', ETr1_Anteil_erneuerbar: '0', ETr1_Anteil_KWK: '0', ETr1_gebaeudeNahErzeugt: '0', ETr1_Heizung: '1', ETr2_TWW: '1', ETr2_Jahr1_Menge_TWW: '-', ETr2_Jahr2_Menge_TWW: '-', ETr2_Jahr3_Menge_TWW: '-', ETr2_Heizung: '1', Gebäudetyp: '0', Datenerhebung: '0', BedarfVerbrauch: 'V', ETr2_Anteil_KWK: '#NV', ETr2_Anteil_erneuerbar: '#NV', ETr2_isFw: '#NV', ETr2_gebaeudeNahErzeugt: '#NV' };

  const num = s => { s = String(s ?? '').trim(); if (!s) return NaN; if (/,/.test(s)) s = s.replace(/\./g, '').replace(',', '.'); else if (/^\d{1,3}(\.\d{3})+$/.test(s)) s = s.replace(/\./g, ''); return parseFloat(s); };
  const de = (n, d = 0) => isFinite(n) ? (Math.round(n * 10 ** d) / 10 ** d).toString().replace('.', ',') : '';
  const pd = s => { const m = /^(\d{1,2})\.(\d{1,2})\.(\d{4})$/.exec(String(s).trim()); if (!m) return null; const d = new Date(+m[3], m[2] - 1, +m[1]); return d.getDate() === +m[1] ? d : null; };
  const fd = d => `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}.${d.getFullYear()}`;
  const tag = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
  const val = id => ($(id).value || '').trim();
  const radio = () => (q('input[name=sea-wsv]:checked') || {}).value;
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const imRegion = plz => C.region.some(p => plz.startsWith(p));
  let step = 1;

  if (C.preview) { $('tag').hidden = false; $('vorschau').hidden = false; }
  if (C.bild) q('.sea-kopf').style.backgroundImage = `linear-gradient(rgba(44,41,39,.78),rgba(44,41,39,.78)),url("${C.bild}")`;
  $('preis').textContent = C.preis;
  $('dslink').href = $('dslink2').href = C.datenschutz;

  // ---------- Schritt 1: Zulässigkeit (GEG § 80) ----------
  function pruefung() {
    const we = +val('we') || 0, bj = +val('bj') || 0, plz = val('plz');
    const alt = we > 0 && we < 5 && bj > 0 && bj < 1978;
    $('f77').hidden = !alt;
    const r = radio();
    let grund = '';
    if ($('art').value === 'nwg') grund = 'Online biete ich den Verbrauchsausweis nur für Wohngebäude an.';
    else if ($('anlass').value === 'AG_NEUBAU') grund = 'Für einen Neubau ist immer ein Bedarfsausweis nötig.';
    else if ($('3j').value === '0') grund = 'Für einen Verbrauchsausweis braucht es die Verbrauchswerte von 3 zusammenhängenden Jahren. Ohne diese ist ein Bedarfsausweis nötig.';
    else if (alt && r === '0') grund = 'Für Ihr Haus schreibt das Gebäudeenergiegesetz einen Bedarfsausweis vor. Dafür ist ein Termin vor Ort nötig.';
    const fertig = we > 0 && bj > 1800 && /^\d{5}$/.test(plz) && (!alt || r !== undefined);
    const u = $('urteil');
    if (!grund && !fertig) { u.hidden = true; $('lead').hidden = true; return false; }
    u.hidden = false;
    if (!grund) { u.className = 'sea-urteil'; u.innerHTML = '<b>Passt.</b> Ein Verbrauchsausweis ist für Ihr Gebäude zulässig.'; $('lead').hidden = true; return true; }
    u.className = 'sea-urteil no';
    const reg = /^\d{5}$/.test(plz) && imRegion(plz);
    u.innerHTML = '<b>Online leider nicht möglich.</b> ' + grund + ' ' + (reg
      ? 'Ihr Haus liegt in meinem Einzugsgebiet, ich erstelle den Bedarfsausweis gern vor Ort.'
      : (/^\d{5}$/.test(plz) ? 'Ihr Haus liegt außerhalb meines Einzugsgebiets. ' + (C.partnerlink
        ? `<br><small>Anzeige</small><br>Ein Energieberater in Ihrer Nähe erstellt den Bedarfsausweis: <a href="${esc(C.partnerlink)}" target="_blank" rel="sponsored noopener">kostenlos Angebote anfordern</a>.`
        : 'Einen Energieberater in Ihrer Nähe finden Sie in der <a href="https://www.energie-effizienz-experten.de/" target="_blank" rel="noopener">Energieeffizienz-Expertenliste</a>.') : 'Bitte geben Sie noch die Postleitzahl an.'));
    $('lead').hidden = !reg;
    return false;
  }
  ['art', 'anlass', 'we', 'bj', 'plz', '3j'].forEach(id => $(id).addEventListener('input', pruefung));
  document.querySelectorAll('input[name=sea-wsv]').forEach(x => x.addEventListener('change', pruefung));

  $('lsend').addEventListener('click', async () => {
    const m = $('lmsg'); m.className = 'sea-msg';
    if (!val('lname') || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(val('lmail'))) { m.textContent = 'Bitte Name und E-Mail angeben.'; return; }
    if (!$('lds').checked) { m.textContent = 'Bitte der Speicherung zustimmen.'; return; }
    const angaben = `Bedarfsausweis nötig (Online-Verbrauchsausweis): ${$('art').selectedOptions[0].text}, ${val('we')} WE, Baujahr ${val('bj')}, Anlass ${$('anlass').selectedOptions[0].text}, 3 Jahre Verbrauch: ${$('3j').value === '1' ? 'ja' : 'nein'}, WSchV 77: ${radio() === '1' ? 'ja' : radio() === 'n' ? 'Bauantrag ab 11/1977' : 'nein/unklar'}`;
    if (!C.anfrage) { m.className = 'sea-msg gut'; m.textContent = 'Vorschau: Diese Anfrage ginge jetzt an info@s-energies.de. ' + angaben; return; }
    $('lsend').disabled = true;
    try {
      const r = await fetch(C.anfrage, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: val('lname'), mail: val('lmail'), tel: val('ltel'), plz: val('plz'), wunsch: 'Bedarfsausweis', angaben, website: val('hp') }) });
      if (!r.ok) throw 0;
      m.className = 'sea-msg gut'; m.textContent = 'Danke! Ihre Anfrage ist angekommen, ich melde mich innerhalb von zwei Werktagen.';
    } catch (e) { m.textContent = 'Das hat leider nicht geklappt. Bitte schreiben Sie an info@s-energies.de.'; $('lsend').disabled = false; }
  });

  // ---------- Schritt 2 ----------
  function check2() {
    const f = [];
    if (!val('str') || !val('hnr') || !val('ort')) f.push('Adresse des Gebäudes');
    const w = num(val('wfl')), we = +val('we') || 1;
    if (!(w > 0)) f.push('Wohnfläche');
    $('msg2').textContent = f.length ? 'Bitte ergänzen: ' + f.join(', ') + '.' : '';
    if (!f.length && (w / we < 20 || w / we > 400)) $('msg2').textContent = `Hinweis: ${de(w / we)} m² pro Wohnung ist ungewöhnlich. Bitte die Wohnfläche prüfen.`;
    return !f.length;
  }

  // ---------- Schritt 3: Verbrauch ----------
  function perioden() {
    const tb = $('perioden'), j = new Date().getFullYear() - 1;
    tb.innerHTML = [0, 1, 2].map(i => `<tr><td class="sea-jt" colspan="5">Jahr ${i + 1}</td></tr><tr>
      <td data-l="von"><input id="sea-von${i}" value="01.01.${j - 2 + i}" placeholder="TT.MM.JJJJ" aria-label="Zeitraum ${i + 1} von"></td>
      <td data-l="bis"><input id="sea-bis${i}" value="31.12.${j - 2 + i}" placeholder="TT.MM.JJJJ" aria-label="Zeitraum ${i + 1} bis"></td>
      <td data-l="Verbrauch" class="sea-m1"><input id="sea-m${i}" inputmode="decimal" aria-label="Verbrauch Zeitraum ${i + 1}"></td>
      <td class="sea-z2" data-l="2. Wärmequelle" hidden><input id="sea-n${i}" inputmode="decimal" aria-label="Zweite Heizung Zeitraum ${i + 1}"></td>
      <td data-l="Leerstand %"><input id="sea-l${i}" inputmode="decimal" placeholder="0" aria-label="Leerstand Zeitraum ${i + 1}"></td></tr>`).join('');
    [0, 1].forEach(i => $('bis' + i).addEventListener('change', () => {
      const b = pd(val('bis' + i)); if (!b) return;
      const v = tag(b, 1); $('von' + (i + 1)).value = fd(v);
      $('bis' + (i + 1)).value = fd(tag(new Date(v.getFullYear() + 1, v.getMonth(), v.getDate()), -1));
      $('bis' + (i + 1)).dispatchEvent(new Event('change'));
    }));
    $('von0').addEventListener('change', () => { const v = pd(val('von0')); if (v) { $('bis0').value = fd(tag(new Date(v.getFullYear() + 1, v.getMonth(), v.getDate()), -1)); $('bis0').dispatchEvent(new Event('change')); } });
  }
  function einheiten() {
    $('einheit').textContent = ETR[$('etr').value][2];
    const z = $('zweit').checked;
    $('zweitbox').hidden = !z; $('th2').hidden = !z;
    document.querySelectorAll('.sea-z2').forEach(td => td.hidden = !z);
    $('einheit2').textContent = ETR[$('etr2').value][2];
  }
  ['etr', 'etr2', 'zweit'].forEach(id => $(id).addEventListener('change', einheiten));

  function check3() {
    const f = []; let prev = null;
    const z = $('zweit').checked;
    for (let i = 0; i < 3; i++) {
      const a = pd(val('von' + i)), b = pd(val('bis' + i)), m = num(val('m' + i)), l = num(val('l' + i) || '0');
      if (!a || !b) { f.push(`Zeitraum ${i + 1}: Datum bitte als TT.MM.JJJJ.`); continue; }
      if (b <= a) f.push(`Zeitraum ${i + 1}: „bis“ liegt vor „von“.`);
      const tage = (b - a) / 864e5 + 1;
      if (tage < 300 || tage > 430) f.push(`Zeitraum ${i + 1} sollte etwa ein Jahr umfassen.`);
      if (prev && Math.round((a - prev) / 864e5) !== 1) f.push(`Zeitraum ${i + 1} schließt nicht direkt an Zeitraum ${i} an.`);
      if (!(m > 0)) f.push(`Zeitraum ${i + 1}: Verbrauch fehlt.`);
      if (z && !(num(val('n' + i)) >= 0)) f.push(`Zeitraum ${i + 1}: Verbrauch der zweiten Wärmequelle fehlt (0 ist erlaubt).`);
      if (!(l >= 0 && l <= 100)) f.push(`Zeitraum ${i + 1}: Leerstand zwischen 0 und 100 %.`);
      prev = b;
    }
    if (prev && (Date.now() - prev) / 864e5 > 548) f.push('Der letzte Zeitraum endet vor mehr als 18 Monaten. Bitte die neueste Abrechnung verwenden.');
    let hinweis = '';
    if (!f.length) {
      const e = ETR[$('etr').value], e2 = ETR[$('etr2').value], wfl = num(val('wfl'));
      const kwh = [0, 1, 2].reduce((s, i) => s + num(val('m' + i)) * e[3] + (z ? num(val('n' + i)) * e2[3] : 0), 0) / 3 / wfl;
      const min = $('etr').value === 'wp' ? 8 : 30;
      if (kwh < min || kwh > 400) hinweis = `Hinweis: ${Math.round(kwh)} kWh pro m² und Jahr ist ungewöhnlich. Bitte Menge und Einheit prüfen. Sie können trotzdem weitermachen.`;
    }
    $('msg3').textContent = f.length ? f.join(' ') : hinweis;
    return !f.length;
  }

  // ---------- Schritt 4 ----------
  function check4() {
    const f = [];
    if (!val('nachname')) f.push('Name');
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(val('email'))) f.push('gültige E-Mail');
    if (!val('tel')) f.push('Telefon');
    if ($('andere').checked && (!val('kstr') || !/^\d{5}$/.test(val('kplz')) || !val('kort'))) f.push('Rechnungsadresse');
    if (!C.preview && !$('foto0').files[0]) f.push('Foto der Hausansicht');
    [0, 1, 2].forEach(i => { const x = $('foto' + i).files[0]; if (x && x.size > 8e6) f.push(`Foto ${i + 1} ist größer als 8 MB`); });
    if (!$('wahr').checked) f.push('Bestätigung der Angaben');
    if (!$('ds').checked) f.push('Datenschutz');
    if (!$('widerruf').checked) f.push('Zustimmung zum Beginn vor Ende der Widerrufsfrist');
    $('msg4').textContent = f.length ? 'Bitte ergänzen: ' + f.join(', ') + '.' : '';
    return !f.length;
  }

  // ---------- CSV ----------
  const clean = s => String(s ?? '').replace(/[;\r\n\t"]/g, ' ').replace(/^[=+@]+/, '').trim();
  function daten() {
    const k = $('etr').value, e = ETR[k], z = $('zweit').checked, e2 = ETR[$('etr2').value], l = $('lueft').value;
    const id = 'VA' + new Date().toISOString().slice(2, 10).replace(/-/g, '') + '-' + Math.random().toString(36).slice(2, 6).toUpperCase();
    const ext = i => { const x = $('foto' + i).files[0]; return x ? `${id}_${['ansicht', 'heizung', 'fenster'][i]}.${/png$/i.test(x.name) ? 'png' : 'jpg'}` : ''; };
    const v = Object.assign({}, DEF, {
      ID: id, Anlass: $('anlass').value, PLZ: val('plz'), Ort: val('ort'), Straße: val('str'), Hausnr: val('hnr'),
      Baujahr: val('bj'), Wohneinheiten: val('we'), Wohnfläche: de(num(val('wfl')), 2), gebaeudeteil: $('teil').value, Keller_beheizt: $('keller').value,
      bilderStreams_0: ext(0), bilderStreams_1: ext(1), bilderStreams_2: ext(2),
      Klimatisiert: $('klima').value, baujahrHzErz: val('bjhz'), TW_Solar: $('twsol').value, HZ_Solar: $('hzsol').value,
      HZ_WP: k === 'wp' ? '1' : '0', TW_WP: k === 'wp' && $('tww').value === '1' ? '1' : '0',
      Fensterlüftung: l === 'fenster' ? '1' : '0', Schachtlüftung: l === 'schacht' ? '1' : '0', L_Mit_WRG: l === 'wrg' ? '1' : '0', L_Ohne_WRG: l === 'owrg' ? '1' : '0',
      Modernisierung: val('modern') || '0', Dach1_Dämmung: val('ddach') || '0', Wand1_Dämmung: val('dwand') || '0', Boden1_Dämmung: val('dboden') || '0', bjFensterAustausch: val('bjfen') || '0',
      ETr1_Kategorie: e[1], ETr1_isFw: k === 'fw' ? '1' : '0', ETr1_TWW: $('tww').value
    });
    [0, 1, 2].forEach(i => {
      const n = i + 1, ls = de((num(val('l' + i)) || 0) / 100, 3);
      v[`ETr1_Jahr${n}_von`] = val('von' + i); v[`ETr1_Jahr${n}_bis`] = val('bis' + i);
      v[`ETr1_Jahr${n}_Menge`] = de(num(val('m' + i)) * e[3]); v[`ETr1_Jahr${n}_Leerstand`] = ls;
      if (z) { v[`ETr2_Jahr${n}_von`] = val('von' + i); v[`ETr2_Jahr${n}_bis`] = val('bis' + i); v[`ETr2_Jahr${n}_Menge`] = de(num(val('n' + i)) * e2[3]); v[`ETr2_Jahr${n}_Leerstand`] = ls; }
    });
    if (z) Object.assign(v, { ETr2_Kategorie: e2[1], ETr2_TWW: '0', ETr2_Anteil_KWK: '0', ETr2_Anteil_erneuerbar: '0', ETr2_isFw: '0', ETr2_gebaeudeNahErzeugt: '0' });
    const a = $('andere').checked;
    const kd = [$('anrede').value, val('vorname'), val('nachname'), a ? val('kstr') : val('str'), a ? val('khnr') : val('hnr'), a ? val('kplz') : val('plz'), a ? val('kort') : val('ort'), val('email'), val('tel')];
    KHEAD.forEach((h, i) => v[h] = kd[i]);
    const kopf = [...HEAD, ...KHEAD], zeile = kopf.map(h => clean(v[h]));
    const roh = [0, 1, 2].map(i => `${val('von' + i)}–${val('bis' + i)}: ${val('m' + i)} ${e[2]} ${e[0]}` + (z ? `, ${val('n' + i) || 0} ${e2[2]} ${e2[0]}` : '') + `, Leerstand ${val('l' + i) || 0} %`);
    const zusatz = { 'Gebäudeart': $('art').selectedOptions[0].text, 'Wärmeschutz 1977': $('f77').hidden ? 'nicht relevant' : ({ '1': 'ja, modernisiert', 'n': 'Bauantrag ab 1.11.1977', '0': 'nein' })[radio()] || '', 'Originalwerte': roh.join(' | ') };
    return { id, v, csv: '﻿' + kopf.join(';') + '\r\n' + zeile.join(';') + '\r\n', zusatz, fotos: [0, 1, 2].map(ext) };
  }

  function uebersicht(d) {
    const e = ETR[$('etr').value];
    $('sum').innerHTML = [['Gebäude', `${val('str')} ${val('hnr')}, ${val('plz')} ${val('ort')}`], ['Baujahr / Wohnungen', `${val('bj')} / ${val('we')}`], ['Wohnfläche', `${val('wfl')} m²`], ['Heizung', e[0] + ($('zweit').checked ? ' + ' + ETR[$('etr2').value][0] : '')], ['Verbrauch', [0, 1, 2].map(i => val('m' + i)).join(' / ') + ' ' + e[2]], ['Kontakt', `${val('vorname')} ${val('nachname')}, ${val('email')}`]]
      .map(([a, b]) => `<dt>${a}</dt><dd>${esc(b)}</dd>`).join('');
    if (C.preview) {
      $('csv').value = d.csv.slice(1);
      $('umrech').textContent = e[3] === 1 ? 'Mengen unverändert in kWh übernommen.' : `Umgerechnet: ${e[2]} × ${de(e[3], 2)} kWh (Heizwert).`;
    }
  }
  $('dl').addEventListener('click', () => {
    const d = daten(); const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([d.csv], { type: 'text/csv;charset=utf-8' })); a.download = d.id + '.csv'; document.body.appendChild(a); a.click(); a.remove();
  });

  $('pay').addEventListener('click', async () => {
    const m = $('msg5'); m.className = 'sea-msg';
    if (!C.endpoint) { m.className = 'sea-msg gut'; m.textContent = 'Vorschau: Hier geht es im Live-Betrieb zur Stripe-Zahlung. Der Auftrag mit CSV-Datei und Fotos geht an info@s-energies.de.'; return; }
    const d = daten(), fd = new FormData();
    fd.append('daten', JSON.stringify({ v: d.v, zusatz: d.zusatz, website: val('hp') }));
    [0, 1, 2].forEach(i => { const x = $('foto' + i).files[0]; if (x) fd.append('foto' + i, x, d.fotos[i]); });
    $('pay').disabled = true; m.className = 'sea-msg gut'; m.textContent = 'Auftrag wird übertragen …';
    try {
      const r = await fetch(C.endpoint, { method: 'POST', body: fd }); const j = await r.json();
      if (!r.ok || !j.ok) throw new Error(j.fehler || '');
      const z = C.zahlungslink;
      if (z) { m.textContent = 'Weiter zur Zahlung …'; location.href = z + (z.includes('?') ? '&' : '?') + 'client_reference_id=' + encodeURIComponent(j.id) + '&prefilled_email=' + encodeURIComponent(val('email')); return; }
      $('fertig').textContent = `Ihre Auftragsnummer ist ${j.id}. Ich melde mich per E-Mail mit dem Zahlungslink.`; show(6);
    } catch (e) { m.className = 'sea-msg'; m.textContent = (e.message || 'Die Übertragung hat nicht geklappt.') + ' Bitte versuchen Sie es noch einmal oder schreiben Sie an info@s-energies.de.'; $('pay').disabled = false; }
  });

  // ---------- Navigation ----------
  function show(n) {
    step = n;
    document.querySelectorAll('#sea [data-step]').forEach(s => s.hidden = +s.dataset.step !== n);
    document.querySelectorAll('#sea-steps li').forEach((li, i) => li.classList.toggle('on', i < n));
    if (n === 5) uebersicht(daten());
    const top = $('f').getBoundingClientRect().top + scrollY - 90; if (scrollY > top) scrollTo({ top });
  }
  $('f').addEventListener('click', ev => {
    const t = ev.target;
    if (t.matches('[data-back]')) show(step - 1);
    if (t.matches('[data-next]')) {
      if (step === 1 && !pruefung()) { if ($('urteil').hidden) { $('urteil').hidden = false; $('urteil').className = 'sea-urteil no'; $('urteil').textContent = 'Bitte alle Fragen beantworten.'; } return; }
      if (step === 2 && !check2()) return;
      if (step === 3 && !check3()) return;
      if (step === 4 && !check4()) return;
      show(step + 1);
    }
  });
  $('andere').addEventListener('change', e => $('kadr').hidden = !e.target.checked);
  $('f').addEventListener('submit', e => e.preventDefault());
  perioden(); einheiten();

  // Testdaten nur in der Vorschau
  if (C.preview) {
    const b = document.createElement('button'); b.type = 'button'; b.className = 'sea-sec'; b.textContent = 'Testdaten einfügen';
    b.style.cssText = 'margin-left:10px;padding:2px 10px;font-size:12px;color:#f2f1e5;border-color:rgba(242,241,229,.4)';
    $('tag').after(b);
    b.addEventListener('click', () => {
      const s = { we: 2, bj: 1984, plz: '91301', str: 'Musterstraße', hnr: '12', ort: 'Forchheim', wfl: '186,5', bjhz: 2009, bjfen: 1998, ddach: 16, dwand: 0, dboden: 0, m0: '2650', m1: '2480', m2: '2590', vorname: 'Anna', nachname: 'Muster', email: 'anna.muster@example.de', tel: '09191 123456' };
      Object.entries(s).forEach(([k, x]) => $(k).value = x);
      $('etr').value = 'oel'; ['wahr', 'ds', 'widerruf'].forEach(k => $(k).checked = true); einheiten(); pruefung();
    });
  }
})();
