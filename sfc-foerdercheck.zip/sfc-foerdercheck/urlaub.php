<?php
// Urlaubsschalter für Online-Energieausweis und Angebotscheck (Einstellungen → Urlaub / Aufträge).
// Modus „verschieben“: Bestellen geht weiter, Hinweis „Bearbeitung ab …“, Express ausgeblendet.
// Modus „pause“: Formular ausgeblendet, nur Hinweis; neue Aufträge werden abgelehnt.
// Nach dem Enddatum ist alles automatisch wieder normal. Per REST setzbar (Administratoren): /wp-json/wp/v2/settings, Felder sfc_urlaub_von, sfc_urlaub_bis, sfc_urlaub_modus.
if (!defined('ABSPATH')) exit;

add_action('init', function () {
  foreach (['sfc_urlaub_von' => 'Urlaub ab (JJJJ-MM-TT, leer = sofort)', 'sfc_urlaub_bis' => 'Urlaub bis einschließlich (JJJJ-MM-TT)', 'sfc_urlaub_modus' => 'verschieben oder pause'] as $o => $b)
    register_setting('sfc_urlaub', $o, ['type' => 'string', 'description' => $b, 'default' => '', 'show_in_rest' => true, 'sanitize_callback' => 'sanitize_text_field']);
});

// Aktiver Urlaub: ['bis' => 'd.m.Y', 'ab' => 'd.m.Y' (erster Arbeitstag), 'pause' => bool] oder null
function sfc_urlaub() {
  $bis = (string) get_option('sfc_urlaub_bis', ''); $von = (string) get_option('sfc_urlaub_von', '');
  if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $bis)) return null;
  $heute = wp_date('Y-m-d');
  if ($heute > $bis || ($von !== '' && $heute < $von)) return null;
  $ab = new DateTime($bis, wp_timezone()); $ab->modify('+1 day');
  while ((int) $ab->format('N') >= 6) $ab->modify('+1 day'); // erster Werktag danach (ohne Feiertage)
  return ['bis' => wp_date('d.m.Y', strtotime($bis)), 'ab' => $ab->format('d.m.Y'), 'pause' => get_option('sfc_urlaub_modus', '') === 'pause'];
}

function sfc_urlaub_satz() {
  $u = sfc_urlaub();
  return $u ? "Hinweis: Ich bin bis einschließlich {$u['bis']} im Urlaub und bearbeite Ihren Auftrag ab dem {$u['ab']}." : '';
}

// Hinweis-Kasten oben im Formular; bei Pause ersetzt er das Formular
function sfc_urlaub_einbauen($html, $express = true) {
  $u = sfc_urlaub();
  if (!$u) return $html;
  $box = $u['pause']
    ? '<div class="sea-box sea-urlaub" style="border:1px solid #f3d97a;border-radius:8px"><p><b>Zurzeit nehme ich keine neuen Aufträge an.</b> Ich bin bis einschließlich ' . esc_html($u['bis']) . ' im Urlaub. Ab dem ' . esc_html($u['ab']) . ' können Sie hier wieder bestellen. Bei Fragen erreichen Sie mich unter <a href="mailto:info@s-energies.de">info@s-energies.de</a>.</p></div>'
    : '<div class="sea-box sea-urlaub" style="border:1px solid #f3d97a;border-radius:8px"><p><b>Urlaubshinweis:</b> Ich bin bis einschließlich ' . esc_html($u['bis']) . ' im Urlaub. Sie können wie gewohnt bestellen, ich bearbeite Ihren Auftrag ab dem ' . esc_html($u['ab']) . '.' . ($express ? ' Express ist bis dahin nicht verfügbar.' : '') . '</p></div>';
  if ($u['pause'] && !isset($_GET['danke'])) return preg_replace('/<form\b.*<\/form>/s', $box, $html, 1);
  return preg_replace('/<form\b[^>]*>/', '$0' . $box, $html, 1);
}

// Neue Aufträge während einer Pause ablehnen (falls jemand eine alte Seite offen hat)
function sfc_urlaub_pause_antwort() {
  $u = sfc_urlaub();
  return $u && $u['pause'] ? new WP_REST_Response(['ok' => false, 'fehler' => "Bis einschließlich {$u['bis']} nehme ich keine neuen Aufträge an."], 423) : null;
}

add_action('admin_menu', function () {
  add_options_page('Urlaub / Aufträge', 'Urlaub / Aufträge', 'manage_options', 'sfc-urlaub', function () {
    if (isset($_POST['sfc_urlaub_save']) && check_admin_referer('sfc_urlaub_save')) {
      $d = fn($k) => preg_match('/^\d{4}-\d{2}-\d{2}$/', $x = sanitize_text_field(wp_unslash($_POST[$k] ?? ''))) ? $x : '';
      update_option('sfc_urlaub_von', $d('von')); update_option('sfc_urlaub_bis', $d('bis'));
      update_option('sfc_urlaub_modus', ($_POST['modus'] ?? '') === 'pause' ? 'pause' : 'verschieben');
      echo '<div class="updated"><p>Gespeichert.</p></div>';
    }
    if (isset($_POST['sfc_urlaub_aus']) && check_admin_referer('sfc_urlaub_save')) { update_option('sfc_urlaub_von', ''); update_option('sfc_urlaub_bis', ''); echo '<div class="updated"><p>Urlaub beendet.</p></div>'; }
    $u = sfc_urlaub(); $p = get_option('sfc_urlaub_modus', '') === 'pause';
    echo '<div class="wrap"><h1>Urlaub / Aufträge</h1><p>Gilt für den Online-Energieausweis und den Angebotscheck. Nach dem Enddatum läuft alles automatisch wieder normal.</p>';
    echo '<p><b>Status:</b> ' . ($u ? ($u['pause'] ? 'pausiert' : 'Aufträge werden angenommen, Bearbeitung ab ' . esc_html($u['ab'])) . ' (bis ' . esc_html($u['bis']) . ')' : 'normal') . '</p>';
    echo '<form method="post">'; wp_nonce_field('sfc_urlaub_save');
    echo '<table class="form-table"><tr><th>Von</th><td><input type="date" name="von" value="' . esc_attr(get_option('sfc_urlaub_von', '')) . '"> <span class="description">leer = ab sofort</span></td></tr>'
      . '<tr><th>Bis einschließlich</th><td><input type="date" name="bis" value="' . esc_attr(get_option('sfc_urlaub_bis', '')) . '"></td></tr>'
      . '<tr><th>Was passiert?</th><td><label><input type="radio" name="modus" value="verschieben"' . ($p ? '' : ' checked') . '> Weiter bestellen lassen, Hinweis „Bearbeitung ab …“, kein Express</label><br>'
      . '<label><input type="radio" name="modus" value="pause"' . ($p ? ' checked' : '') . '> Bestellungen pausieren (Formular ausblenden)</label></td></tr></table>';
    echo '<p><button class="button button-primary" name="sfc_urlaub_save" value="1">Speichern</button> <button class="button" name="sfc_urlaub_aus" value="1">Urlaub beenden</button></p></form></div>';
  });
});
