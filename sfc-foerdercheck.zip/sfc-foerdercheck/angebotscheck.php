<?php
// Angebotscheck: kostenloser Kurzcheck (Preisvergleich mit ac-preise.json aus Stephans Preisdatenbank + Förderschätzung, nur im Browser),
// dann Angebotsbewertung (1 Angebot, 49 €) oder Angebotsvergleich (bis zu 3 Angebote, 79 €) je Gewerk. Shortcode [sfc_angebotscheck], Auftrag mit hochgeladenen Angeboten,
// danach Stripe-Zahlungslink. Zahlungsprüfung, Dankeseite und Löschung unbezahlter Aufträge laufen über den Energieausweis-Code (sfc_ea_zahlungen_pruefen).
// Attribute: zahlungslink="…" (Angebotscheck, 1 Angebot), zahlungslink_vergleich="…" (bis zu 3 Angebote), preis="49 €", preis_vergleich="79 €", vorschau="1". Kein Express.
// BEG Nr. 9.3: Das Angebot nennt und empfiehlt keine Installateure und enthält keine Partnerlinks.
if (!defined('ABSPATH')) exit;

const SFC_AC_MAIL_MB = 15; // größere Anhänge bleiben im Backend (Download-Link in der Mail)

add_action('init', function () {
  register_post_type('sfc_ac_auftrag', [
    'label' => 'Angebotscheck-Aufträge', 'labels' => ['singular_name' => 'Angebotscheck-Auftrag'],
    'public' => false, 'show_ui' => true, 'show_in_menu' => 'edit.php?post_type=sfc_anfrage',
    'supports' => ['title', 'editor'], 'capability_type' => 'post',
    'capabilities' => ['create_posts' => 'do_not_allow'], 'map_meta_cap' => true,
  ]);
});

add_shortcode('sfc_angebotscheck', function ($atts = []) {
  $a = shortcode_atts(['zahlungslink' => 'https://buy.stripe.com/aFabJ34Ce3mbfyP8MX9Zm06', 'zahlungslink_vergleich' => 'https://buy.stripe.com/28E28t4Ce1e3aev2oz9Zm04', 'preis' => '49 €', 'preis_vergleich' => '79 €', 'vorschau' => '0', 'bild' => content_url('uploads/2025/11/Welt_Beleuchtet.webp')], $atts);
  $dir = plugin_dir_path(__FILE__); $url = plugin_dir_url(__FILE__);
  wp_enqueue_style('sfc-ea', $url . sfc_datei($dir, 'ea.css'), [], null);
  wp_enqueue_style('sfc-ac', $url . sfc_datei($dir, 'ac.css'), ['sfc-ea'], null);
  wp_enqueue_script('sfc-ac-lesen', $url . sfc_datei($dir, 'ac-lesen.js'), [], null, ['in_footer' => true, 'strategy' => 'defer']);
  wp_enqueue_script('sfc-ac', $url . sfc_datei($dir, 'ac.js'), ['sfc-ac-lesen'], null, ['in_footer' => true, 'strategy' => 'defer']);
  wp_add_inline_script('sfc-ac', 'window.SAC_CFG=' . wp_json_encode([
    'endpoint' => rest_url('sfc/v1/angebotscheck'), 'zahlung' => rest_url('sfc/v1/zahlung'),
    'zahlungslink' => esc_url_raw($a['zahlungslink']), 'zahlungslink_vergleich' => esc_url_raw($a['zahlungslink_vergleich']),
    'preis' => $a['preis'], 'preis_vergleich' => $a['preis_vergleich'], 'preview' => $a['vorschau'] === '1', 'preise' => sfc_ac_preise(), 'bild' => esc_url_raw($a['bild']),
    'kc_endpoint' => rest_url('sfc/v1/kurzcheck'), 'pdfjs' => $url . 'pdfjs/pdf-3.11.174.min.js', 'pdfworker' => $url . 'pdfjs/pdf-3.11.174.worker.min.js', 'foerderrechner' => home_url('/foerdercheck/'),
    'datenschutz' => get_privacy_policy_url() ?: home_url('/datenschutzerklaerung/')]) . ';', 'before');
  return sfc_urlaub_einbauen(str_replace('class="sea sac"', 'class="sea sac sea-wp"', file_get_contents($dir . 'ac.html')), false);
});

add_action('rest_api_init', function () {
  register_rest_route('sfc/v1', '/angebotscheck', ['methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => 'sfc_ac_auftrag']);
});

function sfc_ac_auftrag(WP_REST_Request $r) {
  if ($p = sfc_urlaub_pause_antwort()) return $p;
  $d = json_decode((string) $r->get_param('daten'), true);
  if (!is_array($d) || !empty($d['website']) || !is_array($d['haus'] ?? null) || !is_array($d['kontakt'] ?? null)) return new WP_REST_Response(['ok' => false], 400);
  $t = fn($x, $n = 200) => mb_substr(sanitize_text_field((string) $x), 0, $n);
  $k = $d['kontakt'];
  $mail = sanitize_email($k['email'] ?? ''); $vor = $t($k['vorname'] ?? '', 80); $nach = $t($k['nachname'] ?? '', 80); $tel = $t($k['tel'] ?? '', 40);
  $haus = [];
  foreach ($d['haus'] as $hk => $hv) if (count($haus) < 20) $haus[$t($hk, 40)] = $t($hv, 120);
  if (!is_email($mail) || $nach === '' || !preg_match('/^\d{5}$/', $haus['PLZ'] ?? '')) return new WP_REST_Response(['ok' => false, 'fehler' => 'Es fehlen Angaben.'], 422);
  $tarif = ($d['tarif'] ?? '') === 'vergleich' ? 'vergleich' : 'einzel';

  // max. 5 Aufträge pro IP und Stunde
  $rl = 'sfc_ac_rl_' . md5($_SERVER['REMOTE_ADDR'] ?? '');
  $n = (int) get_transient($rl);
  if ($n >= 5) return new WP_REST_Response(['ok' => false, 'fehler' => 'Zu viele Aufträge in kurzer Zeit.'], 429);
  set_transient($rl, $n + 1, HOUR_IN_SECONDS);

  $titel = "{$haus['PLZ']} – $nach – " . ($haus['Gewerk'] ?? 'Angebot');
  $pid = wp_insert_post(['post_type' => 'sfc_ac_auftrag', 'post_status' => 'private', 'post_title' => $titel]);
  if (!$pid || is_wp_error($pid)) return new WP_REST_Response(['ok' => false], 500);
  $id = 'AC' . wp_date('ymd') . '-' . $pid;

  // Dateien: PDF, JPG, PNG, je max. 10 MB, höchstens 25
  $ordner = sfc_ea_ordner(); $dateien = []; $namen = [];
  for ($i = 0; $i < 25; $i++) {
    $f = $_FILES["datei$i"] ?? null;
    if (!$f || $f['error'] !== UPLOAD_ERR_OK || $f['size'] > 10 * MB_IN_BYTES) continue;
    $ty = wp_check_filetype_and_ext($f['tmp_name'], $f['name'], ['jpg|jpeg' => 'image/jpeg', 'png' => 'image/png', 'pdf' => 'application/pdf']);
    if (empty($ty['ext'])) continue;
    if ($ty['ext'] !== 'pdf' && !@getimagesize($f['tmp_name'])) continue;
    if ($ty['ext'] === 'pdf' && file_get_contents($f['tmp_name'], false, null, 0, 5) !== '%PDF-') continue;
    $teil = preg_match('/^(a[123]|extra)__/', $f['name'], $m) ? $m[1] : 'extra';
    $label = ['a1' => 'Angebot1', 'a2' => 'Angebot2', 'a3' => 'Angebot3', 'extra' => 'Unterlage'][$teil];
    $ext = $ty['ext'] === 'jpeg' ? 'jpg' : $ty['ext'];
    $name = "{$id}_{$label}_" . (count($dateien) + 1) . ".$ext";
    if (move_uploaded_file($f['tmp_name'], "$ordner/$name")) { $dateien[] = "$ordner/$name"; $namen[] = $name . ' (' . sanitize_file_name(substr($f['name'], strlen($teil) + 2)) . ')'; }
  }
  if (!array_filter($namen, fn($x) => strpos($x, '_Angebot') !== false)) {
    foreach ($dateien as $x) @unlink($x);
    wp_delete_post($pid, true);
    return new WP_REST_Response(['ok' => false, 'fehler' => 'Das Angebot konnte nicht hochgeladen werden (nur PDF, JPG oder PNG bis 10 MB).'], 422);
  }

  $text = "Auftragsnummer: $id\nPaket: " . ($tarif === 'vergleich' ? 'Angebotsvergleich (bis zu 3 Angebote, mit Gegenüberstellung), 79 €' : 'Angebotsbewertung (1 Angebot), 49 €') . "\n"
    . "Kunde: $vor $nach\nE-Mail: $mail\nTelefon: $tel\n\n";
  foreach ($haus as $hk => $hv) $text .= "$hk: $hv\n";
  $text .= "\nKurzcheck des Kunden: " . ($t($d['kurzcheck'] ?? '', 300) ?: '–') . "\nVorprüfung (automatisch, grob): " . $t($d['vorpruefung'] ?? '', 300) . "\n";
  $frage = mb_substr(sanitize_textarea_field((string) ($d['frage'] ?? '')), 0, 2000);
  $text .= "\nFrage des Kunden:\n" . ($frage !== '' ? $frage : '–') . "\n\nDateien:\n- " . implode("\n- ", $namen) . "\n";

  wp_update_post(['ID' => $pid, 'post_title' => "[wartet auf Zahlung] $id – $titel", 'post_content' => nl2br(esc_html($text))]);
  // gleiche Meta-Felder wie beim Energieausweis, damit dessen Zahlungsprüfung den Auftrag mit erledigt
  foreach (['_sfc_ea_status' => 'offen', '_sfc_ea_id' => $id, '_sfc_ea_kunde' => $mail, '_sfc_ea_nachname' => $nach, '_sfc_ea_titel' => $titel, '_sfc_ea_text' => $text, '_sfc_ea_dateien' => $dateien, '_sfc_ac_tarif' => $tarif] as $mk => $mv) update_post_meta($pid, $mk, $mv);
  wp_schedule_single_event(time() + 120, 'sfc_ea_zahlungen');
  return new WP_REST_Response(['ok' => true, 'id' => $id], 200);
}

// Nach Zahlungseingang (aufgerufen aus sfc_ea_versand): Auftrag mit Unterlagen an Stephan, Bestätigung an den Kunden
function sfc_ac_versand($pid, array $s) {
  $id = get_post_meta($pid, '_sfc_ea_id', true); $titel = get_post_meta($pid, '_sfc_ea_titel', true); $text = get_post_meta($pid, '_sfc_ea_text', true);
  $mail = get_post_meta($pid, '_sfc_ea_kunde', true); $name = get_post_meta($pid, '_sfc_ea_nachname', true);
  $vergleich = get_post_meta($pid, '_sfc_ac_tarif', true) === 'vergleich';
  $netto = (int) ($s['amount_subtotal'] ?? 0); $betrag = number_format((int) ($s['amount_total'] ?? 0) / 100, 2, ',', '.') . ' €';
  $warn = $vergleich && $netto > 0 && $netto < 7900 ? "\nACHTUNG: Vergleich gewählt, aber nur der Preis für ein Angebot bezahlt. Bitte nur ein Angebot prüfen oder nachfragen.\n" : '';
  // Anhänge bis SFC_AC_MAIL_MB, der Rest per Download-Link (nur für Administratoren)
  $anh = []; $links = []; $summe = 0;
  foreach (array_values(array_filter((array) get_post_meta($pid, '_sfc_ea_dateien', true), 'is_file')) as $i => $f) {
    $gr = filesize($f);
    if ($summe + $gr <= SFC_AC_MAIL_MB * MB_IN_BYTES) { $anh[] = $f; $summe += $gr; }
    else $links[] = basename($f) . ': ' . admin_url('admin-post.php?action=sfc_ac_datei&p=' . $pid . '&i=' . $i);
  }
  wp_update_post(['ID' => $pid, 'post_title' => str_replace('[wartet auf Zahlung]', '[bezahlt]', get_the_title($pid))]);
  $geruest = "Prüfbericht-Gerüst (zum Ausfüllen):\n1. Ihr Haus und Ihr Vorhaben\n2. Technik: Heizung = Größe/Heizlast, Vorlauftemperatur, Heizkörper, Warmwasser, Schall, hydraulischer Abgleich; Hülle = Dämmstoff, Stärke/U-Wert, Anschlüsse und Wärmebrücken, Luftdichtheit, Gerüst/Entsorgung; Fenster = Uw-Wert, Einbau (RAL), Lüftungskonzept\n"
    . "3. Preis: Gesamtpreis und auffällige Positionen, bei mehreren Angeboten Gegenüberstellung\n4. Förderung: technische Mindestanforderungen, förderfähige Kosten und Kostengrenze, Boni, Vertrag mit Förder-Bedingung, Antrag vor Beginn\n5. Fragen an den Installateur\n6. Fazit (ohne Empfehlung eines Betriebs, BEG Nr. 9.3)\n";
  wp_mail(SFC_EMPFAENGER, ($vergleich ? 'Angebotsvergleich' : 'Angebotsbewertung') . " $id: $titel (bezahlt)",
    "Neuer bezahlter Auftrag für eine Angebotsprüfung.\nBezahlt: $betrag (Stripe " . ($s['id'] ?? '') . ")\n$warn\n$text\n"
    . ($links ? "Nicht angehängt (zu groß für die Mail, Download nach Anmeldung in WordPress):\n" . implode("\n", $links) . "\n\n" : '')
    . $geruest . "\nDen Bericht bitte als PDF direkt an $mail schicken (Antworten an diese Mail gehen an den Kunden).\n",
    ["Reply-To: $name <$mail>"], $anh);
  wp_mail($mail, "Ihr Auftrag $id: Prüfung Ihrer Angebote",
    "Guten Tag,\n\nvielen Dank für Ihren Auftrag und Ihre Zahlung. Ihre Unterlagen sind bei mir angekommen.\n\n"
    . "Ich sehe mir Ihre Unterlagen persönlich an und schicke Ihnen den Prüfbericht als PDF per E-Mail, in der Regel innerhalb von 3 Werktagen." . (sfc_urlaub() ? ' ' . sfc_urlaub_satz() : '') . " Bei Rückfragen melde ich mich bei Ihnen.\n\n"
    . "Bitte unterschreiben Sie bis dahin nichts, falls das noch nicht geschehen ist.\n\n"
    . "Mit freundlichen Grüßen\nStephan Hecky\nsENERGIEs Energieberatung\nMöchs 33, 91355 Hiltpoltstein · Tel. +49 155 65134339 · info@s-energies.de", ['Reply-To: sENERGIEs Energieberatung <' . SFC_EMPFAENGER . '>']);
}

// Download einzelner Dateien für Administratoren (Ordner ist von außen gesperrt)
add_action('admin_post_sfc_ac_datei', function () {
  if (!current_user_can('manage_options')) wp_die('Keine Berechtigung.', 403);
  $l = array_values(array_filter((array) get_post_meta((int) ($_GET['p'] ?? 0), '_sfc_ea_dateien', true), 'is_file'));
  $f = $l[(int) ($_GET['i'] ?? -1)] ?? '';
  if (!$f) wp_die('Datei nicht gefunden.', 404);
  nocache_headers();
  header('Content-Type: ' . (wp_check_filetype($f)['type'] ?: 'application/octet-stream'));
  header('Content-Disposition: attachment; filename="' . basename($f) . '"');
  header('Content-Length: ' . filesize($f));
  readfile($f); exit;
});
