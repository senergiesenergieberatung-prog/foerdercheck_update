<?php
// Angebotscheck: kostenloser Kurzcheck (Preisvergleich mit ac-preise.json aus Stephans Preisdatenbank + Förderschätzung, nur im Browser),
// dann Angebotsbewertung (1 Angebot, 49 €) oder Angebotsvergleich (bis zu 3 Angebote, 79 €) je Gewerk. Shortcode [sfc_angebotscheck], Auftrag mit hochgeladenen Angeboten,
// danach Stripe-Zahlungslink. Zahlungsprüfung, Dankeseite und Löschung unbezahlter Aufträge laufen über den Energieausweis-Code (sfc_ea_zahlungen_pruefen).
// Attribute: zahlungslink="…" (Angebotscheck, 1 Angebot), zahlungslink_vergleich="…" (bis zu 3 Angebote), preis="49 €", preis_vergleich="79 €", vorschau="1". Kein Express.
// BEG Nr. 9.3: Das Angebot nennt und empfiehlt keine Installateure und enthält keine Partnerlinks.
if (!defined('ABSPATH')) exit;

const SFC_AC_MAIL_MB = 15; // größere Anhänge bleiben im Backend (Download-Link in der Mail)

add_action('init', function () {
  register_post_type('sfc_ac_auftrag', [
    'label' => 'Angebotscheck-Aufträge', 'labels' => ['singular_name' => 'Angebotscheck-Auftrag'],
    'public' => false, 'show_ui' => true, 'show_in_menu' => 'edit.php?post_type=sfc_anfrage',
    'supports' => ['title', 'editor'], 'capability_type' => 'post',
    'capabilities' => ['create_posts' => 'do_not_allow'], 'map_meta_cap' => true,
  ]);
});

add_shortcode('sfc_angebotscheck', function ($atts = []) {
  $a = shortcode_atts(['zahlungslink' => 'https://buy.stripe.com/aFabJ34Ce3mbfyP8MX9Zm06', 'zahlungslink_vergleich' => 'https://buy.stripe.com/28E28t4Ce1e3aev2oz9Zm04', 'preis' => '49 €', 'preis_vergleich' => '79 €', 'vorschau' => '0', 'bild' => content_url('uploads/2025/11/Welt_Beleuchtet.webp')], $atts);
  $dir = plugin_dir_path(__FILE__); $url = plugin_dir_url(__FILE__);
  wp_enqueue_style('sfc-ea', $url . sfc_datei($dir, 'ea.css'), [], null);
  wp_enqueue_style('sfc-ac', $url . sfc_datei($dir, 'ac.css'), ['sfc-ea'], null);
  wp_enqueue_script('sfc-ac-lesen', $url . sfc_datei($dir, 'ac-lesen.js'), [], null, ['in_footer' => true, 'strategy' => 'defer']);
  wp_enqueue_script('sfc-ac', $url . sfc_datei($dir, 'ac.js'), ['sfc-ac-lesen'], null, ['in_footer' => true, 'strategy' => 'defer']);
  if (function_exists('sfc_zaehler_einbinden')) sfc_zaehler_einbinden(); // anonymer Nutzungszähler (seit 1.8.5)
  wp_add_inline_script('sfc-ac', 'window.SAC_CFG=' . wp_json_encode([
    'endpoint' => rest_url('sfc/v1/angebotscheck'), 'zahlung' => rest_url('sfc/v1/zahlung'),
    'zahlungslink' => esc_url_raw($a['zahlungslink']), 'zahlungslink_vergleich' => esc_url_raw($a['zahlungslink_vergleich']),
    'preis' => $a['preis'], 'preis_vergleich' => $a['preis_vergleich'], 'preview' => $a['vorschau'] === '1', 'preise' => sfc_ac_preise(), 'bild' => esc_url_raw($a['bild']),
    'kc_endpoint' => rest_url('sfc/v1/kurzcheck'), 'pdfjs' => $url . 'pdfjs/pdf-3.11.174.min.js', 'pdfworker' => $url . 'pdfjs/pdf-3.11.174.worker.min.js', 'foerderrechner' => home_url('/foerdercheck/'),
    'gutschein' => rest_url('sfc/v1/ac-gutschein'), 'datei' => rest_url('sfc/v1/ac-datei'), 'maxdatei' => sfc_ac_maxdatei(),
    'datenschutz' => get_privacy_policy_url() ?: home_url('/datenschutzerklaerung/')]) . ';', 'before');
  return sfc_urlaub_einbauen(str_replace('class="sea sac"', 'class="sea sac sea-wp"', file_get_contents($dir . 'ac.html')), false);
});

add_action('rest_api_init', function () {
  register_rest_route('sfc/v1', '/angebotscheck', ['methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => 'sfc_ac_auftrag']);
  register_rest_route('sfc/v1', '/ac-datei', ['methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => 'sfc_ac_datei']);
  register_rest_route('sfc/v1', '/ac-gutschein', ['methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => 'sfc_ac_gutschein']);
});

// ---------- Gutscheincode vorab prüfen (wie beim Energieausweis), damit der Kunde den reduzierten Preis vor der Bestellung sieht ----------
// Liest Stripe-Rabattcodes mit dem eingeschränkten Schlüssel. Abgezogen wird der Rabatt erst von Stripe (prefilled_promo_code).
const SFC_AC_PRODUKTE = ['einzel' => 'prod_VYPgvQmrAI5w8M', 'vergleich' => 'prod_VY9nqYt3eHlpcz'];
function sfc_ac_gutschein(WP_REST_Request $r) {
  $code = strtoupper(preg_replace('/[^A-Za-z0-9_-]/', '', (string) $r->get_param('code')));
  if (strlen($code) < 2 || strlen($code) > 40) return new WP_REST_Response(['status' => 'ungueltig'], 200);
  $cache = 'sfc_ac_gc_' . md5($code);
  if (($c = get_transient($cache)) !== false) return new WP_REST_Response($c, 200);
  $key = 'sfc_ac_gcl_' . md5($_SERVER['REMOTE_ADDR'] ?? '');
  $n = (int) get_transient($key);
  if ($n >= 30) return new WP_REST_Response(['status' => 'unbekannt'], 200);
  set_transient($key, $n + 1, HOUR_IN_SECONDS);
  $unbekannt = new WP_REST_Response(['status' => 'unbekannt'], 200);
  if (!function_exists('sfc_liz_stripe')) return $unbekannt;
  $l = sfc_liz_stripe('promotion_codes', ['code' => $code, 'active' => 'true', 'limit' => 1]);
  if ($l === null) return $unbekannt;
  $erg = ['status' => 'ungueltig'];
  $pc = $l['data'][0] ?? null;
  if ($pc && strcasecmp($pc['code'] ?? '', $code) === 0
      && (empty($pc['expires_at']) || $pc['expires_at'] > time())
      && (empty($pc['max_redemptions']) || ($pc['times_redeemed'] ?? 0) < $pc['max_redemptions'])) {
    $cid = $pc['promotion']['coupon'] ?? $pc['coupon'] ?? '';
    if (is_array($cid)) $cid = $cid['id'] ?? '';
    $cp = $cid ? sfc_liz_stripe('coupons/' . rawurlencode($cid), ['expand' => ['applies_to']]) : null;
    if ($cp === null) return $unbekannt;
    if (!empty($cp['valid']) && (empty($cp['amount_off']) || strtolower($cp['currency'] ?? '') === 'eur')) {
      $prod = $cp['applies_to']['products'] ?? [];
      $erg = ['status' => 'ok', 'code' => $pc['code'], 'betrag' => (int) ($cp['amount_off'] ?? 0), 'prozent' => (float) ($cp['percent_off'] ?? 0),
        'einzel' => !$prod || in_array(SFC_AC_PRODUKTE['einzel'], $prod, true), 'vergleich' => !$prod || in_array(SFC_AC_PRODUKTE['vergleich'], $prod, true)];
    }
  }
  set_transient($cache, $erg, 10 * MINUTE_IN_SECONDS);
  return new WP_REST_Response($erg, 200);
}

// ---------- Dateien schon in Schritt 2 hochladen und prüfen ----------
// Jede Datei kommt einzeln (eigene Anfrage), damit die Server-Grenze für eine Anfrage nicht für alle Dateien zusammen gilt.
// Der Bestell-Knopf schickt danach nur noch die Angaben und die Nummern der geprüften Dateien.
function sfc_ac_maxdatei() { return (int) min(10 * MB_IN_BYTES, wp_max_upload_size()); }

// prüft eine hochgeladene Datei; gibt [Endung, ''] oder ['', Fehlertext] zurück
function sfc_ac_datei_pruefen($f) {
  $mb = number_format_i18n(sfc_ac_maxdatei() / MB_IN_BYTES, 0);
  if (!$f) return ['', 'Keine Datei angekommen. Bitte noch einmal auswählen.'];
  if (in_array($f['error'], [UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE], true) || $f['size'] > sfc_ac_maxdatei()) return ['', "Die Datei ist größer als $mb MB. Bitte verkleinern (z. B. PDF komprimieren) oder als Fotos hochladen."];
  if ($f['error'] !== UPLOAD_ERR_OK) return ['', 'Die Übertragung wurde unterbrochen. Bitte noch einmal versuchen.'];
  $kopf = (string) file_get_contents($f['tmp_name'], false, null, 0, 1024);
  // PDF: am Inhalt erkennen ("%PDF-" in den ersten 1024 Bytes), nicht am Dateityp des Browsers
  if (strpos($kopf, '%PDF-') !== false) return ['pdf', ''];
  $bild = @getimagesize($f['tmp_name']);
  if ($bild && $bild[2] === IMAGETYPE_JPEG) return ['jpg', ''];
  if ($bild && $bild[2] === IMAGETYPE_PNG) return ['png', ''];
  if (preg_match('/\.(heic|heif)$/i', $f['name'])) return ['', 'iPhone-Fotos im HEIC-Format gehen leider nicht. Bitte als JPG oder PDF speichern.'];
  return ['', 'Diese Datei ist kein PDF, JPG oder PNG.'];
}

function sfc_ac_datei(WP_REST_Request $r) {
  if ($p = sfc_urlaub_pause_antwort()) return $p;
  $tok = preg_replace('/[^a-f0-9]/', '', (string) $r->get_param('token'));
  $feld = (string) $r->get_param('feld');
  if (strlen($tok) !== 32 || !in_array($feld, ['a1', 'a2', 'a3'], true)) return new WP_REST_Response(['ok' => false, 'fehler' => 'Ungültige Anfrage.'], 400);
  $rl = 'sfc_ac_drl_' . md5($_SERVER['REMOTE_ADDR'] ?? '');
  $n = (int) get_transient($rl);
  if ($n >= 60) return new WP_REST_Response(['ok' => false, 'fehler' => 'Zu viele Dateien in kurzer Zeit. Bitte später noch einmal versuchen.'], 429);
  set_transient($rl, $n + 1, HOUR_IN_SECONDS);
  $f = $_FILES['datei'] ?? null;
  [$ext, $fehler] = sfc_ac_datei_pruefen($f);
  if ($fehler) return new WP_REST_Response(['ok' => false, 'fehler' => $fehler], 422);
  $ordner = sfc_ea_ordner();
  // alte, nie bestellte Zwischendateien aufräumen (älter als 1 Tag)
  foreach ((array) glob("$ordner/tmp_*") as $alt) if (is_file($alt) && filemtime($alt) < time() - DAY_IN_SECONDS) @unlink($alt);
  $liste = get_transient("sfc_ac_tmp_$tok") ?: [];
  if (count($liste) >= 20) return new WP_REST_Response(['ok' => false, 'fehler' => 'Es sind schon sehr viele Dateien hochgeladen.'], 422);
  $nr = count($liste);
  $ziel = "$ordner/tmp_{$tok}_$nr.$ext";
  if (!move_uploaded_file($f['tmp_name'], $ziel)) return new WP_REST_Response(['ok' => false, 'fehler' => 'Die Datei konnte nicht gespeichert werden. Bitte noch einmal versuchen.'], 500);
  $liste[] = ['feld' => $feld, 'pfad' => $ziel, 'ext' => $ext, 'name' => sanitize_file_name($f['name'])];
  set_transient("sfc_ac_tmp_$tok", $liste, DAY_IN_SECONDS);
  return new WP_REST_Response(['ok' => true, 'nr' => $nr], 200);
}

function sfc_ac_auftrag(WP_REST_Request $r) {
  if ($p = sfc_urlaub_pause_antwort()) return $p;
  $d = json_decode((string) $r->get_param('daten'), true);
  if (!is_array($d) || !empty($d['website']) || !is_array($d['haus'] ?? null) || !is_array($d['kontakt'] ?? null)) return new WP_REST_Response(['ok' => false], 400);
  $t = fn($x, $n = 200) => mb_substr(sanitize_text_field((string) $x), 0, $n);
  $k = $d['kontakt'];
  $mail = sanitize_email($k['email'] ?? ''); $vor = $t($k['vorname'] ?? '', 80); $nach = $t($k['nachname'] ?? '', 80); $tel = $t($k['tel'] ?? '', 40);
  $haus = [];
  foreach ($d['haus'] as $hk => $hv) if (count($haus) < 20) $haus[$t($hk, 40)] = $t($hv, 120);
  if (!is_email($mail) || $nach === '' || !preg_match('/^\d{5}$/', $haus['PLZ'] ?? '')) return new WP_REST_Response(['ok' => false, 'fehler' => 'Es fehlen Angaben.'], 422);
  $tarif = ($d['tarif'] ?? '') === 'vergleich' ? 'vergleich' : 'einzel';

  // Schutz vor Missbrauch: max. 20 angelegte Aufträge pro IP und Stunde. Gezählt werden nur erfolgreich angelegte Aufträge,
  // Fehlversuche (z. B. fehlende Dateien) zählen nicht mit.
  $rl = 'sfc_ac_rl_' . md5($_SERVER['REMOTE_ADDR'] ?? '');
  $n = (int) get_transient($rl);
  if ($n >= 20) return new WP_REST_Response(['ok' => false, 'fehler' => 'Sie haben in der letzten Stunde schon sehr viele Aufträge angelegt.'], 429);

  $titel = "{$haus['PLZ']} – $nach – " . ($haus['Gewerk'] ?? 'Angebot');
  $pid = wp_insert_post(['post_type' => 'sfc_ac_auftrag', 'post_status' => 'private', 'post_title' => $titel]);
  if (!$pid || is_wp_error($pid)) return new WP_REST_Response(['ok' => false], 500);
  $id = 'AC' . wp_date('ymd') . '-' . $pid;

  // Dateien: in Schritt 2 einzeln hochgeladen und geprüft (sfc_ac_datei), hier nur noch umbenennen
  $ordner = sfc_ea_ordner(); $dateien = []; $namen = [];
  $tok = preg_replace('/[^a-f0-9]/', '', (string) ($d['token'] ?? ''));
  $liste = strlen($tok) === 32 ? (get_transient("sfc_ac_tmp_$tok") ?: []) : [];
  $nrs = array_slice(array_unique(array_map('intval', (array) ($d['dateien'] ?? []))), 0, 25);
  usort($nrs, fn($a, $b) => strcmp(($liste[$a]['feld'] ?? 'z') . sprintf('%03d', $a), ($liste[$b]['feld'] ?? 'z') . sprintf('%03d', $b)));
  foreach ($nrs as $nr) {
    $x = $liste[$nr] ?? null;
    if (!$x || !is_file($x['pfad'])) continue;
    $label = ['a1' => 'Angebot1', 'a2' => 'Angebot2', 'a3' => 'Angebot3'][$x['feld']];
    $name = "{$id}_{$label}_" . (count($dateien) + 1) . ".{$x['ext']}";
    if (@rename($x['pfad'], "$ordner/$name")) { $dateien[] = "$ordner/$name"; $namen[] = "$name ({$x['name']})"; }
  }
  if (!$dateien) {
    wp_delete_post($pid, true);
    return new WP_REST_Response(['ok' => false, 'neu' => true, 'fehler' => 'Ihre Dateien sind nicht mehr auf dem Server (zum Beispiel weil die Seite lange offen war). Bitte gehen Sie zu Schritt 2 und laden Sie das Angebot noch einmal hoch.'], 422);
  }
  delete_transient("sfc_ac_tmp_$tok");
  set_transient($rl, $n + 1, HOUR_IN_SECONDS);

  $text = "Auftragsnummer: $id\nPaket: " . ($tarif === 'vergleich' ? 'Angebotsvergleich (bis zu 3 Angebote, mit Gegenüberstellung), 79 €' : 'Angebotsbewertung (1 Angebot), 49 €') . "\n"
    . "Kunde: $vor $nach\nE-Mail: $mail\nTelefon: $tel\n\n";
  foreach ($haus as $hk => $hv) $text .= "$hk: $hv\n";
  $text .= "\nHinweis: je Upload-Feld ein Angebot; bei mehr Angeboten als gebucht wird nur das erste geprüft (Vergleich gegen Aufpreis 30 €: https://buy.stripe.com/14AeVfb0C7CrfyP3sD9Zm07).\n";
  $text .= "\nKurzcheck des Kunden: " . ($t($d['kurzcheck'] ?? '', 300) ?: '–') . "\nVorprüfung (automatisch, grob): " . $t($d['vorpruefung'] ?? '', 300) . "\n";
  $frage = mb_substr(sanitize_textarea_field((string) ($d['frage'] ?? '')), 0, 2000);
  $text .= "\nFrage des Kunden:\n" . ($frage !== '' ? $frage : '–') . "\n\nDateien:\n- " . implode("\n- ", $namen) . "\n";

  wp_update_post(['ID' => $pid, 'post_title' => "[wartet auf Zahlung] $id – $titel", 'post_content' => nl2br(esc_html($text))]);
  // gleiche Meta-Felder wie beim Energieausweis, damit dessen Zahlungsprüfung den Auftrag mit erledigt
  foreach (['_sfc_ea_status' => 'offen', '_sfc_ea_id' => $id, '_sfc_ea_kunde' => $mail, '_sfc_ea_nachname' => $nach, '_sfc_ea_titel' => $titel, '_sfc_ea_text' => $text, '_sfc_ea_dateien' => $dateien, '_sfc_ac_tarif' => $tarif] as $mk => $mv) update_post_meta($pid, $mk, $mv);
  wp_schedule_single_event(time() + 120, 'sfc_ea_zahlungen');
  return new WP_REST_Response(['ok' => true, 'id' => $id], 200);
}

// Nach Zahlungseingang (aufgerufen aus sfc_ea_versand): Auftrag mit Unterlagen an Stephan, Bestätigung an den Kunden
function sfc_ac_versand($pid, array $s) {
  $id = get_post_meta($pid, '_sfc_ea_id', true); $titel = get_post_meta($pid, '_sfc_ea_titel', true); $text = get_post_meta($pid, '_sfc_ea_text', true);
  $mail = get_post_meta($pid, '_sfc_ea_kunde', true); $name = get_post_meta($pid, '_sfc_ea_nachname', true);
  $vergleich = get_post_meta($pid, '_sfc_ac_tarif', true) === 'vergleich';
  $netto = (int) ($s['amount_subtotal'] ?? 0); $betrag = number_format((int) ($s['amount_total'] ?? 0) / 100, 2, ',', '.') . ' €';
  $warn = $vergleich && $netto > 0 && $netto < 7900 ? "\nACHTUNG: Vergleich gewählt, aber nur der Preis für ein Angebot bezahlt. Bitte nur ein Angebot prüfen oder nachfragen.\n" : '';
  // Anhänge bis SFC_AC_MAIL_MB, der Rest per Download-Link (nur für Administratoren)
  $anh = []; $links = []; $summe = 0;
  foreach (array_values(array_filter((array) get_post_meta($pid, '_sfc_ea_dateien', true), 'is_file')) as $i => $f) {
    $gr = filesize($f);
    if ($summe + $gr <= SFC_AC_MAIL_MB * MB_IN_BYTES) { $anh[] = $f; $summe += $gr; }
    else $links[] = basename($f) . ': ' . admin_url('admin-post.php?action=sfc_ac_datei&p=' . $pid . '&i=' . $i);
  }
  wp_update_post(['ID' => $pid, 'post_title' => str_replace('[wartet auf Zahlung]', '[bezahlt]', get_the_title($pid))]);
  $geruest = "Prüfbericht-Gerüst (zum Ausfüllen):\n1. Ihr Haus und Ihr Vorhaben\n2. Technik: Heizung = Größe/Heizlast, Vorlauftemperatur, Heizkörper, Warmwasser, Schall, hydraulischer Abgleich; Hülle = Dämmstoff, Stärke/U-Wert, Anschlüsse und Wärmebrücken, Luftdichtheit, Gerüst/Entsorgung; Fenster = Uw-Wert, Einbau (RAL), Lüftungskonzept\n"
    . "3. Preis: Gesamtpreis und auffällige Positionen, bei mehreren Angeboten Gegenüberstellung\n4. Förderung: technische Mindestanforderungen, förderfähige Kosten und Kostengrenze, Boni, Vertrag mit Förder-Bedingung, Antrag vor Beginn\n5. Fragen an den Installateur\n6. Fazit (ohne Empfehlung eines Betriebs, BEG Nr. 9.3)\n";
  wp_mail(SFC_EMPFAENGER, ($vergleich ? 'Angebotsvergleich' : 'Angebotsbewertung') . " $id: $titel (bezahlt)",
    "Neuer bezahlter Auftrag für eine Angebotsprüfung.\nBezahlt: $betrag (Stripe " . ($s['id'] ?? '') . ")\n$warn\n$text\n"
    . ($links ? "Nicht angehängt (zu groß für die Mail, Download nach Anmeldung in WordPress):\n" . implode("\n", $links) . "\n\n" : '')
    . $geruest . "\nDen Bericht bitte als PDF direkt an $mail schicken (Antworten an diese Mail gehen an den Kunden).\n",
    ["Reply-To: $name <$mail>"], $anh);
  wp_mail($mail, "Ihr Auftrag $id: Prüfung Ihrer Angebote",
    "Guten Tag,\n\nvielen Dank für Ihren Auftrag und Ihre Zahlung. Ihre Unterlagen sind bei mir angekommen.\n\n"
    . "Ich sehe mir Ihre Unterlagen persönlich an und schicke Ihnen den Prüfbericht als PDF per E-Mail, in der Regel am nächsten Werktag." . (sfc_urlaub() ? ' ' . sfc_urlaub_satz() : '') . " Bei Rückfragen melde ich mich bei Ihnen.\n\n"
    . "Bitte unterschreiben Sie bis dahin nichts, falls das noch nicht geschehen ist.\n\n"
    . "Mit freundlichen Grüßen\nStephan Hecky\nsENERGIEs Energieberatung\nMöchs 33, 91355 Hiltpoltstein · Tel. +49 155 65134339 · info@s-energies.de", ['Reply-To: sENERGIEs Energieberatung <' . SFC_EMPFAENGER . '>']);
}

// Download einzelner Dateien für Administratoren (Ordner ist von außen gesperrt)
add_action('admin_post_sfc_ac_datei', function () {
  if (!current_user_can('manage_options')) wp_die('Keine Berechtigung.', 403);
  $l = array_values(array_filter((array) get_post_meta((int) ($_GET['p'] ?? 0), '_sfc_ea_dateien', true), 'is_file'));
  $f = $l[(int) ($_GET['i'] ?? -1)] ?? '';
  if (!$f) wp_die('Datei nicht gefunden.', 404);
  nocache_headers();
  header('Content-Type: ' . (wp_check_filetype($f)['type'] ?: 'application/octet-stream'));
  header('Content-Disposition: attachment; filename="' . basename($f) . '"');
  header('Content-Length: ' . filesize($f));
  readfile($f); exit;
});
