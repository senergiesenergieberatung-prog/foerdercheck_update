<?php
// Online-Bedarfsausweis: Shortcode [sfc_bedarfsausweis], Bestellung mit Vorab-Prüfung, Zahlung über Stripe-Zahlungslink (client_reference_id = Bestellnummer).
// Nach bestätigter Zahlung (gleiche Prüfung wie beim Verbrauchsausweis, sfc_ea_zahlungen_pruefen) geht die Bestellung an arbeitsTAKT:
// dort entstehen Kunde, Projekt und der persönliche Aufnahme-Link, den arbeitsTAKT dem Kunden mailt.
// Attribute: zahlungslink="https://buy.stripe.com/…", preis="279 €", vorschau="1" (Hinweis „Testseite“ im Kopf), bild="…".
// Einstellungen → Online-Bedarfsausweis: arbeitsTAKT-Adresse und persönlicher arbeitsTAKT-Schlüssel (nur in der Datenbank, nie im Plugin).
if (!defined('ABSPATH')) exit;

const SFC_BA_PRODUKT = 'prod_Vb7ejXQ9n4o4WI'; // Stripe-Produkt „Online-Bedarfsausweis“
const SFC_BA_ZAHLUNGSLINK = 'https://buy.stripe.com/28EcN70lY3mbfyPaV59Zm08';              // Stripe-Zahlungslink 279 €

add_action('init', function () {
  register_post_type('sfc_ba_auftrag', [
    'label' => 'Bedarfsausweis-Aufträge', 'labels' => ['singular_name' => 'Bedarfsausweis-Auftrag'],
    'public' => false, 'show_ui' => true, 'show_in_menu' => 'edit.php?post_type=sfc_anfrage',
    'supports' => ['title', 'editor'], 'capability_type' => 'post',
    'capabilities' => ['create_posts' => 'do_not_allow'], 'map_meta_cap' => true,
  ]);
});

add_shortcode('sfc_bedarfsausweis', function ($atts = []) {
  $a = shortcode_atts(['zahlungslink' => SFC_BA_ZAHLUNGSLINK, 'preis' => '279 €', 'vorschau' => '0', 'bild' => content_url('uploads/2025/11/Welt_Beleuchtet.webp')], $atts);
  $dir = plugin_dir_path(__FILE__); $url = plugin_dir_url(__FILE__);
  wp_enqueue_style('sfc-ea', $url . sfc_datei($dir, 'ea.css'), [], null);
  wp_enqueue_style('sfc-ba', $url . sfc_datei($dir, 'ba.css'), ['sfc-ea'], null);
  wp_enqueue_script('sfc-ba', $url . sfc_datei($dir, 'ba.js'), [], null, ['in_footer' => true, 'strategy' => 'defer']);
  wp_add_inline_script('sfc-ba', 'window.SBA_CFG=' . wp_json_encode([
    'endpoint' => rest_url('sfc/v1/bedarfsausweis'), 'gutschein' => rest_url('sfc/v1/gutschein'), 'zahlung' => rest_url('sfc/v1/zahlung'),
    'zahlungslink' => esc_url_raw($a['zahlungslink']), 'preis' => $a['preis'], 'vorschau' => $a['vorschau'] === '1', 'bild' => esc_url_raw($a['bild']),
    'datenschutz' => get_privacy_policy_url() ?: home_url('/datenschutzerklaerung/')]) . ';', 'before');
  return str_replace('class="sea sba"', 'class="sea sba sea-wp"', file_get_contents($dir . 'ba.html'));
});

// Autoptimize nicht an das Skript lassen (wie beim Rechner)
add_filter('autoptimize_filter_js_exclude', function ($ex) { return $ex . ', sfc-foerdercheck/ba.'; });

add_action('rest_api_init', function () {
  register_rest_route('sfc/v1', '/bedarfsausweis', ['methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => 'sfc_ba_auftrag']);
});

function sfc_ba_txt($v, $max = 120) {
  return mb_substr(trim(sanitize_text_field((string) $v)), 0, $max);
}

function sfc_ba_auftrag(WP_REST_Request $r) {
  if (function_exists('sfc_urlaub_pause_antwort') && ($p = sfc_urlaub_pause_antwort())) return $p;
  $d = $r->get_json_params();
  if (!is_array($d) || !empty($d['website'])) return new WP_REST_Response(['ok' => false], 400);
  $g = array_map('sfc_ba_txt', array_intersect_key((array) ($d['gebaeude'] ?? []), array_flip(['strasse', 'hausnummer', 'plz', 'ort', 'baujahr', 'we', 'wohnflaeche', 'anlass', 'masse'])));
  $k = array_map('sfc_ba_txt', array_intersect_key((array) ($d['kunde'] ?? []), array_flip(['anrede', 'vorname', 'nachname', 'email', 'telefon', 'strasse', 'hausnummer', 'plz', 'ort'])));
  $k['email'] = sanitize_email($k['email'] ?? '');
  $anm = mb_substr(sanitize_textarea_field((string) ($d['anmerkung'] ?? '')), 0, 1500);
  if (!is_email($k['email']) || ($k['nachname'] ?? '') === '' || ($g['strasse'] ?? '') === '' || !preg_match('/^\d{5}$/', $g['plz'] ?? '') || ($g['ort'] ?? '') === '')
    return new WP_REST_Response(['ok' => false, 'fehler' => 'Es fehlen Angaben.'], 422);
  if ((int) ($g['we'] ?? 0) > 2 || (int) ($g['wohnflaeche'] ?? 0) > 200)
    return new WP_REST_Response(['ok' => false, 'fehler' => 'Der Online-Preis gilt bis 2 Wohnungen und 200 m².'], 422);

  // max. 5 Bestellungen pro IP und Stunde
  $key = 'sfc_ba_rl_' . md5($_SERVER['REMOTE_ADDR'] ?? '');
  $n = (int) get_transient($key);
  if ($n >= 5) return new WP_REST_Response(['ok' => false, 'fehler' => 'Zu viele Bestellungen in kurzer Zeit.'], 429);
  set_transient($key, $n + 1, HOUR_IN_SECONDS);

  $titel = "{$g['strasse']} {$g['hausnummer']}, {$g['plz']} {$g['ort']} – {$k['nachname']}";
  $pid = wp_insert_post(['post_type' => 'sfc_ba_auftrag', 'post_status' => 'private', 'post_title' => $titel]);
  if (!$pid || is_wp_error($pid)) return new WP_REST_Response(['ok' => false], 500);
  $id = 'BA' . wp_date('ymd') . '-' . $pid;

  $text = "Bestellnummer: $id\nGebäude: {$g['strasse']} {$g['hausnummer']}, {$g['plz']} {$g['ort']}\n"
    . "Baujahr / Wohnungen / Wohnfläche: {$g['baujahr']} / {$g['we']} / ca. {$g['wohnflaeche']} m²\nAnlass: {$g['anlass']}\nAußenmaße/Fotos möglich: {$g['masse']}\n"
    . "Kunde: " . trim("{$k['anrede']} {$k['vorname']} {$k['nachname']}") . ", {$k['strasse']} {$k['hausnummer']}, {$k['plz']} {$k['ort']}\nE-Mail: {$k['email']}\nTelefon: {$k['telefon']}\n"
    . ($anm !== '' ? "Anmerkung: $anm\n" : '');
  wp_update_post(['ID' => $pid, 'post_title' => "[wartet auf Zahlung] $id – $titel", 'post_content' => nl2br(esc_html($text))]);
  update_post_meta($pid, '_sfc_ea_status', 'offen');
  update_post_meta($pid, '_sfc_ea_id', $id);
  update_post_meta($pid, '_sfc_ea_kunde', $k['email']);
  update_post_meta($pid, '_sfc_ea_nachname', $k['nachname']);
  update_post_meta($pid, '_sfc_ea_titel', $titel);
  update_post_meta($pid, '_sfc_ea_text', $text);
  update_post_meta($pid, '_sfc_ba_daten', ['gebaeude' => $g, 'kunde' => $k, 'anmerkung' => $anm]);
  wp_schedule_single_event(time() + 120, 'sfc_ea_zahlungen'); // kurz nach der Zahlung einmal extra nachsehen
  return new WP_REST_Response(['ok' => true, 'id' => $id], 200);
}

// ---------- Übergabe an arbeitsTAKT ----------
function sfc_ba_arbeitstakt($pid) {
  $basis = untrailingslashit((string) get_option('sfc_ba_at_url', ''));
  $schluessel = (string) get_option('sfc_ba_at_schluessel', '');
  if ($basis === '' || $schluessel === '') return ['ok' => false, 'fehler' => 'arbeitsTAKT-Adresse oder Schlüssel fehlt (Einstellungen → Online-Bedarfsausweis).'];
  $d = (array) get_post_meta($pid, '_sfc_ba_daten', true);
  $g = (array) ($d['gebaeude'] ?? []); $k = (array) ($d['kunde'] ?? []);
  $anm = trim("Baujahr {$g['baujahr']}, {$g['we']} Wohnung(en), ca. {$g['wohnflaeche']} m², Anlass: {$g['anlass']}, Außenmaße/Fotos möglich: {$g['masse']}" . (($d['anmerkung'] ?? '') !== '' ? "\n" . $d['anmerkung'] : ''));
  $body = [
    'nummer' => get_post_meta($pid, '_sfc_ea_id', true),
    'kunde' => ['vorname' => $k['vorname'] ?? '', 'nachname' => $k['nachname'] ?? '', 'email' => $k['email'] ?? '', 'telefon' => $k['telefon'] ?? '',
      'strasse' => $k['strasse'] ?? '', 'hausnummer' => $k['hausnummer'] ?? '', 'plz' => $k['plz'] ?? '', 'ort' => $k['ort'] ?? ''],
    'gebaeude' => ['strasse' => $g['strasse'] ?? '', 'hausnummer' => $g['hausnummer'] ?? '', 'plz' => $g['plz'] ?? '', 'ort' => $g['ort'] ?? ''],
    'anmerkung' => $anm,
  ];
  $betrag = get_post_meta($pid, '_sfc_ba_betrag', true);
  if ($betrag !== '') $body['betrag'] = (float) $betrag;
  $body['bezahlt_am'] = wp_date('d.m.Y');
  $r = wp_remote_post($basis . '/api/bestellung', ['timeout' => 25, 'headers' => ['Authorization' => 'Bearer ' . $schluessel, 'Content-Type' => 'application/json'], 'body' => wp_json_encode($body)]);
  if (is_wp_error($r)) return ['ok' => false, 'fehler' => $r->get_error_message()];
  $j = json_decode(wp_remote_retrieve_body($r), true);
  if (wp_remote_retrieve_response_code($r) !== 200 || empty($j['ok'])) return ['ok' => false, 'fehler' => wp_remote_retrieve_response_code($r) . ' ' . substr((string) ($j['fehler'] ?? ''), 0, 300)];
  return ['ok' => true, 'mail' => !empty($j['mail_gesendet']), 'projekt' => (string) ($j['projekt']['nummer'] ?? ''), 'link' => (string) ($j['projekt']['link'] ?? '')];
}

// Aufruf aus sfc_ea_versand, sobald Stripe die Zahlung bestätigt hat
function sfc_ba_versand($pid, array $s) {
  update_post_meta($pid, '_sfc_ba_betrag', round(((int) ($s['amount_total'] ?? 0)) / 100, 2));
  $id = get_post_meta($pid, '_sfc_ea_id', true); $titel = get_post_meta($pid, '_sfc_ea_titel', true); $text = get_post_meta($pid, '_sfc_ea_text', true);
  $mail = get_post_meta($pid, '_sfc_ea_kunde', true); $name = get_post_meta($pid, '_sfc_ea_nachname', true);
  $betrag = number_format(((int) ($s['amount_total'] ?? 0)) / 100, 2, ',', '.') . ' €';
  $at = sfc_ba_arbeitstakt($pid);
  update_post_meta($pid, '_sfc_ba_at', $at['ok'] ? 'ok' : 'fehler');
  update_post_meta($pid, '_sfc_ba_at_versuche', 1);
  wp_update_post(['ID' => $pid, 'post_title' => str_replace('[wartet auf Zahlung]', $at['ok'] ? '[bezahlt]' : '[bezahlt, arbeitsTAKT fehlt]', get_the_title($pid))]);
  $stand = $at['ok']
    ? "In arbeitsTAKT angelegt" . ($at['projekt'] ? " (Projekt {$at['projekt']})" : '') . '. ' . ($at['mail'] ? 'Der Kunde hat seinen Link per Mail bekommen.' : 'ACHTUNG: Die Link-Mail an den Kunden ging nicht raus, bitte im Projekt „Link neu senden“.') . ($at['link'] ? "\n{$at['link']}" : '')
    : "ACHTUNG: Die Übergabe an arbeitsTAKT hat nicht geklappt ({$at['fehler']}). Die Website versucht es alle 5 Minuten erneut (bis zu 12-mal). Der Kunde hat noch keinen Link.";
  wp_mail(SFC_EMPFAENGER, "Online-Bedarfsausweis $id: $titel (bezahlt)",
    "Neue bezahlte Bestellung für einen Online-Bedarfsausweis.\nBezahlt: $betrag (Stripe " . ($s['id'] ?? '') . ")\n\n$stand\n\n$text", ["Reply-To: $name <$mail>"]);
  wp_mail($mail, "Ihre Bestellung $id: Online-Bedarfsausweis",
    "Guten Tag,\n\nvielen Dank für Ihre Bestellung und Ihre Zahlung für einen Bedarfsausweis für $titel.\n\n"
    . "Sie erhalten in wenigen Minuten eine zweite E-Mail mit Ihrem persönlichen Link. Darüber erfassen Sie Ihr Haus Schritt für Schritt und können jederzeit zwischenspeichern. Bitte schauen Sie auch im Spam-Ordner nach.\n\n"
    . "Sobald Sie Ihre Angaben abgeschickt haben, prüfe ich sie persönlich und melde mich bei Rückfragen. Den fertigen Ausweis erhalten Sie als PDF per E-Mail." . (function_exists('sfc_urlaub') && sfc_urlaub() ? ' ' . sfc_urlaub_satz() : '') . "\n\n"
    . "Mit freundlichen Grüßen\nStephan Hecky\nsENERGIEs Energieberatung\nMöchs 33, 91355 Hiltpoltstein · Tel. +49 155 65134339 · info@s-energies.de", ['Reply-To: sENERGIEs Energieberatung <' . SFC_EMPFAENGER . '>']);
}

// Fehlgeschlagene Übergaben bei jedem Lauf der Zahlungsprüfung erneut versuchen
add_action('sfc_ea_zahlungen', function () {
  $liste = get_posts(['post_type' => 'sfc_ba_auftrag', 'post_status' => 'private', 'numberposts' => 10, 'meta_key' => '_sfc_ba_at', 'meta_value' => 'fehler']);
  foreach ($liste as $p) {
    $n = (int) get_post_meta($p->ID, '_sfc_ba_at_versuche', true);
    if ($n >= 12) continue;
    update_post_meta($p->ID, '_sfc_ba_at_versuche', $n + 1);
    $at = sfc_ba_arbeitstakt($p->ID);
    if (!$at['ok']) continue;
    update_post_meta($p->ID, '_sfc_ba_at', 'ok');
    wp_update_post(['ID' => $p->ID, 'post_title' => str_replace('[bezahlt, arbeitsTAKT fehlt]', '[bezahlt]', $p->post_title)]);
    $id = get_post_meta($p->ID, '_sfc_ea_id', true);
    wp_mail(SFC_EMPFAENGER, "Online-Bedarfsausweis $id: jetzt in arbeitsTAKT", "Die Bestellung $id ist im zweiten Anlauf in arbeitsTAKT angelegt" . ($at['projekt'] ? " (Projekt {$at['projekt']})" : '') . '. ' . ($at['mail'] ? 'Der Kunde hat seinen Link bekommen.' : 'Die Link-Mail ging nicht raus, bitte im Projekt „Link neu senden“.'));
  }
}, 20);

add_action('admin_menu', function () {
  add_options_page('Online-Bedarfsausweis', 'Online-Bedarfsausweis', 'manage_options', 'sfc-bedarfsausweis', function () {
    if (isset($_POST['sfc_ba_save']) && check_admin_referer('sfc_ba_save')) {
      update_option('sfc_ba_at_url', esc_url_raw(trim(wp_unslash($_POST['at_url'] ?? ''))), false);
      $k = trim(sanitize_text_field(wp_unslash($_POST['at_schluessel'] ?? '')));
      if ($k !== '') update_option('sfc_ba_at_schluessel', $k, false);
      echo '<div class="updated"><p>Gespeichert.</p></div>';
    }
    if (isset($_POST['sfc_ba_test']) && check_admin_referer('sfc_ba_save')) {
      $basis = untrailingslashit((string) get_option('sfc_ba_at_url', ''));
      $r = wp_remote_post($basis . '/api/bestellung', ['timeout' => 15, 'headers' => ['Authorization' => 'Bearer ' . get_option('sfc_ba_at_schluessel', ''), 'Content-Type' => 'application/json'], 'body' => '{}']);
      $c = is_wp_error($r) ? $r->get_error_message() : wp_remote_retrieve_response_code($r);
      // 400 = Schlüssel gültig, nur die (absichtlich leere) Bestellung fehlt
      echo '<div class="' . ($c === 400 ? 'updated' : 'error') . '"><p>' . ($c === 400 ? 'Verbindung zu arbeitsTAKT klappt, der Schlüssel ist gültig.' : 'Verbindung klappt nicht: ' . esc_html((string) $c) . ' ' . esc_html(is_wp_error($r) ? '' : substr(wp_remote_retrieve_body($r), 0, 200))) . '</p></div>';
    }
    $hat = get_option('sfc_ba_at_schluessel', '') !== '';
    echo '<div class="wrap"><h1>Online-Bedarfsausweis</h1><p>Nach bestätigter Zahlung legt die Website die Bestellung in arbeitsTAKT an. arbeitsTAKT mailt dem Kunden den persönlichen Link zur Erfassung seines Hauses.</p>';
    echo '<form method="post">'; wp_nonce_field('sfc_ba_save');
    echo '<table class="form-table"><tr><th><label for="at_url">arbeitsTAKT-Adresse</label></th><td><input id="at_url" name="at_url" class="regular-text" value="' . esc_attr(get_option('sfc_ba_at_url', '')) . '" placeholder="https://…"><p class="description">Die Adresse, unter der Sie arbeitsTAKT im Browser öffnen, ohne Pfad.</p></td></tr>';
    echo '<tr><th><label for="at_schluessel">arbeitsTAKT-Schlüssel</label></th><td><input type="password" id="at_schluessel" name="at_schluessel" class="regular-text" autocomplete="off" placeholder="' . ($hat ? 'gespeichert, nur zum Ändern neu eintragen' : 'ses_mcp_…') . '"><p class="description">In arbeitsTAKT unter Einstellungen einen persönlichen Schlüssel erstellen (wie für die Claude-App).</p></td></tr></table>';
    echo '<p><button class="button button-primary" name="sfc_ba_save" value="1">Speichern</button> <button class="button" name="sfc_ba_test" value="1">Verbindung testen</button></p></form></div>';
  });
});
