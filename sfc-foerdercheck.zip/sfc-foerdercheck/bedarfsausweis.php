<?php
// Online-Bedarfsausweis: Shortcode [sfc_bedarfsausweis], Bestellung mit Vorab-Prüfung, Zahlung über Stripe-Zahlungslink (client_reference_id = Bestellnummer).
// Nach bestätigter Zahlung (gleiche Prüfung wie beim Verbrauchsausweis, sfc_ea_zahlungen_pruefen) geht die Bestellung an arbeitsTAKT:
// dort entstehen Kunde, Projekt und der persönliche Aufnahme-Link, den arbeitsTAKT dem Kunden mailt.
// Attribute: zahlungslink="https://buy.stripe.com/…", preis="279 €", vorschau="1" (Hinweis „Testseite“ im Kopf), bild="…".
// Einstellungen → Online-Bedarfsausweis: arbeitsTAKT-Adresse und persönlicher arbeitsTAKT-Schlüssel (nur in der Datenbank, nie im Plugin).
if (!defined('ABSPATH')) exit;

const SFC_BA_PRODUKT = 'prod_Vb7ejXQ9n4o4WI'; // Stripe-Produkt „Online-Bedarfsausweis“
const SFC_BA_ZAHLUNGSLINK = 'https://buy.stripe.com/28EcN70lY3mbfyPaV59Zm08';
const SFC_BA_ZAHLUNGSLINK_VIDEO = 'https://buy.stripe.com/6oU28t3yaaODfyP0gr9Zm09'; // 279 € + Video-Termin 99 €
const SFC_BA_PREISE = ['grund' => 'price_1UZvP9PygzhGZSqqEUpcBBKR', 'we' => 'price_1UZw3JPygzhGZSqqCZo6NV5Y', 'flaeche' => 'price_1UZwEiPygzhGZSqqNIQWOuzz', 'video' => 'price_1UZw2MPygzhGZSqqGYOXe31I'];
// Ersatz, falls die Checkout-Sitzung nicht angelegt werden kann: Stripe-Zahlungslinks je Anzahl Wohnungen: [ohne Video, mit Video]; +50 € je Wohnung ab der dritten (prod_Vb8JNIn9qKeJzK)
const SFC_BA_LINKS = [
  '3' => ['https://buy.stripe.com/aFa28t1q209Z72j2oz9Zm0a', 'https://buy.stripe.com/4gMeVf6Km9KzbizbZ99Zm0e'],
  '4' => ['https://buy.stripe.com/bJe3cxb0C09Z5Yf5AL9Zm0b', 'https://buy.stripe.com/9B64gB7Oq5ujdqHe7h9Zm0f'],
  '5' => ['https://buy.stripe.com/8x2bJ37Oq1e3euL9R19Zm0c', 'https://buy.stripe.com/4gMcN78Su09Zbiz3sD9Zm0g'],
  '6' => ['https://buy.stripe.com/3cIaEZc4G5ujdqH4wH9Zm0d', 'https://buy.stripe.com/fZudRb9Wy3mb5Yf0gr9Zm0h'],
];              // Stripe-Zahlungslink 279 €

add_action('init', function () {
  register_post_type('sfc_ba_auftrag', [
    'label' => 'Bedarfsausweis-Aufträge', 'labels' => ['singular_name' => 'Bedarfsausweis-Auftrag'],
    'public' => false, 'show_ui' => true, 'show_in_menu' => 'edit.php?post_type=sfc_anfrage',
    'supports' => ['title', 'editor'], 'capability_type' => 'post',
    'capabilities' => ['create_posts' => 'do_not_allow'], 'map_meta_cap' => true,
  ]);
});

add_shortcode('sfc_bedarfsausweis', function ($atts = []) {
  $a = shortcode_atts(['zahlungslink' => SFC_BA_ZAHLUNGSLINK, 'zahlungslink_video' => SFC_BA_ZAHLUNGSLINK_VIDEO, 'preis' => '279 €', 'vorschau' => '0', 'bild' => content_url('uploads/2025/11/Welt_Beleuchtet.webp')], $atts);
  $dir = plugin_dir_path(__FILE__); $url = plugin_dir_url(__FILE__);
  wp_enqueue_style('sfc-ea', $url . sfc_datei($dir, 'ea.css'), [], null);
  wp_enqueue_style('sfc-ba', $url . sfc_datei($dir, 'ba.css'), ['sfc-ea'], null);
  wp_enqueue_script('sfc-ba', $url . sfc_datei($dir, 'ba.js'), [], null, ['in_footer' => true, 'strategy' => 'defer']);
  wp_add_inline_script('sfc-ba', 'window.SBA_CFG=' . wp_json_encode([
    'endpoint' => rest_url('sfc/v1/bedarfsausweis'), 'mailcheck' => rest_url('sfc/v1/mailcheck'), 'gutschein' => rest_url('sfc/v1/gutschein'), 'zahlung' => rest_url('sfc/v1/zahlung'),
    'zahlungslink' => esc_url_raw($a['zahlungslink']), 'zahlungslink_video' => esc_url_raw($a['zahlungslink_video']), 'preis_video' => 99, 'links' => ['2' => [esc_url_raw($a['zahlungslink']), esc_url_raw($a['zahlungslink_video'])]] + SFC_BA_LINKS, 'preis' => $a['preis'], 'vorschau' => $a['vorschau'] === '1', 'bild' => esc_url_raw($a['bild']),
    'datenschutz' => get_privacy_policy_url() ?: home_url('/datenschutzerklaerung/')]) . ';', 'before');
  return str_replace('class="sea sba"', 'class="sea sba sea-wp"', file_get_contents($dir . 'ba.html'));
});

// Autoptimize nicht an das Skript lassen (wie beim Rechner)
add_filter('autoptimize_filter_js_exclude', function ($ex) { return $ex . ', sfc-foerdercheck/ba.'; });

add_action('rest_api_init', function () {
  register_rest_route('sfc/v1', '/bedarfsausweis', ['methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => 'sfc_ba_auftrag']);
  register_rest_route('sfc/v1', '/mailcheck', ['methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => function (WP_REST_Request $r) {
    $key = 'sfc_ba_mc_' . md5($_SERVER['REMOTE_ADDR'] ?? '');
    $n = (int) get_transient($key);
    if ($n >= 30) return new WP_REST_Response(['ok' => null], 200);
    set_transient($key, $n + 1, HOUR_IN_SECONDS);
    return new WP_REST_Response(['ok' => sfc_ba_mail_ok((string) $r->get_param('mail'))], 200);
  }]);
});

// E-Mail-Adresse: Form gültig und Domain nimmt Mails an (MX-, ersatzweise A-Eintrag). null = nicht prüfbar
function sfc_ba_mail_ok($mail) {
  $mail = sanitize_email($mail);
  if (!is_email($mail)) return false;
  $dom = strtolower(substr(strrchr($mail, '@'), 1));
  $c = get_transient('sfc_ba_dom_' . md5($dom));
  if ($c !== false) return $c === '1';
  if (!function_exists('checkdnsrr')) return null;
  $ok = checkdnsrr($dom . '.', 'MX') || checkdnsrr($dom . '.', 'A');
  set_transient('sfc_ba_dom_' . md5($dom), $ok ? '1' : '0', DAY_IN_SECONDS);
  return $ok;
}
// Deutsche Handynummer (015x, 016x, 017x), Rückgabe ohne Leerzeichen mit führender 0, sonst ''
function sfc_ba_handy($t) {
  $z = preg_replace('/^(\+49|0049)/', '0', preg_replace('/[\s\-\/().]/', '', (string) $t));
  return preg_match('/^01[567]\d{8,9}$/', $z) ? $z : '';
}

function sfc_ba_txt($v, $max = 120) {
  return mb_substr(trim(sanitize_text_field((string) $v)), 0, $max);
}

function sfc_ba_auftrag(WP_REST_Request $r) {
  if (function_exists('sfc_urlaub_pause_antwort') && ($p = sfc_urlaub_pause_antwort())) return $p;
  $d = $r->get_json_params();
  if (!is_array($d) || !empty($d['website'])) return new WP_REST_Response(['ok' => false], 400);
  $g = array_map('sfc_ba_txt', array_intersect_key((array) ($d['gebaeude'] ?? []), array_flip(['strasse', 'hausnummer', 'plz', 'ort', 'baujahr', 'we', 'wohnflaeche', 'anlass', 'masse'])));
  $k = array_map('sfc_ba_txt', array_intersect_key((array) ($d['kunde'] ?? []), array_flip(['anrede', 'vorname', 'nachname', 'email', 'telefon', 'strasse', 'hausnummer', 'plz', 'ort'])));
  $k['email'] = sanitize_email($k['email'] ?? '');
  $video = !empty($d['video']);
  $anm = mb_substr(sanitize_textarea_field((string) ($d['anmerkung'] ?? '')), 0, 1500);
  if (sfc_ba_mail_ok($k['email']) === false) return new WP_REST_Response(['ok' => false, 'fehler' => 'Bitte die E-Mail-Adresse prüfen.'], 422);
  $k['telefon'] = sfc_ba_handy($k['telefon'] ?? '');
  if ($k['telefon'] === '') return new WP_REST_Response(['ok' => false, 'fehler' => 'Bitte eine deutsche Handynummer angeben.'], 422);
  if (!is_email($k['email']) || ($k['nachname'] ?? '') === '' || ($g['strasse'] ?? '') === '' || !preg_match('/^\d{5}$/', $g['plz'] ?? '') || ($g['ort'] ?? '') === '')
    return new WP_REST_Response(['ok' => false, 'fehler' => 'Es fehlen Angaben.'], 422);
  $we = (int) ($g['we'] ?? 0);
  $wfl = (int) ($g['wohnflaeche'] ?? 0);
  if ($we < 1 || $we > 6 || ($we <= 2 && $wfl > 400))
    return new WP_REST_Response(['ok' => false, 'fehler' => 'Online geht es bis 6 Wohnungen, bei Ein- und Zweifamilienhäusern bis 400 m².'], 422);

  // max. 5 Bestellungen pro IP und Stunde
  $key = 'sfc_ba_rl_' . md5($_SERVER['REMOTE_ADDR'] ?? '');
  $n = (int) get_transient($key);
  if ($n >= 5) return new WP_REST_Response(['ok' => false, 'fehler' => 'Zu viele Bestellungen in kurzer Zeit.'], 429);
  set_transient($key, $n + 1, HOUR_IN_SECONDS);

  $titel = "{$g['strasse']} {$g['hausnummer']}, {$g['plz']} {$g['ort']} – {$k['nachname']}";
  $pid = wp_insert_post(['post_type' => 'sfc_ba_auftrag', 'post_status' => 'private', 'post_title' => $titel]);
  if (!$pid || is_wp_error($pid)) return new WP_REST_Response(['ok' => false], 500);
  $id = 'BA' . wp_date('ymd') . '-' . $pid;

  $text = "Bestellnummer: $id\nGebäude: {$g['strasse']} {$g['hausnummer']}, {$g['plz']} {$g['ort']}\n"
    . "Baujahr / Wohnungen / Wohnfläche: {$g['baujahr']} / {$g['we']} / ca. {$g['wohnflaeche']} m²\nAnlass: {$g['anlass']}\nAußenmaße/Fotos möglich: {$g['masse']}\nVideo-Termin: " . ($video ? 'JA, gebucht (+99 €), bitte Termin vereinbaren' : 'nein') . "\n"
    . "Kunde: " . trim("{$k['anrede']} {$k['vorname']} {$k['nachname']}") . ", {$k['strasse']} {$k['hausnummer']}, {$k['plz']} {$k['ort']}\nE-Mail: {$k['email']}\nTelefon: {$k['telefon']}\n"
    . ($anm !== '' ? "Anmerkung: $anm\n" : '');
  wp_update_post(['ID' => $pid, 'post_title' => "[wartet auf Zahlung] $id – $titel", 'post_content' => nl2br(esc_html($text))]);
  update_post_meta($pid, '_sfc_ea_status', 'offen');
  update_post_meta($pid, '_sfc_ea_id', $id);
  update_post_meta($pid, '_sfc_ea_kunde', $k['email']);
  update_post_meta($pid, '_sfc_ea_nachname', $k['nachname']);
  update_post_meta($pid, '_sfc_ea_titel', $titel);
  update_post_meta($pid, '_sfc_ea_text', $text);
  update_post_meta($pid, '_sfc_ba_daten', ['gebaeude' => $g, 'kunde' => $k, 'anmerkung' => $anm, 'video' => $video]);
  wp_schedule_single_event(time() + 120, 'sfc_ea_zahlungen'); // kurz nach der Zahlung einmal extra nachsehen
  // Zahlungsseite bei Stripe mit genau dem Betrag aus den Angaben (Grundpreis, Wohnungen, Fläche, Video)
  $url = sfc_ba_checkout($id, $k['email'], $we, $wfl, $video, (string) ($d['gutschein'] ?? ''), (string) ($d['seite'] ?? ''));
  update_post_meta($pid, '_sfc_ba_soll', sfc_ba_preis($we, $wfl, $video));
  return new WP_REST_Response(['ok' => true, 'id' => $id, 'url' => $url], 200);
}

// Preis in Cent: 279 € + 50 € je Wohnung ab der dritten + 1 €/m² über 200 m² (nur 1–2 Wohnungen) + 99 € Video
function sfc_ba_preis($we, $wfl, $video) {
  return 27900 + 5000 * max(0, $we - 2) + ($we <= 2 ? 100 * max(0, $wfl - 200) : 0) + ($video ? 9900 : 0);
}

// Checkout-Sitzung anlegen (eingeschränkter Schlüssel braucht „Checkout Sessions: Schreiben“). Liefert die URL oder '' (dann Zahlungslink als Ersatz).
function sfc_ba_checkout($id, $mail, $we, $wfl, $video, $code, $seite) {
  $key = (string) get_option('sfc_liz_stripe_key', '');
  if ($key === '') return '';
  $home = wp_parse_url(home_url(), PHP_URL_HOST);
  if (!$seite || wp_parse_url($seite, PHP_URL_HOST) !== $home) $seite = home_url('/');
  $seite = remove_query_arg(['danke', 'session_id', 'code'], $seite);
  $items = [['price' => SFC_BA_PREISE['grund'], 'quantity' => 1]];
  if ($we > 2) $items[] = ['price' => SFC_BA_PREISE['we'], 'quantity' => $we - 2];
  if ($we <= 2 && $wfl > 200) $items[] = ['price' => SFC_BA_PREISE['flaeche'], 'quantity' => $wfl - 200];
  if ($video) $items[] = ['price' => SFC_BA_PREISE['video'], 'quantity' => 1];
  $teile = ($we > 2 ? ", $we Wohneinheiten" : '') . ($we <= 2 && $wfl > 200 ? ", $wfl m² Wohnfläche" : '') . ($video ? ', mit Video-Termin' : '');
  $q = [
    'mode' => 'payment', 'line_items' => $items, 'client_reference_id' => $id, 'customer_email' => $mail,
    'automatic_tax' => ['enabled' => 'true'], 'billing_address_collection' => 'required', 'customer_creation' => 'if_required',
    'invoice_creation' => ['enabled' => 'true', 'invoice_data' => ['description' => 'Erstellung eines DIBt-registrierten Bedarfsausweises für ein Wohngebäude (Online-Datenaufnahme)' . $teile, 'footer' => 'sENERGIEs Energieberatung · Möchs 33, 91355 Hiltpoltstein · info@s-energies.de']],
    'custom_text' => ['submit' => ['message' => 'Gleich nach der Zahlung erhalten Sie per E-Mail Ihren persönlichen Link zur Erfassung Ihres Hauses.' . ($video ? ' Den Video-Termin vereinbare ich mit Ihnen.' : '') . ' Die Rechnung kommt ebenfalls per E-Mail.']],
    'success_url' => add_query_arg('danke', '1', $seite) . '&session_id={CHECKOUT_SESSION_ID}', 'cancel_url' => $seite,
    'metadata' => ['ses_app' => 'bedarfsausweis', 'bestellung' => $id],
  ];
  $code = strtoupper(preg_replace('/[^A-Za-z0-9_-]/', '', $code));
  $pc = $code !== '' && function_exists('sfc_liz_stripe') ? sfc_liz_stripe('promotion_codes', ['code' => $code, 'active' => 'true', 'limit' => 1]) : null;
  if (!empty($pc['data'][0]['id']) && strcasecmp($pc['data'][0]['code'] ?? '', $code) === 0) $q['discounts'] = [['promotion_code' => $pc['data'][0]['id']]];
  else $q['allow_promotion_codes'] = 'true';
  $r = wp_remote_post('https://api.stripe.com/v1/checkout/sessions', ['timeout' => 15, 'headers' => ['Authorization' => 'Bearer ' . $key], 'body' => http_build_query($q)]);
  $j = is_wp_error($r) ? null : json_decode(wp_remote_retrieve_body($r), true);
  if (empty($j['url'])) {
    if (!get_transient('sfc_ba_co_warnung')) {
      set_transient('sfc_ba_co_warnung', 1, DAY_IN_SECONDS);
      wp_mail(SFC_EMPFAENGER, 'Bedarfsausweis: Stripe-Zahlungsseite konnte nicht angelegt werden', "Bestellung $id: " . (is_wp_error($r) ? $r->get_error_message() : substr(wp_remote_retrieve_body($r), 0, 400)) . "\n\nBitte prüfen: Hat der Stripe-Schlüssel unter Einstellungen → Fördercheck-Lizenzen das Recht „Checkout Sessions: Schreiben“? Bis dahin nutzt die Seite die festen Zahlungslinks (ohne Flächen-Aufpreis).");
    }
    return '';
  }
  return (string) $j['url'];
}

// ---------- Übergabe an arbeitsTAKT ----------
function sfc_ba_arbeitstakt($pid) {
  $basis = untrailingslashit((string) get_option('sfc_ba_at_url', ''));
  $schluessel = (string) get_option('sfc_ba_at_schluessel', '');
  if ($basis === '' || $schluessel === '') return ['ok' => false, 'fehler' => 'arbeitsTAKT-Adresse oder Schlüssel fehlt (Einstellungen → Online-Bedarfsausweis).'];
  $d = (array) get_post_meta($pid, '_sfc_ba_daten', true);
  $g = (array) ($d['gebaeude'] ?? []); $k = (array) ($d['kunde'] ?? []);
  $anm = trim("Baujahr {$g['baujahr']}, {$g['we']} Wohnung(en), ca. {$g['wohnflaeche']} m², Anlass: {$g['anlass']}, Außenmaße/Fotos möglich: {$g['masse']}" . (!empty($d['video']) ? ', Video-Termin gebucht (+99 €)' : '') . (($d['anmerkung'] ?? '') !== '' ? "\n" . $d['anmerkung'] : ''));
  $body = [
    'nummer' => get_post_meta($pid, '_sfc_ea_id', true),
    'kunde' => ['vorname' => $k['vorname'] ?? '', 'nachname' => $k['nachname'] ?? '', 'email' => $k['email'] ?? '', 'telefon' => $k['telefon'] ?? '',
      'strasse' => $k['strasse'] ?? '', 'hausnummer' => $k['hausnummer'] ?? '', 'plz' => $k['plz'] ?? '', 'ort' => $k['ort'] ?? ''],
    'gebaeude' => ['strasse' => $g['strasse'] ?? '', 'hausnummer' => $g['hausnummer'] ?? '', 'plz' => $g['plz'] ?? '', 'ort' => $g['ort'] ?? ''],
    'anmerkung' => $anm,
  ];
  $betrag = get_post_meta($pid, '_sfc_ba_betrag', true);
  if ($betrag !== '') $body['betrag'] = (float) $betrag;
  $body['bezahlt_am'] = wp_date('d.m.Y');
  $r = wp_remote_post($basis . '/api/bestellung', ['timeout' => 25, 'headers' => ['Authorization' => 'Bearer ' . $schluessel, 'Content-Type' => 'application/json'], 'body' => wp_json_encode($body)]);
  if (is_wp_error($r)) return ['ok' => false, 'fehler' => $r->get_error_message()];
  $j = json_decode(wp_remote_retrieve_body($r), true);
  if (wp_remote_retrieve_response_code($r) !== 200 || empty($j['ok'])) return ['ok' => false, 'fehler' => wp_remote_retrieve_response_code($r) . ' ' . substr((string) ($j['fehler'] ?? ''), 0, 300)];
  return ['ok' => true, 'mail' => !empty($j['mail_gesendet']), 'projekt' => (string) ($j['projekt']['nummer'] ?? ''), 'link' => (string) ($j['projekt']['link'] ?? '')];
}

// Aufruf aus sfc_ea_versand, sobald Stripe die Zahlung bestätigt hat
function sfc_ba_versand($pid, array $s) {
  update_post_meta($pid, '_sfc_ba_betrag', round(((int) ($s['amount_total'] ?? 0)) / 100, 2));
  $id = get_post_meta($pid, '_sfc_ea_id', true); $titel = get_post_meta($pid, '_sfc_ea_titel', true); $text = get_post_meta($pid, '_sfc_ea_text', true);
  $mail = get_post_meta($pid, '_sfc_ea_kunde', true); $name = get_post_meta($pid, '_sfc_ea_nachname', true);
  $betrag = number_format(((int) ($s['amount_total'] ?? 0)) / 100, 2, ',', '.') . ' €';
  $at = sfc_ba_arbeitstakt($pid);
  update_post_meta($pid, '_sfc_ba_at', $at['ok'] ? 'ok' : 'fehler');
  update_post_meta($pid, '_sfc_ba_at_versuche', 1);
  wp_update_post(['ID' => $pid, 'post_title' => str_replace('[wartet auf Zahlung]', $at['ok'] ? '[bezahlt]' : '[bezahlt, arbeitsTAKT fehlt]', get_the_title($pid))]);
  $stand = $at['ok']
    ? "In arbeitsTAKT angelegt" . ($at['projekt'] ? " (Projekt {$at['projekt']})" : '') . '. ' . ($at['mail'] ? 'Der Kunde hat seinen Link per Mail bekommen.' : 'ACHTUNG: Die Link-Mail an den Kunden ging nicht raus, bitte im Projekt „Link neu senden“.') . ($at['link'] ? "\n{$at['link']}" : '')
    : "ACHTUNG: Die Übergabe an arbeitsTAKT hat nicht geklappt ({$at['fehler']}). Die Website versucht es alle 5 Minuten erneut (bis zu 12-mal). Der Kunde hat noch keinen Link.";
  $bd = (array) get_post_meta($pid, '_sfc_ba_daten', true);
  $video = !empty($bd['video']);
  $soll = (int) get_post_meta($pid, '_sfc_ba_soll', true) ?: sfc_ba_preis((int) ($bd['gebaeude']['we'] ?? 0), (int) ($bd['gebaeude']['wohnflaeche'] ?? 0), $video);
  $netto = (int) ($s['amount_subtotal'] ?? 0);
  if ($netto > 0 && $netto < $soll) $stand = "ACHTUNG: Laut Angaben wären " . number_format($soll / 100, 2, ',', '.') . " € fällig (Wohnungen/Fläche/Video), bezahlt wurde der Preis für weniger. Bitte nachfragen.\n\n" . $stand;
  wp_mail(SFC_EMPFAENGER, ($video ? 'MIT VIDEO-TERMIN – ' : '') . "Online-Bedarfsausweis $id: $titel (bezahlt)",
    "Neue bezahlte Bestellung für einen Online-Bedarfsausweis.\nBezahlt: $betrag (Stripe " . ($s['id'] ?? '') . ")\n\n$stand\n\n$text", ["Reply-To: $name <$mail>"]);
  wp_mail($mail, "Ihre Bestellung $id: Online-Bedarfsausweis",
    "Guten Tag,\n\nvielen Dank für Ihre Bestellung und Ihre Zahlung für einen Bedarfsausweis für $titel.\n\n"
    . "Sie erhalten in wenigen Minuten eine zweite E-Mail mit Ihrem persönlichen Link. Darüber erfassen Sie Ihr Haus Schritt für Schritt und können jederzeit zwischenspeichern. Bitte schauen Sie auch im Spam-Ordner nach.\n\n" . ($video ? "Sie haben einen Video-Termin dazugebucht. Ich melde mich in den nächsten Tagen bei Ihnen, um einen Termin zu vereinbaren. Dabei gehen wir Ihr Haus gemeinsam am Handy durch.\n\n" : '')
    . "Sobald Sie Ihre Angaben abgeschickt haben, prüfe ich sie persönlich und melde mich bei Rückfragen. Den fertigen Ausweis erhalten Sie als PDF per E-Mail." . (function_exists('sfc_urlaub') && sfc_urlaub() ? ' ' . sfc_urlaub_satz() : '') . "\n\n"
    . "Mit freundlichen Grüßen\nStephan Hecky\nsENERGIEs Energieberatung\nMöchs 33, 91355 Hiltpoltstein · Tel. +49 155 65134339 · info@s-energies.de", ['Reply-To: sENERGIEs Energieberatung <' . SFC_EMPFAENGER . '>']);
}

// Fehlgeschlagene Übergaben bei jedem Lauf der Zahlungsprüfung erneut versuchen
add_action('sfc_ea_zahlungen', function () {
  $liste = get_posts(['post_type' => 'sfc_ba_auftrag', 'post_status' => 'private', 'numberposts' => 10, 'meta_key' => '_sfc_ba_at', 'meta_value' => 'fehler']);
  foreach ($liste as $p) {
    $n = (int) get_post_meta($p->ID, '_sfc_ba_at_versuche', true);
    if ($n >= 12) continue;
    update_post_meta($p->ID, '_sfc_ba_at_versuche', $n + 1);
    $at = sfc_ba_arbeitstakt($p->ID);
    if (!$at['ok']) continue;
    update_post_meta($p->ID, '_sfc_ba_at', 'ok');
    wp_update_post(['ID' => $p->ID, 'post_title' => str_replace('[bezahlt, arbeitsTAKT fehlt]', '[bezahlt]', $p->post_title)]);
    $id = get_post_meta($p->ID, '_sfc_ea_id', true);
    wp_mail(SFC_EMPFAENGER, "Online-Bedarfsausweis $id: jetzt in arbeitsTAKT", "Die Bestellung $id ist im zweiten Anlauf in arbeitsTAKT angelegt" . ($at['projekt'] ? " (Projekt {$at['projekt']})" : '') . '. ' . ($at['mail'] ? 'Der Kunde hat seinen Link bekommen.' : 'Die Link-Mail ging nicht raus, bitte im Projekt „Link neu senden“.'));
  }
}, 20);

add_action('admin_menu', function () {
  add_options_page('Online-Bedarfsausweis', 'Online-Bedarfsausweis', 'manage_options', 'sfc-bedarfsausweis', function () {
    if (isset($_POST['sfc_ba_save']) && check_admin_referer('sfc_ba_save')) {
      update_option('sfc_ba_at_url', esc_url_raw(trim(wp_unslash($_POST['at_url'] ?? ''))), false);
      $k = trim(sanitize_text_field(wp_unslash($_POST['at_schluessel'] ?? '')));
      if ($k !== '') update_option('sfc_ba_at_schluessel', $k, false);
      echo '<div class="updated"><p>Gespeichert.</p></div>';
    }
    if (isset($_POST['sfc_ba_test']) && check_admin_referer('sfc_ba_save')) {
      $basis = untrailingslashit((string) get_option('sfc_ba_at_url', ''));
      $r = wp_remote_post($basis . '/api/bestellung', ['timeout' => 15, 'headers' => ['Authorization' => 'Bearer ' . get_option('sfc_ba_at_schluessel', ''), 'Content-Type' => 'application/json'], 'body' => '{}']);
      $c = is_wp_error($r) ? $r->get_error_message() : wp_remote_retrieve_response_code($r);
      // 400 = Schlüssel gültig, nur die (absichtlich leere) Bestellung fehlt
      echo '<div class="' . ($c === 400 ? 'updated' : 'error') . '"><p>' . ($c === 400 ? 'Verbindung zu arbeitsTAKT klappt, der Schlüssel ist gültig.' : 'Verbindung klappt nicht: ' . esc_html((string) $c) . ' ' . esc_html(is_wp_error($r) ? '' : substr(wp_remote_retrieve_body($r), 0, 200))) . '</p></div>';
    }
    $hat = get_option('sfc_ba_at_schluessel', '') !== '';
    echo '<div class="wrap"><h1>Online-Bedarfsausweis</h1><p>Nach bestätigter Zahlung legt die Website die Bestellung in arbeitsTAKT an. arbeitsTAKT mailt dem Kunden den persönlichen Link zur Erfassung seines Hauses.</p>';
    echo '<form method="post">'; wp_nonce_field('sfc_ba_save');
    echo '<table class="form-table"><tr><th><label for="at_url">arbeitsTAKT-Adresse</label></th><td><input id="at_url" name="at_url" class="regular-text" value="' . esc_attr(get_option('sfc_ba_at_url', '')) . '" placeholder="https://…"><p class="description">Die Adresse, unter der Sie arbeitsTAKT im Browser öffnen, ohne Pfad.</p></td></tr>';
    echo '<tr><th><label for="at_schluessel">arbeitsTAKT-Schlüssel</label></th><td><input type="password" id="at_schluessel" name="at_schluessel" class="regular-text" autocomplete="off" placeholder="' . ($hat ? 'gespeichert, nur zum Ändern neu eintragen' : 'ses_mcp_…') . '"><p class="description">In arbeitsTAKT unter Einstellungen einen persönlichen Schlüssel erstellen (wie für die Claude-App).</p></td></tr></table>';
    echo '<p><button class="button button-primary" name="sfc_ba_save" value="1">Speichern</button> <button class="button" name="sfc_ba_test" value="1">Verbindung testen</button></p></form></div>';
  });
});
