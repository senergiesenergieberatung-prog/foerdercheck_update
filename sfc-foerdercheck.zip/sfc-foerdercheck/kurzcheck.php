<?php
// Kurzcheck-Eingang: Kundinnen und Kunden laden für den kostenlosen Kurzcheck ihr Angebot hoch und willigen ein,
// dass sENERGIEs es ohne Namen und Adressen für die eigene Preisdatenbank auswertet.
// Die wöchentliche Auswertung (Claude, Konto mit edit_others_pages) holt neue Eingänge ab, übernimmt sie in die Preisdatenbank,
// spielt die neuen Vergleichswerte über /sfc/v1/ac-preise ein (Option sfc_ac_preise, kein Plugin-Update nötig)
// und markiert die Eingänge als erledigt; dabei werden die Dateien auf dem Server gelöscht.
if (!defined('ABSPATH')) exit;

add_action('init', function () {
  register_post_type('sfc_kc_angebot', [
    'label' => 'Kurzcheck-Angebote', 'labels' => ['singular_name' => 'Kurzcheck-Angebot'],
    'public' => false, 'show_ui' => true, 'show_in_menu' => 'edit.php?post_type=sfc_anfrage',
    'supports' => ['title', 'editor'], 'capability_type' => 'post',
    'capabilities' => ['create_posts' => 'do_not_allow'], 'map_meta_cap' => true,
  ]);
});

function sfc_kc_darf() { return current_user_can('edit_others_pages'); }

add_action('rest_api_init', function () {
  register_rest_route('sfc/v1', '/kurzcheck', ['methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => 'sfc_kc_eingang']);
  register_rest_route('sfc/v1', '/kurzcheck/neu', ['methods' => 'GET', 'permission_callback' => 'sfc_kc_darf', 'callback' => 'sfc_kc_neu']);
  register_rest_route('sfc/v1', '/kurzcheck/datei', ['methods' => 'GET', 'permission_callback' => 'sfc_kc_darf', 'callback' => 'sfc_kc_datei']);
  register_rest_route('sfc/v1', '/kurzcheck/erledigt', ['methods' => 'POST', 'permission_callback' => 'sfc_kc_darf', 'callback' => 'sfc_kc_erledigt']);
  register_rest_route('sfc/v1', '/ac-preise', ['methods' => 'POST', 'permission_callback' => 'sfc_kc_darf', 'callback' => 'sfc_kc_preise']);
});

// Vergleichswerte für den Kurzcheck: zuerst die wöchentlich eingespielte Option, sonst die mitgelieferte Datei
function sfc_ac_preise() {
  $o = get_option('sfc_ac_preise');
  if (is_array($o) && !empty($o['systeme'])) return $o;
  return json_decode((string) @file_get_contents(plugin_dir_path(__FILE__) . 'ac-preise.json'), true);
}

function sfc_kc_eingang(WP_REST_Request $r) {
  $d = json_decode((string) $r->get_param('daten'), true);
  if (!is_array($d) || !empty($d['website'])) return new WP_REST_Response(['ok' => true], 200); // Honeypot: still schlucken
  if (empty($d['einwilligung'])) return new WP_REST_Response(['ok' => false], 422);
  $rl = 'sfc_kc_rl_' . md5($_SERVER['REMOTE_ADDR'] ?? '');
  $n = (int) get_transient($rl);
  if ($n >= 10) return new WP_REST_Response(['ok' => false], 429);
  set_transient($rl, $n + 1, HOUR_IN_SECONDS);

  $t = fn($x, $l = 120) => mb_substr(sanitize_text_field((string) $x), 0, $l);
  $daten = [];
  foreach (['gewerk', 'system', 'einheit', 'mwst', 'plz', 'selbst', 'wohnungen', 'tueren', 'wallbox'] as $k) $daten[$k] = $t($d[$k] ?? '');
  foreach (['groesse', 'preis', 'netto'] as $k) $daten[$k] = round((float) ($d[$k] ?? 0), 2);
  $daten['ergebnis'] = $t($d['ergebnis'] ?? '', 600);
  if (!preg_match('/^\d{5}$/', $daten['plz'])) $daten['plz'] = '';

  $pid = wp_insert_post(['post_type' => 'sfc_kc_angebot', 'post_status' => 'private',
    'post_title' => trim("{$daten['plz']} – {$daten['gewerk']} – {$daten['system']}", ' –')]);
  if (!$pid || is_wp_error($pid)) return new WP_REST_Response(['ok' => false], 500);

  $ordner = sfc_ea_ordner(); $dateien = [];
  for ($i = 0; $i < 6; $i++) {
    $f = $_FILES["datei$i"] ?? null;
    if (!$f || $f['error'] !== UPLOAD_ERR_OK || $f['size'] > 10 * MB_IN_BYTES) continue;
    $ty = wp_check_filetype_and_ext($f['tmp_name'], $f['name'], ['jpg|jpeg' => 'image/jpeg', 'png' => 'image/png', 'pdf' => 'application/pdf']);
    if (empty($ty['ext'])) continue;
    if ($ty['ext'] !== 'pdf' && !@getimagesize($f['tmp_name'])) continue;
    if ($ty['ext'] === 'pdf' && file_get_contents($f['tmp_name'], false, null, 0, 5) !== '%PDF-') continue;
    $ext = $ty['ext'] === 'jpeg' ? 'jpg' : $ty['ext'];
    $name = 'KC' . wp_date('ymd') . "-{$pid}_" . (count($dateien) + 1) . ".$ext";
    if (move_uploaded_file($f['tmp_name'], "$ordner/$name")) $dateien[] = "$ordner/$name";
  }
  if (!$dateien) { wp_delete_post($pid, true); return new WP_REST_Response(['ok' => false], 422); }

  $text = '';
  foreach ($daten as $k => $v) $text .= "$k: $v\n";
  wp_update_post(['ID' => $pid, 'post_content' => nl2br(esc_html($text . 'Dateien: ' . count($dateien)))]);
  foreach (['_sfc_kc_daten' => $daten, '_sfc_kc_dateien' => $dateien, '_sfc_kc_status' => 'neu', '_sfc_kc_einwilligung' => current_time('mysql')] as $mk => $mv) update_post_meta($pid, $mk, $mv);
  sfc_kc_aufraeumen();
  return new WP_REST_Response(['ok' => true], 200);
}

// Datensparsamkeit: Dateien, die nach 60 Tagen noch auf dem Server liegen, werden gelöscht
function sfc_kc_aufraeumen() {
  $alt = get_posts(['post_type' => 'sfc_kc_angebot', 'post_status' => 'private', 'numberposts' => 20, 'fields' => 'ids',
    'date_query' => [['before' => '60 days ago']], 'meta_query' => [['key' => '_sfc_kc_dateien', 'compare' => 'EXISTS']]]);
  foreach ($alt as $p) { foreach ((array) get_post_meta($p, '_sfc_kc_dateien', true) as $f) if (is_file($f)) @unlink($f); delete_post_meta($p, '_sfc_kc_dateien'); }
}

function sfc_kc_neu() {
  $l = get_posts(['post_type' => 'sfc_kc_angebot', 'post_status' => 'private', 'numberposts' => 100, 'orderby' => 'date', 'order' => 'ASC',
    'meta_query' => [['key' => '_sfc_kc_status', 'value' => 'neu']]]);
  return array_map(fn($p) => ['id' => $p->ID, 'datum' => get_post_time('Y-m-d H:i', false, $p), 'einwilligung' => get_post_meta($p->ID, '_sfc_kc_einwilligung', true),
    'daten' => get_post_meta($p->ID, '_sfc_kc_daten', true),
    'dateien' => array_map('basename', array_values(array_filter((array) get_post_meta($p->ID, '_sfc_kc_dateien', true), 'is_file')))], $l);
}

function sfc_kc_datei(WP_REST_Request $r) {
  $l = array_values(array_filter((array) get_post_meta((int) $r['id'], '_sfc_kc_dateien', true), 'is_file'));
  $f = $l[(int) $r['i']] ?? '';
  if (!$f || get_post_type((int) $r['id']) !== 'sfc_kc_angebot') return new WP_REST_Response(['ok' => false], 404);
  nocache_headers();
  header('Content-Type: ' . (wp_check_filetype($f)['type'] ?: 'application/octet-stream'));
  header('Content-Disposition: attachment; filename="' . basename($f) . '"');
  header('Content-Length: ' . filesize($f));
  readfile($f); exit;
}

// status: "uebernommen" (in die Preisdatenbank aufgenommen) oder "verworfen" (unbrauchbar); Dateien werden gelöscht
function sfc_kc_erledigt(WP_REST_Request $r) {
  $p = (int) $r['id']; $st = $r['status'] === 'verworfen' ? 'verworfen' : 'uebernommen';
  if (get_post_type($p) !== 'sfc_kc_angebot') return new WP_REST_Response(['ok' => false], 404);
  foreach ((array) get_post_meta($p, '_sfc_kc_dateien', true) as $f) if (is_file($f)) @unlink($f);
  delete_post_meta($p, '_sfc_kc_dateien');
  update_post_meta($p, '_sfc_kc_status', $st);
  wp_update_post(['ID' => $p, 'post_title' => "[$st] " . preg_replace('/^\[[a-z]+\] /', '', get_the_title($p))]);
  return ['ok' => true, 'status' => $st];
}

function sfc_kc_preise(WP_REST_Request $r) {
  $j = $r->get_json_params();
  if (!is_array($j) || !is_array($j['systeme'] ?? null) || !$j['systeme']) return new WP_REST_Response(['ok' => false], 400);
  $s = [];
  foreach ($j['systeme'] as $k => $v) {
    if (!is_array($v) || count($s) >= 200) continue;
    $s[mb_substr(sanitize_text_field($k), 0, 80)] = ['n' => (int) ($v['n'] ?? 0), 'min' => (float) ($v['min'] ?? 0), 'median' => (float) ($v['median'] ?? 0), 'max' => (float) ($v['max'] ?? 0)];
  }
  update_option('sfc_ac_preise', ['stand' => sanitize_text_field($j['stand'] ?? ''), 'systeme' => $s], false);
  return ['ok' => true, 'anzahl' => count($s)];
}
