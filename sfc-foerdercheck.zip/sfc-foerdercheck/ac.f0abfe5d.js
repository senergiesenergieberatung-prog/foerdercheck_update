/* sENERGIEs Angebotscheck: Zweitmeinung zum Heizungsangebot. Erfasst Haus, Angebote (Upload) und Kontakt, legt den Auftrag an und leitet zur Stripe-Zahlung. */
(function () {
  const C = Object.assign({ preview: false, endpoint: '', zahlung: '', zahlungslink: '', zahlungslink_vergleich: '', preis: '49 €', preis_vergleich: '79 €', datenschutz: '/datenschutzerklaerung/', bild: '' }, window.SAC_CFG || {});
  const $ = id => document.getElementById('sac-' + id);
  const q = (s, r = document) => r.querySelector(s);
  if (!$('f')) return;
  const val = id => ($(id).value || '').trim();
  const num = s => { s = String(s ?? '').trim(); if (!s) return NaN; if (/,/.test(s)) s = s.replace(/\./g, '').replace(',', '.'); else if (/^\d{1,3}(\.\d{3})+$/.test(s)) s = s.replace(/\./g, ''); return parseFloat(s); };
  const de = (n, d = 0) => isFinite(n) ? (Math.round(n * 10 ** d) / 10 ** d).toLocaleString('de-DE') : '';
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const MAXDATEI = 10e6, MAXJE = 6, MAXSUMME = 60e6;

  // Energieträger: Name, Einheit auf der Abrechnung, kWh je Einheit, Nutzungsgrad (Wärmepumpe: Jahresarbeitszahl ca. 3)
  const ETR = { gas: ['Erdgas', 'kWh', 1, .9], oel: ['Heizöl', 'Liter', 10, .85], fluessig: ['Flüssiggas', 'Liter', 6.57, .9], pellet: ['Pellets', 'kg', 4.9, .85],
    holz: ['Scheitholz', 'Ster', 1750, .7], strom: ['Strom / Nachtspeicher', 'kWh', 1, 1], fw: ['Fernwärme', 'kWh', 1, .98], wp: ['Wärmepumpe', 'kWh Strom', 1, 3] };

  if (C.preview) { $('tag').hidden = false; $('vorschau').hidden = false; }
  if (C.bild) q('#sac .sea-kopf').style.backgroundImage = `linear-gradient(rgba(44,41,39,.78),rgba(44,41,39,.78)),url("${C.bild}")`;
  $('dslink').href = C.datenschutz; $('p1').textContent = C.preis; $('p2').textContent = C.preis_vergleich;

  // ---------- Kacheln ----------
  function sync() {
    document.querySelectorAll('#sac .sea-chips').forEach(g => g.querySelectorAll('button').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.v === document.getElementById(g.dataset.for).value))));
    const nwg = $('art').value === 'nwg';
    $('nwg').hidden = !nwg; $('wg').hidden = nwg; $('n1').hidden = nwg;
    const e = ETR[$('alt').value]; $('einh').textContent = e ? `in ${e[1]}` : '(laut Abrechnung)';
    $('unterhint').hidden = !/^ja/.test($('unter').value);
    const n = +$('anz').value || 1; $('u2').hidden = n < 2; $('u3').hidden = n < 3;
    // mehr als ein Angebot: nur der Vergleich passt
    const t1 = q('input[value=einzel]', $('t1')), t2 = q('input[value=vergleich]', $('t2'));
    t1.disabled = n > 1; $('t1').classList.toggle('sac-aus', n > 1);
    if (n > 1) t2.checked = true;
  }
  document.addEventListener('click', ev => {
    const b = ev.target.closest('#sac .sea-chips button'); if (!b) return;
    document.getElementById(b.parentElement.dataset.for).value = b.dataset.v; sync();
    b.closest('.sea-frage').classList.remove('sea-err');
  });

  // ---------- Dateien anzeigen und einzeln entfernen ----------
  const kb = n => n > 1e6 ? de(n / 1e6, 1) + ' MB' : Math.max(1, Math.round(n / 1e3)) + ' KB';
  document.querySelectorAll('#sac input[type=file]').forEach(inp => {
    const ul = document.createElement('ul'); ul.className = 'sea-files'; ul.hidden = true;
    inp.closest('.sea-upl').insertAdjacentElement('afterend', ul);
    const zeigen = () => { const fs = [...inp.files]; ul.hidden = !fs.length;
      ul.innerHTML = fs.map((f, i) => `<li><span>${esc(f.name)} <small>${kb(f.size)}${f.size > MAXDATEI ? ' – zu groß' : ''}</small></span><button type="button" class="sea-sec" data-weg="${i}" aria-label="${esc(f.name)} entfernen">✕ Entfernen</button></li>`).join(''); };
    inp.addEventListener('change', zeigen);
    ul.addEventListener('click', ev => { const b = ev.target.closest('[data-weg]'); if (!b) return;
      const dt = new DataTransfer(); [...inp.files].forEach((f, i) => { if (i !== +b.dataset.weg) dt.items.add(f); });
      inp.files = dt.files; inp.dispatchEvent(new Event('change', { bubbles: true })); });
  });
  const dateien = () => { const n = +$('anz').value || 1; return ['a1', 'a2', 'a3', 'extra'].filter((k, i) => i === 3 || i < n).flatMap(k => [...$(k).files].slice(0, MAXJE).map(f => [k, f])); };

  // ---------- Pflichtfelder ----------
  function markiere(sec, ids) {
    sec.querySelectorAll('.sea-err').forEach(x => x.classList.remove('sea-err'));
    const els = ids.map(i => { const x = $(i); if (!x) return null; if (x.type === 'checkbox') return x.closest('label'); if (x.type === 'hidden') return x.closest('.sea-frage'); if (x.type === 'file') return x.closest('.sea-upl'); return x; }).filter(Boolean);
    els.forEach(x => x.classList.add('sea-err'));
    if (els[0]) { const t = els[0].getBoundingClientRect().top + scrollY - 120; if (t < scrollY) scrollTo({ top: t }); }
    return !els.length;
  }
  function check(n) {
    const sec = q(`#sac section[data-step="${n}"]`), m = $('msg' + n), f = [];
    if (n === 1) {
      if (!val('neu')) f.push('neu'); if (!val('alt')) f.push('alt');
      const bj = +val('bj'); if (!(bj >= 1800 && bj <= 2026)) f.push('bj');
      if (!(num(val('wfl')) >= 20)) f.push('wfl'); if (!(+val('we') >= 1)) f.push('we');
      if (!/^\d{5}$/.test(val('plz'))) f.push('plz');
      if (!val('hfl')) f.push('hfl'); if (!val('selbst')) f.push('selbst'); if (!val('unter')) f.push('unter');
    }
    if (n === 2) {
      const n2 = +$('anz').value || 1;
      if (!C.preview) ['a1', 'a2', 'a3'].slice(0, n2).forEach(k => { if (!$(k).files.length) f.push(k); });
      const fs = dateien();
      if (fs.some(([, x]) => x.size > MAXDATEI)) { m.textContent = 'Eine Datei ist größer als 10 MB. Bitte verkleinern oder als Foto mit geringerer Auflösung hochladen.'; return false; }
      if (fs.reduce((s, [, x]) => s + x.size, 0) > MAXSUMME) { m.textContent = 'Zusammen sind die Dateien zu groß (max. 60 MB). Bitte Fotos verkleinern oder PDFs nutzen.'; return false; }
    }
    if (n === 3) {
      if (!val('vorname')) f.push('vorname'); if (!val('nachname')) f.push('nachname');
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(val('email'))) f.push('email');
      if (!$('ds').checked) f.push('ds'); if (!$('widerruf').checked) f.push('widerruf');
    }
    const ok = markiere(sec, f);
    m.textContent = ok ? '' : 'Bitte die rot markierten Angaben ergänzen.';
    return ok;
  }

  // ---------- Vorprüfung für Stephan (nur grobe Richtwerte aus dem Verbrauch) ----------
  function vorpruefung() {
    const e = ETR[val('alt')], v = num(val('verbr')), a = num(val('wfl'));
    if (!e || !(v > 0) || !(a > 0)) return 'Kein Verbrauch angegeben, Heizlast nicht abschätzbar.';
    const kwh = v * e[2] * e[3], ww = 12.5 * a, hl = Math.max(3, (kwh - ww) / 2000);
    return `Wärmebedarf ca. ${de(kwh)} kWh/a (${de(kwh / a)} kWh/m²a), davon Warmwasser ca. ${de(ww)} kWh. Heizlast grob ${de(hl, 1)} kW (Verbrauch / 2000 h, ohne Gewähr).`;
  }
  const tarif = () => (q('input[name=sac-tarif]:checked') || {}).value || 'einzel';
  function daten() {
    const e = ETR[val('alt')] || ['', ''];
    return {
      haus: { 'Angeboten': val('neu'), 'Heizung heute': e[0], 'Baujahr Haus': val('bj'), 'Wohnfläche': val('wfl') + ' m²', 'Wohnungen': val('we'), 'Baujahr alte Heizung': val('bjhz') || 'k. A.',
        'Verbrauch letztes Jahr': val('verbr') ? `${val('verbr')} ${e[1]}` : 'k. A.', 'Heizflächen': val('hfl'), 'Selbst bewohnt': val('selbst'),
        'Schon unterschrieben': { nein: 'nein', ja: 'ja, mit Förder-Vorbehalt', 'ja-ohne': 'ja, ohne Vorbehalt / unklar' }[val('unter')] || '', 'PLZ': val('plz'), 'Anzahl Angebote': val('anz') },
      kontakt: { vorname: val('vorname'), nachname: val('nachname'), email: val('email'), tel: val('tel') },
      frage: val('frage'), vorpruefung: vorpruefung(), tarif: tarif(), website: val('hp')
    };
  }
  function uebersicht() {
    const d = daten(), n = dateien();
    $('sum').innerHTML = [['Haus', `${d.haus['Wohnfläche']}, Baujahr ${d.haus['Baujahr Haus']}, ${d.haus['Wohnungen']} Wohnung(en), PLZ ${d.haus.PLZ}`], ['Heizung', `${d.haus['Heizung heute']} → ${d.haus.Angeboten}`],
      ['Unterlagen', `${n.length} Datei(en)`], ['Kontakt', `${d.kontakt.vorname} ${d.kontakt.nachname}, ${d.kontakt.email}`]]
      .map(([a, b]) => `<dt>${a}</dt><dd>${esc(b)}</dd>`).join('');
    if (C.preview) $('mail').value = Object.entries(d.haus).map(([k, v]) => `${k}: ${v}`).join('\n') + `\n\nVorprüfung: ${d.vorpruefung}\nFrage: ${d.frage || '–'}\nDateien: ${n.map(([k, f]) => k + ' ' + f.name).join(', ')}`;
  }

  $('pay').addEventListener('click', async () => {
    const m = $('msg4'); m.className = 'sea-msg';
    if (!C.endpoint) { m.className = 'sea-msg gut'; m.textContent = 'Vorschau: Hier geht es im Live-Betrieb zur Stripe-Zahlung. Der Auftrag geht mit allen Dateien an info@s-energies.de, sobald bezahlt ist.'; return; }
    const d = daten(), fd = new FormData();
    fd.append('daten', JSON.stringify(d));
    dateien().forEach(([k, f], i) => fd.append('datei' + i, f, k + '__' + f.name));
    $('pay').disabled = true; m.className = 'sea-msg gut'; m.textContent = 'Unterlagen werden übertragen …';
    try {
      const r = await fetch(C.endpoint, { method: 'POST', body: fd }); const j = await r.json().catch(() => ({}));
      if (!r.ok || !j.ok) throw new Error(j.fehler || '');
      const z = d.tarif === 'vergleich' ? C.zahlungslink_vergleich : C.zahlungslink;
      if (z) { m.textContent = 'Weiter zur Zahlung …'; location.href = z + (z.includes('?') ? '&' : '?') + 'client_reference_id=' + encodeURIComponent(j.id) + '&prefilled_email=' + encodeURIComponent(d.kontakt.email); return; }
      $('fertig').textContent = `Ihre Auftragsnummer ist ${j.id}. Ich melde mich per E-Mail mit dem Zahlungslink.`; show(5);
    } catch (e) { m.className = 'sea-msg'; m.textContent = (e.message || 'Die Übertragung hat nicht geklappt.') + ' Bitte versuchen Sie es noch einmal oder schreiben Sie an info@s-energies.de.'; $('pay').disabled = false; }
  });

  // ---------- Navigation ----------
  let step = 1;
  function show(n) {
    step = n;
    document.querySelectorAll('#sac [data-step]').forEach(s => s.hidden = +s.dataset.step !== n);
    document.querySelectorAll('#sac-steps li').forEach((li, i) => li.classList.toggle('on', i < n));
    if (n === 4) uebersicht();
    const top = $('f').getBoundingClientRect().top + scrollY - 90; if (scrollY > top) scrollTo({ top });
  }
  $('f').addEventListener('click', ev => {
    const t = ev.target;
    if (t.matches('[data-back]')) show(step - 1);
    if (t.matches('[data-next]') && check(step)) show(step + 1);
  });
  $('f').addEventListener('input', ev => { const x = ev.target; if (x.classList.contains('sea-err') && x.value) x.classList.remove('sea-err'); const l = x.closest('.sea-err'); if (l && (x.checked || x.files && x.files.length)) l.classList.remove('sea-err'); });
  $('f').addEventListener('submit', e => e.preventDefault());

  // ---------- Rückkehr von Stripe: Dankeseite und sofortige Zahlungsprüfung ----------
  { const u = new URLSearchParams(location.search);
    if (u.has('danke')) {
      document.querySelectorAll('#sac [data-step]').forEach(s => s.hidden = s.dataset.step !== '6');
      document.querySelectorAll('#sac-steps li').forEach(li => li.classList.add('on'));
      const sid = u.get('session_id') || '';
      if (C.zahlung && /^cs_(live|test)_[A-Za-z0-9]+$/.test(sid)) fetch(C.zahlung + (C.zahlung.includes('?') ? '&' : '?') + 'sid=' + encodeURIComponent(sid)).catch(() => {});
    } }
  sync();

  if (C.preview) {
    const b = document.createElement('button'); b.type = 'button'; b.className = 'sea-sec'; b.textContent = 'Testdaten einfügen';
    b.style.cssText = 'margin-left:10px;padding:2px 10px;font-size:12px;color:#f2f1e5;border-color:rgba(242,241,229,.4)';
    $('tag').after(b);
    b.addEventListener('click', () => {
      Object.entries({ neu: 'Luft-Wasser-Wärmepumpe', alt: 'oel', bj: 1978, wfl: '145', we: 1, bjhz: 1998, verbr: '2400', plz: '91301', hfl: 'Heizkörper', selbst: 'ja', unter: 'nein', vorname: 'Anna', nachname: 'Muster', email: 'anna.muster@example.de', tel: '09191 123456' }).forEach(([k, x]) => $(k).value = x);
      ['ds', 'widerruf'].forEach(k => $(k).checked = true); sync();
    });
  }
})();
