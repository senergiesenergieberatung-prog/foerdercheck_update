/* sENERGIEs Angebotscheck: kostenloser Kurzcheck (Preisvergleich mit der Preisdatenbank + Förderschätzung, läuft nur im Browser),
   danach persönliche Prüfung: Angebotsbewertung (1 Angebot) oder Angebotsvergleich (bis zu 3 Angebote) mit Upload und Stripe-Zahlung. */
(function () {
  const C = Object.assign({ preview: false, endpoint: '', zahlung: '', zahlungslink: '', zahlungslink_vergleich: '', preis: '49 €', preis_vergleich: '79 €', gutschein: '', datenschutz: '/datenschutzerklaerung/', bild: '', preise: null, kc_endpoint: '', pdfjs: 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js', pdfworker: 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js', foerderrechner: '/foerdercheck/' }, window.SAC_CFG || {});
  const $ = id => document.getElementById('sac-' + id);
  const q = (s, r = document) => r.querySelector(s);
  if (!$('f')) return;
  const val = id => ($(id).value || '').trim();
  const istHz = () => val('gewerk') === 'Heizung';
  const num = s => { s = String(s ?? '').trim().replace(/\s|€/g, ''); if (!s) return NaN; if (/,/.test(s)) s = s.replace(/\./g, '').replace(',', '.'); else if (/^\d{1,3}(\.\d{3})+$/.test(s)) s = s.replace(/\./g, ''); return parseFloat(s); };
  const de = (n, d = 0) => isFinite(n) ? (Math.round(n * 10 ** d) / 10 ** d).toLocaleString('de-DE') : '';
  const eur = n => de(n) + ' €';
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const MAXDATEI = 10e6, MAXJE = 6, MAXSUMME = 60e6;

  // Energieträger: Name, Einheit auf der Abrechnung, kWh je Einheit, Nutzungsgrad (Wärmepumpe: Jahresarbeitszahl ca. 3)
  const ETR = { gas: ['Erdgas', 'kWh', 1, .9], oel: ['Heizöl', 'Liter', 10, .85], fluessig: ['Flüssiggas', 'Liter', 6.57, .9], pellet: ['Pellets', 'kg', 4.9, .85],
    holz: ['Scheitholz', 'Ster', 1750, .7], strom: ['Strom / Nachtspeicher', 'kWh', 1, 1], fw: ['Fernwärme', 'kWh', 1, .98], wp: ['Wärmepumpe', 'kWh Strom', 1, 3] };

  if (C.preview) { $('tag').hidden = false; $('vorschau').hidden = false; }
  if (C.bild) q('#sac .sea-kopf').style.backgroundImage = `linear-gradient(rgba(44,41,39,.78),rgba(44,41,39,.78)),url("${C.bild}")`;
  $('dslink').href = C.datenschutz; document.querySelectorAll('#sac .sac-dslink').forEach(a => a.href = C.datenschutz); $('p1').textContent = C.preis; $('p2').textContent = C.preis_vergleich;

  // =====================================================================
  // Kostenloser Kurzcheck
  // =====================================================================
  // System: [Schlüssel, Name, Schlüssel in der Preisdatenbank (null = noch keine Vergleichswerte), Einheit, Beispiel, Förderart, Name im Auftragsformular]
  const SYS = {
    'Heizung': [['wp', 'Luft-Wasser-Wärmepumpe', 'WP Luft/Wasser|€/kW', 'kW Heizleistung', '9', 'wp', 'Luft-Wasser-Wärmepumpe'],
      ['wpe', 'Erdwärmepumpe', null, 'kW Heizleistung', '9', 'wp', 'Erdwärmepumpe'],
      ['pellet', 'Pelletkessel', 'Pellet|€/kW', 'kW Nennleistung', '15', 'bio', 'Pellet- oder Hackschnitzelheizung'],
      ['hack', 'Hackschnitzelkessel', 'Hackschnitzel|€/kW', 'kW Nennleistung', '30', 'bio', 'Pellet- oder Hackschnitzelheizung'],
      ['scheit', 'Scheitholzkessel', 'Scheitholz|€/kW', 'kW Nennleistung', '25', 'bio', 'Scheitholz- oder Kombikessel'],
      ['kombi', 'Kombikessel Scheitholz/Pellet', 'Pellet/Scheitholz-Kombi|€/kW', 'kW Nennleistung', '25', 'bio', 'Scheitholz- oder Kombikessel'],
      ['solar', 'Solarthermie', 'Solarthermie|€/m²', 'm² Kollektorfläche', '10', 'solar', 'Solarthermie']],
    'Dach / oberste Geschossdecke': [['auf', 'Aufsparrendämmung mit neuer Eindeckung', 'Aufsparrendämmung|€/m²', 'm² Dachfläche', '160', 'huelle'],
      ['aufin', 'Aufsparrendämmung mit neuer Innenverkleidung', 'Aufsparrendämmung inkl. Innenbekleidung|€/m²', 'm² Dachfläche', '160', 'huelle'],
      ['zwi', 'Zwischen- oder Untersparrendämmung von innen', null, 'm² Dachfläche', '120', 'huelle'],
      ['ogd', 'Dämmung der obersten Geschossdecke', 'OGD-Dämmung|€/m²', 'm² Deckenfläche', '80', 'huelle']],
    'Außenwand / Fassade': [['wdvs', 'Wärmedämmverbundsystem', null, 'm² Wandfläche', '180', 'huelle'],
      ['vhf', 'Vorgehängte Fassade', null, 'm² Wandfläche', '180', 'huelle'],
      ['kern', 'Kern- oder Innendämmung', null, 'm² Wandfläche', '180', 'huelle']],
    'Fenster und Außentüren': [['fen', 'Fenster', 'Fenster Kunststoff|€/m²', 'm² Fensterfläche (Breite × Höhe, alle Fenster)', '25', 'huelle'],
      ['tuer', 'Haustür', 'Haustür|€/Stück', 'Stück', '1', 'huelle'],
      ['fentuer', 'Fenster und Haustür', 'Fenster Kunststoff|€/m²', 'm² Fensterfläche (Breite × Höhe, alle Fenster)', '25', 'huelle']],
    'Kellerdecke / Bodenplatte': [['kd', 'Dämmung der Kellerdecke', null, 'm² Deckenfläche', '90', 'huelle']],
    'Lüftungsanlage': [['zl', 'Zentrale Lüftung mit Wärmerückgewinnung', null, 'm² Wohnfläche', '140', 'huelle'],
      ['dl', 'Dezentrale Lüfter mit Wärmerückgewinnung', null, 'Stück', '6', 'huelle']],
    'Photovoltaik': [['pv', 'ohne Speicher', null, 'kWp', '10', 'pv'],
      ['pvs', 'mit Speicher', 'PV mit Batterie|€/kWp', 'kWp', '10', 'pv']]
  };
  // Technische Mindestanforderungen (Kurzfassung) und worauf man im Angebot achten sollte
  const TMA = { wp: 'Jahresarbeitszahl mindestens 3,0, Geräuschgrenzwert der Außeneinheit eingehalten, hydraulischer Abgleich.', bio: 'Emissionsgrenzwerte für Staub und Kohlenmonoxid, ausreichend großer Pufferspeicher, hydraulischer Abgleich.', solar: 'Kollektoren mit Solar-Keymark-Zertifikat, hydraulischer Abgleich.',
    'Dach / oberste Geschossdecke': 'U-Wert höchstens 0,14 W/(m²K), Dachflächenfenster Uw höchstens 1,0 W/(m²K).',
    'Außenwand / Fassade': 'U-Wert höchstens 0,20 W/(m²K) (Innendämmung und Fachwerk mit Sonderregeln).',
    'Fenster und Außentüren': 'Fenster Uw höchstens 0,95 W/(m²K), Haustüren Ud höchstens 1,3 W/(m²K). Lüftungskonzept nötig, wenn viele Fenster getauscht werden.',
    'Kellerdecke / Bodenplatte': 'U-Wert höchstens 0,25 W/(m²K).',
    'Lüftungsanlage': 'Wärmerückgewinnung und Effizienzwerte nach Förderrichtlinie, Planung nach DIN 1946-6.' };
  const LISTE = {
    'Heizung': ['raumweise Heizlastberechnung', 'hydraulischer Abgleich (Verfahren B)', 'Demontage und Entsorgung der alten Heizung und des Tanks', 'Elektroanschluss und Zählerschrank', 'Aufstellung: Fundament, Kernbohrungen, Leitungen nach außen', 'Speicher für Warmwasser und Puffer', 'Inbetriebnahme und Einweisung'],
    'Dach / oberste Geschossdecke': ['Gerüst und Absturzsicherung', 'Abbruch und Entsorgung', 'Dampfbremse bzw. luftdichte Ebene mit allen Anschlüssen', 'Dachrinnen und Blechanschlüsse', 'Anschlüsse an Kamin, Dachfenster und Giebel', 'Dämmstoff, Dicke und U-Wert genannt'],
    'Außenwand / Fassade': ['Gerüst', 'Untergrundvorbereitung', 'Fensterbänke und Laibungen', 'Sockeldämmung', 'Anschlüsse an Dach und Fenster', 'Dämmstoff, Dicke und U-Wert genannt'],
    'Fenster und Außentüren': ['Ausbau und Entsorgung der alten Fenster', 'Montage nach RAL (innen luftdicht, außen schlagregendicht)', 'Fensterbänke innen und außen', 'Laibungen beiputzen', 'Uw-Wert jedes Elements genannt', 'Rollläden und Insektenschutz, falls gewünscht'],
    'Kellerdecke / Bodenplatte': ['Vorbereitung des Untergrunds', 'Umgang mit Leitungen und Leuchten', 'Dämmstoff, Dicke und U-Wert genannt', 'Randbereiche und Kellertreppe'],
    'Lüftungsanlage': ['Lüftungskonzept nach DIN 1946-6', 'Kanäle, Durchbrüche und Verschließen', 'Elektroanschluss', 'Einregulierung und Protokoll', 'Filter und Wartung'],
    'Photovoltaik': ['Gerüst', 'Zählerschrank nach den Vorgaben des Netzbetreibers', 'Anmeldung beim Netzbetreiber', 'Unterkonstruktion passend zur Dacheindeckung', 'Überspannungsschutz', 'nutzbare Speicherkapazität genannt'] };

  // Gewerke mit mehreren wählbaren Bausteinen: je Feld [id, Beschriftung, Einheit, Preisschlüssel, Faktor gegenüber dem Grundpreis, Hinweis]
  const BAU = {
    'Dach / oberste Geschossdecke': [
      { k: 'auf', t: 'Dachdämmung von außen mit neuer Eindeckung', f: [['m_auf', 'Dachfläche, von außen gedämmt', 'm²', 'Aufsparrendämmung|€/m²', 1]] },
      { k: 'innen', t: 'Dachdämmung von innen', f: [['m_innen', 'Dachfläche, von innen gedämmt', 'm²', '', 1]] },
      { k: 'ogd', t: 'Oberste Geschossdecke', f: [['m_ogd', 'Fläche oberste Geschossdecke', 'm²', 'OGD-Dämmung|€/m²', 1]] },
      { k: 'gaube', t: 'Dachgaube', f: [['n_gaube', 'Anzahl Gauben', 'Stück', null, 0], ['e_gaube', 'Kosten der Gauben laut Angebot', '€', null, 0, 'optional, falls einzeln ausgewiesen']] }],
    'Fenster und Außentüren': [
      { k: 'fen', t: 'Fenster', f: [['n_fl', 'Normale Fensterflügel', 'Flügel', 'Fenster je Flügel|€/Flügel', 1, 'zweiflügeliges Fenster = 2'], ['n_bt', 'Bodentiefe Fensterflügel', 'Flügel', 'Fenster je Flügel|€/Flügel', 1.6, 'auch Balkon- und Terrassentüren'],
        ['n_df', 'Dachfenster', 'Stück', 'Fenster je Flügel|€/Flügel', 2.5], ['n_hst', 'Hebeschiebeanlagen', 'Stück', 'Fenster je Flügel|€/Flügel', 6]] },
      { k: 'tuer', t: 'Haustür', f: [['n_tuer', 'Anzahl Haustüren', 'Stück', 'Haustür|€/Stück', 1]] }],
    'Außenwand / Fassade': [
      { k: 'wdvs', t: 'Wärmedämmverbundsystem', f: [['m_wdvs', 'Wandfläche mit Wärmedämmverbundsystem', 'm²', '', 1]] },
      { k: 'vhf', t: 'Vorgehängte Fassade', f: [['m_vhf', 'Wandfläche mit vorgehängter Fassade', 'm²', '', 1]] },
      { k: 'kern', t: 'Kern- oder Innendämmung', f: [['m_kern', 'Wandfläche mit Kern- oder Innendämmung', 'm²', '', 1]] }],
    'Kellerdecke / Bodenplatte': [
      { k: 'kd', t: 'Dämmung der Kellerdecke', f: [['m_kd', 'Fläche der Kellerdecke', 'm²', '', 1]] }]
  };
  // Gebäudehülle: mehrere Gewerke in einem Angebot möglich (ein Auftrag, ein BAFA-Topf)
  const gews = () => val('kgew').split(',').filter(Boolean);
  const multi = () => gews().length > 0 && gews().every(g => BAU[g]);
  const bauDefs = () => multi() ? gews().flatMap(g => BAU[g]) : [];
  const bauSel = () => multi() ? val('ksys').split(',').filter(k => bauDefs().some(b => b.k === k)) : [];
  const bauFelder = () => bauDefs().filter(b => bauSel().includes(b.k)).flatMap(b => b.f);
  const sysListe = () => multi() ? [] : SYS[val('kgew')] || [];
  const sys = () => {
    if (!multi()) return sysListe().find(s => s[0] === val('ksys'));
    const sel = bauSel(); if (!sel.length) return undefined;
    return [sel.join(','), bauDefs().filter(b => sel.includes(b.k)).map(b => b.t).join(' + '), null, 'Stück', '', 'huelle'];
  };

  // Stichtage der Reform vom 21.07.2026: Klimageschwindigkeitsbonus und Kostengrenze der 1. Wohneinheit (wie kacheln.js)
  function stufe(d) {
    const t = d.toISOString().slice(0, 10);
    const s = [['2027-02-01', 16, 28000], ['2027-08-01', 12, 27250], ['2028-02-01', 8, 26500], ['2028-08-01', 4, 25750]];
    for (const [bis, kb, cap] of s) if (t < bis) return { kb, cap };
    const halbj = Math.floor((d.getFullYear() - 2028) * 2 + (d.getMonth() >= 7 ? 1 : 0));
    return { kb: 0, cap: Math.max(22000, 25750 - 750 * Math.max(0, halbj)) };
  }

  function foerderung(s, brutto) {
    const art = s[5], we = Math.max(1, Math.round(num(val('kwe')) || 1)), selbst = val('kselbst') === 'ja';
    if (art === 'pv') return { z: 0, text: 'Photovoltaik wird über die Gebäudeförderung (BEG) nicht bezuschusst. Ihr Vorteil: Für PV-Anlagen und Speicher auf Wohnhäusern gilt 0 % Mehrwertsteuer. Steht im Angebot Mehrwertsteuer, fragen Sie nach.', tips: [] };
    if (art === 'huelle') {
      const isfp = val('kisfp') === 'ja';
      const capH = (isfp ? 60000 : 30000) + Math.min(we - 1, 5) * (isfp ? 30000 : 15000), ohne = 30000 + Math.min(we - 1, 5) * 15000;
      const f = Math.min(brutto, capH), z = f * .15 + (isfp ? Math.max(0, f - ohne) * .05 : 0);
      const tips = ['Für Dämmung, Fenster und Lüftung ist ein Energieeffizienz-Experte Pflicht. Seine Baubegleitung wird zusätzlich mit 50 % bezuschusst.'];
      if (brutto > capH) tips.push(`Förderfähig sind höchstens ${eur(capH)} je Jahr. Größere Vorhaben lassen sich auf zwei Jahre verteilen.`);
      if (!isfp) tips.push('Mit einem Sanierungsfahrplan (iSFP) steigt die Förderung um 5 Prozentpunkte und die förderfähigen Kosten verdoppeln sich.');
      if (selbst) { const st = Math.min(Math.min(brutto, 200000) * .2, 40000); if (st > z) tips.push(`Als Alternative zur BAFA-Förderung: Über den Steuerbonus (§ 35c EStG) wären bis zu ${eur(st)} über drei Jahre möglich.`); }
      return { z, text: `15 %${isfp ? ' plus 5 % iSFP-Bonus' : ''} auf ${eur(f)} förderfähige Kosten (BAFA).`, tips };
    }
    // Heizung (KfW 458)
    const { kb, cap } = stufe(new Date());
    const capAll = cap + Math.min(we - 1, 5) * 15000 + Math.max(0, we - 6) * 8000, ff = Math.min(brutto, capAll);
    const klimaOk = selbst && art !== 'solar' && (['oel', 'strom'].includes(val('kalt')) || (['gas', 'bio'].includes(val('kalt')) && val('kalter') === 'alt'));
    const zve = +val('keink') || 0, eink = selbst ? ({ 30: 40, 40: 30, 50: 10 }[zve] || 0) : 0, deckel = selbst && zve === 30 ? 80 : 70;
    const satz = Math.min(deckel, 30 + (klimaOk ? kb : 0) + eink), eigen = selbst ? ff / we : 0, z = eigen * satz / 100 + (ff - eigen) * .3;
    const t = ['30 % Grundförderung']; if (klimaOk) t.push(kb + ' % Klimabonus'); if (eink) t.push(eink + ' % Einkommensbonus');
    const tips = [];
    if (brutto > capAll) tips.push(`Förderfähig sind höchstens ${eur(capAll)}. Den Rest kann die KfW mit einem Ergänzungskredit finanzieren.`);
    if (klimaOk && kb === 16) tips.push('Ab 1. Februar 2027 sinkt der Klimabonus auf 12 %. Rechtzeitig beantragen lohnt sich.');
    if (selbst && !zve) tips.push('Den Einkommensbonus (bis zu 40 %) habe ich ohne Angabe nicht eingerechnet.');
    if (art === 'wp') tips.push('Ab dem ersten Quartal 2027 sinkt die Grundförderung für Wärmepumpen, die nicht in der EU hergestellt werden, auf 15 %. Fragen Sie nach dem Herstellungsort.');
    tips.push('Der Antrag muss vor Beginn der Arbeiten gestellt sein, und der Vertrag braucht eine Förder-Bedingung.');
    return { z, text: `${t.join(' + ')}${satz < 30 + (klimaOk ? kb : 0) + eink ? `, gedeckelt auf ${deckel} %` : ''} auf ${eur(ff)} förderfähige Kosten (KfW).${we > 1 && selbst ? ' Boni nur für die selbst genutzte Wohnung.' : ''}`, tips };
  }

  // ---------- Angebot im Browser auslesen (nur Text-PDFs; Scans und Fotos: Handeingabe) ----------
  let pdfLaden = null;
  const ladePdf = () => pdfLaden || (pdfLaden = new Promise((ok, nein) => {
    if (window.pdfjsLib) return ok(window.pdfjsLib);
    const sc = document.createElement('script'); sc.src = C.pdfjs; sc.onerror = nein;
    sc.onload = () => { window.pdfjsLib.GlobalWorkerOptions.workerSrc = C.pdfworker; ok(window.pdfjsLib); }; document.head.appendChild(sc); }));
  async function pdfZeilen(f) {
    const lib = await ladePdf(), doc = await lib.getDocument({ data: new Uint8Array(await f.arrayBuffer()) }).promise, out = [];
    for (let p = 1; p <= Math.min(doc.numPages, 30); p++) {
      const c = await (await doc.getPage(p)).getTextContent(), rows = {};
      c.items.forEach(it => { const y = Math.round(it.transform[5]); (rows[y] = rows[y] || []).push([it.transform[4], it.str]); });
      Object.keys(rows).sort((a, b) => b - a).forEach(y => out.push(rows[y].sort((a, b) => a[0] - b[0]).map(x => x[1]).join(' ').replace(/\s+/g, ' ').trim()));
    }
    return out.filter(Boolean);
  }
  $('kdatei').addEventListener('change', async () => {
    const fs = [...$('kdatei').files], m = $('klesen'), pdf = fs.find(f => /pdf$/i.test(f.type) || /\.pdf$/i.test(f.name));
    m.hidden = !fs.length; if (!fs.length) return;
    $('kdatei').closest('.sea-upl').classList.remove('sea-err');
    if (!pdf || !window.sacLesen) { m.textContent = 'Fotos kann ich nicht automatisch auslesen. Bitte tragen Sie Gewerk, Größe und Preis unten ein.'; return; }
    m.textContent = 'Ich lese Ihr Angebot …';
    try {
      const r = window.sacLesen(await pdfZeilen(pdf)), gef = [];
      if (r.gewerk && !val('kgew')) { const gl = (r.gewerke && r.gewerke.length ? r.gewerke : [r.gewerk]); $('kgew').value = gl.join(','); sync(); gef.push(gl.join(' und ')); }
      if (r.sys && gews().includes(r.gewerk) && !val('ksys')) { $('ksys').value = r.sys; sync(); const s = sys(); if (s) gef.push(s[1]); }
      const hinw = [];
      if (multi()) {
        const setz = (id, v, txt) => { if (v && !val(id)) { $(id).value = de(v, 2); gef.push(txt); } };
        const sel = bauSel(), fl = sel.includes('auf') ? 'm_auf' : sel.includes('ogd') ? 'm_ogd' : sel.includes('innen') ? 'm_innen' : '';
        if (fl && gews().length === 1) setz(fl, r.gr, de(r.gr, 2) + ' m²');
        setz('n_fl', r.fl, r.fl + ' normale Flügel'); setz('n_bt', r.bt, r.bt + ' bodentiefe Flügel');
        if (r.dachfenster) hinw.push('Dachfenster'); if (r.hebeschiebe) hinw.push('Hebeschiebeanlagen');
        if (sel.includes('gaube')) hinw.push('Dachgauben');
      } else if (r.gr && !val('kgr')) { $('kgr').value = de(r.gr, 2); gef.push(de(r.gr, 2) + ' ' + (sys() ? sys()[3].split(' ')[0] : '')); }
      if (r.zus && r.zus.length && val('kgew') === 'Heizung' && !val('kzus')) { $('kzus').value = r.zus.join(','); sync(); hinw.push(r.zus.map(k => ZUS[k]).join(' und ')); }
      if (r.wallbox && val('kgew') === 'Photovoltaik') { $('kwb').value = 'ja'; gef.push('mit Wallbox'); }
      if (r.preis && !val('kpreis')) { $('kpreis').value = de(r.preis, 2); $('kmwst').value = r.nullSteuer ? 'brutto' : r.mwst; gef.push(eur(r.preis) + (r.mwst === 'netto' ? ' netto' : '')); }
      sync();
      m.textContent = (gef.length ? `Aus Ihrem Angebot ausgelesen: ${gef.join(', ')}. Bitte prüfen Sie die Werte und ergänzen Sie, was fehlt.` : 'Ich konnte keine Werte sicher auslesen. Bitte tragen Sie Gewerk, Größe und Preis unten ein.')
        + (hinw.length ? ` Im Angebot stehen vermutlich auch ${hinw.join(' und ')}. Bitte prüfen Sie die Auswahl und tragen Sie Anzahl oder Betrag ein.` : '');
    } catch (e) { m.textContent = 'Das Auslesen hat nicht geklappt. Bitte tragen Sie Gewerk, Größe und Preis unten ein.'; }
  });

  // ---------- Angebot für die Preisdatenbank übertragen (nur mit Einwilligung) ----------
  function kcSenden(daten) {
    if (!C.kc_endpoint || val('hp')) return;
    const fd = new FormData(); fd.append('daten', JSON.stringify(daten));
    [...$('kdatei').files].slice(0, MAXJE).filter(f => f.size <= MAXDATEI).forEach((f, i) => fd.append('datei' + i, f, f.name));
    fetch(C.kc_endpoint, { method: 'POST', body: fd }).catch(() => {});
  }

  // Preis beim Tippen mit Tausenderpunkten anzeigen (z. B. 90000 -> 90.000, Komma für Cent bleibt)
  function tausender(e) {
    const el = e.target, roh = el.value.replace(/[^\d,]/g, ''), [g, ...r] = roh.split(',');
    const neu = g.replace(/^0+(?=\d)/, '').replace(/\B(?=(\d{3})+(?!\d))/g, '.') + (r.length ? ',' + r.join('').slice(0, 2) : '');
    if (neu !== el.value) { const hinten = el.value.length - el.selectionStart; el.value = neu; const p = Math.max(0, neu.length - hinten); el.setSelectionRange(p, p); }
  }
  $('kpreis').addEventListener('input', tausender);

  // Zusatzleistungen im Heizungsangebot (Fußbodenheizung usw.), werden aus dem Preisvergleich herausgerechnet
  const ZUS = { fbh: 'neue Fußbodenheizung', hk: 'neue Heizkörper', el: 'Zählerschrank oder Elektro', kamin: 'Schornstein oder Abgasanlage', sonst: 'weitere Leistungen' };
  const zusL = () => val('kzus').split(',').filter(k => ZUS[k]);
  const zusFrage = () => !!sys() && val('kgew') === 'Heizung';
  $('kzusb').addEventListener('input', tausender);
  let kurzText = '';
  const WALLBOX = 1500; // Richtwert netto für Wallbox inkl. Anschluss, wird beim Preisvergleich der PV-Anlage abgezogen
  function kurzcheck() {
    const s = sys(), gr = num(val('kgr')), p = num(val('kpreis')), m = $('msg0'), f = [];
    if (!$('kdatei').files.length) f.push('kdatei');
    if (!val('kgew')) f.push('kgew'); else if (!s) f.push('ksys');
    if (s && !multi() && !(gr > 0)) f.push('kgr'); if (s && !(p > 100)) f.push('kpreis');
    const bw = id => Math.max(0, num(val(id)) || 0);
    if (s && multi()) {
      bauSel().forEach(k => { if (k === 'fen') { if (bw('n_fl') + bw('n_bt') + bw('n_df') + bw('n_hst') < 1) f.push('n_fl'); }
        else { const id = bauDefs().find(b => b.k === k).f[0][0]; if (!(bw(id) > 0)) f.push(id); } });
    }
    if (zusFrage() && !val('kzus')) f.push('kzus');
    if (s && !/^\d{5}$/.test(val('kplz'))) f.push('kplz');
    if (s && s[5] !== 'pv' && !val('kselbst')) f.push('kselbst');
    if (!$('keinw').checked) f.push('keinw');
    if ([...$('kdatei').files].some(x => x.size > MAXDATEI)) { m.textContent = 'Eine Datei ist größer als 10 MB. Bitte verkleinern.'; return; }
    if (s && (s[5] === 'wp' || s[5] === 'bio') && !val('kalt')) f.push('kalt');
    if (!$('kalterw').hidden && !val('kalter')) f.push('kalter');
    if (!markiere(q('#sac section[data-step="0"]'), f)) { m.textContent = 'Bitte die rot markierten Angaben ergänzen.'; return; }
    m.textContent = '';
    const pv = s[5] === 'pv', netto = pv || val('kmwst') === 'netto' ? p : p / 1.19, brutto = pv ? p : (val('kmwst') === 'netto' ? p * 1.19 : p);
    const DB = (C.preise && C.preise.systeme) || {}, mwstF = pv || val('kmwst') === 'netto' ? 1 : 1 / 1.19;
    const gaubeN = multi() && bauSel().includes('gaube') ? bw('e_gaube') * mwstF : 0, gaubeB = gaubeN / mwstF;
    const wb = s[5] === 'pv' && val('kwb') === 'ja', wabz = wb && netto - WALLBOX > 0 ? WALLBOX : 0, zl = zusFrage() ? zusL() : [], zusN = zl.length ? Math.min(Math.max(0, num(val('kzusb')) || 0) * mwstF, netto * .9) : 0, abzug = wabz + zusN;
    const je = (netto - abzug) / gr, einh = s[3].split(' ')[0], r = !multi() && s[2] ? DB[s[2]] : null;
    let h = `<h2>Ihr Ergebnis</h2>`;
    // 1. Preis
    if (multi()) {
      // Summe der Bausteine: erwarteter Rahmen aus den Vergleichswerten je Einheit, Sonderbauformen mit Aufschlag
      const teile = bauFelder().filter(x => x[4] && bw(x[0]) > 0), fehlt = teile.filter(x => !x[3] || !DB[x[3]]);
      const gaubeOhneKosten = bauSel().includes('gaube') && !gaubeN, basis = netto - gaubeN;
      const KURZ = { m_auf: 'm² Dach von außen', m_innen: 'm² Dach von innen', m_ogd: 'm² oberste Geschossdecke', n_fl: 'normale Fensterflügel', n_bt: 'bodentiefe Fensterflügel', n_df: 'Dachfenster', n_hst: 'Hebeschiebeanlagen', n_tuer: 'Haustür(en)' };
      const umfang = teile.map(x => `${de(bw(x[0]), 1)} ${KURZ[x[0]] || x[1]}`).join(', ');
      if (!fehlt.length && !gaubeOhneKosten && teile.length && basis > 0) {
        let lo = 0, hi = 0, med = 0;
        teile.forEach(x => { const rr = DB[x[3]], w = rr.n < 3 ? .2 : .15, q = bw(x[0]) * x[4]; lo += q * rr.min * (1 - w); hi += q * rr.max * (1 + w); med += q * rr.median; });
        const [cls, urteil] = basis < lo ? ['no', 'Auffällig günstig. Prüfen Sie, ob alle nötigen Leistungen enthalten sind, sonst kommen Nachträge.']
          : basis > hi ? ['no', 'Über meinen Vergleichswerten. Nachfragen und ein zweites Angebot lohnen sich.']
          : basis > med * 1.1 ? ['', 'Im üblichen Rahmen, eher im oberen Bereich.'] : basis < med * .9 ? ['', 'Im üblichen Rahmen, eher im unteren Bereich.'] : ['', 'Im üblichen Rahmen.'];
        const a = Math.min(lo, basis) * .9, b = Math.max(hi, basis) * 1.05, pos = x => Math.max(0, Math.min(100, (x - a) / (b - a) * 100));
        const sonder = gews().includes('Fenster und Außentüren') && (bw('n_bt') || bw('n_df') || bw('n_hst'));
        h += `<div class="sea-urteil ${cls}"><b>Preis: ${urteil}</b><br>Ihr Angebot: <b>${eur(basis)} netto</b>${gaubeN ? ` (ohne ${eur(gaubeN)} netto für die Gauben)` : ''} für ${esc(umfang)}.<br>
          Vergleichswerte aus geprüften Angeboten meiner Kundinnen und Kunden: ${eur(Math.round(lo / 100) * 100)} bis ${eur(Math.round(hi / 100) * 100)} netto für diesen Umfang.
          <div class="sac-bar" aria-hidden="true"><span class="sac-band" style="left:${pos(lo)}%;width:${pos(hi) - pos(lo)}%"></span><span class="sac-mark" style="left:${pos(basis)}%"></span></div>
          <small>Richtwert. Preise schwanken mit Region, Zugänglichkeit und Ausstattung${sonder ? '. Bodentiefe Fenster, Dachfenster und Hebeschiebeanlagen sind teurer als normale Fenster und mit Aufschlag eingerechnet' : ''}.</small></div>`;
        kurzText = `${s[1]}: ${de(basis)} € netto für ${umfang}, Rahmen ${de(lo)}–${de(hi)} → ${urteil}`;
      } else {
        const grund = gaubeOhneKosten ? 'Die Gauben sind im Angebot nicht einzeln ausgewiesen, deshalb ist ein Vergleich des Gesamtpreises nicht belastbar.'
          : `Für ${fehlt.map(x => '„' + x[1].split(',')[0] + '“').join(', ')} habe ich noch keine belastbaren Vergleichswerte.`;
        h += `<div class="sea-urteil"><b>Preis:</b> Ihr Angebot: ${eur(netto)} netto${umfang ? ' für ' + esc(umfang) : ''}. ${esc(grund)} In der persönlichen Prüfung bewerte ich die einzelnen Positionen.</div>`;
        kurzText = `${s[1]}: ${de(netto)} € netto, kein Vergleich (${grund})`;
      }
    } else if (r && zl.length && !zusN) {
      const zt = zl.map(k => ZUS[k]).join(', ');
      h += `<div class="sea-urteil"><b>Preis:</b> Ihr Angebot: ${eur(netto)} netto, darin enthalten auch ${esc(zt)}. Weil der Betrag dafür nicht einzeln angegeben ist, kann ich den Preis der Heizung nicht belastbar vergleichen. Tragen Sie den Betrag oben ein, wenn er im Angebot steht, oder lassen Sie das Angebot persönlich prüfen.</div>`;
      kurzText = `${s[1]}: ${de(netto)} € netto inkl. ${zt}, kein Vergleich (Betrag Zusatzleistungen fehlt)`;
    } else if (r) {
      const weit = r.n < 3 ? .2 : .15, lo = r.min * (1 - weit), hi = r.max * (1 + weit);
      const [cls, urteil] = je < lo ? ['no', 'Auffällig günstig. Prüfen Sie, ob alle nötigen Leistungen enthalten sind, sonst kommen Nachträge.']
        : je > hi ? ['no', 'Über meinen Vergleichswerten. Nachfragen und ein zweites Angebot lohnen sich.']
        : je > r.median * 1.1 ? ['', 'Im üblichen Rahmen, eher im oberen Bereich.']
        : je < r.median * .9 ? ['', 'Im üblichen Rahmen, eher im unteren Bereich.'] : ['', 'Im üblichen Rahmen.'];
      const a = Math.min(lo, je) * .9, b = Math.max(hi, je) * 1.05, pos = x => Math.max(0, Math.min(100, (x - a) / (b - a) * 100));
      h += `<div class="sea-urteil ${cls}"><b>Preis: ${urteil}</b><br>Ihr Angebot: <b>${eur(je)} je ${esc(einh)}</b> netto (${wabz ? `${eur(netto)} netto, davon für die Wallbox ${eur(wabz)} als Richtwert abgezogen, Rest ${eur(netto - abzug)} für ${de(gr, 1)} ${esc(einh)}` : zusN ? `${eur(netto)} netto, davon ${eur(zusN)} für ${esc(zl.map(k => ZUS[k]).join(', '))} abgezogen, Rest ${eur(netto - abzug)} für ${de(gr, 1)} ${esc(einh)}` : `${eur(netto)} netto für ${de(gr, 1)} ${esc(einh)}`}).<br>
        Vergleichswerte aus geprüften Angeboten meiner Kundinnen und Kunden: ${eur(Math.round(lo / 10) * 10)} bis ${eur(Math.round(hi / 10) * 10)} je ${esc(einh)} netto.
        <div class="sac-bar" aria-hidden="true"><span class="sac-band" style="left:${pos(lo)}%;width:${pos(hi) - pos(lo)}%"></span><span class="sac-mark" style="left:${pos(je)}%"></span></div>
        <small>Richtwert. Preise schwanken mit Region, Zugänglichkeit und Ausstattung${s[0] === 'wp' ? ', und kleine Wärmepumpen kosten je kW mehr als große' : ''}.</small></div>`;
      kurzText = `${s[1]}${zusN ? ` (ohne ${de(zusN)} € Zusatzleistungen)` : ''}: ${de(je)} €/${einh} netto, Spanne ${de(lo)}–${de(hi)} (n=${r.n}) → ${urteil}`;
    } else {
      h += `<div class="sea-urteil"><b>Preis:</b> Ihr Angebot entspricht ${eur(je)} je ${esc(einh)} netto. Für „${esc(s[1])}“ habe ich noch keine belastbaren Vergleichswerte. In der persönlichen Prüfung bewerte ich die einzelnen Positionen.</div>`;
      kurzText = `${s[1]}: ${de(je)} €/${einh} netto, keine Vergleichswerte`;
    }
    // 2. Förderung mit Knopf zum Förderrechner
    const fo = foerderung(s, brutto - gaubeB), mass = { Heizung: 'heizung', 'Fenster und Außentüren': 'fenster' }[gews().length === 1 ? gews()[0] : ''] || 'daemmung';
    const fr = `${C.foerderrechner}${C.foerderrechner.includes('?') ? '&' : '?'}massnahme=${mass}&kosten=${Math.round(brutto)}`;
    h += fo.z > 0 ? `<div class="sea-box"><p><b>Förderung: etwa ${eur(fo.z)} Zuschuss</b><br>${esc(fo.text)} Ihr Eigenanteil läge bei etwa ${eur(brutto - fo.z)}.</p>
        <p><a class="sac-knopf" href="${esc(fr)}" target="_blank" rel="noopener">Förderung genau berechnen im Förderrechner</a></p></div>`
      : `<div class="sea-box"><p><b>Förderung</b><br>${esc(fo.text)}</p></div>`;
    if (zl.some(k => k !== 'sonst')) fo.tips.unshift('Neue Heizkörper oder Fußbodenheizung, Elektroarbeiten und Schornstein gehören als Umfeldmaßnahmen meist zu den förderfähigen Kosten, wenn sie für die neue Heizung nötig sind.');
    if (zl.includes('sonst')) fo.tips.unshift('Leistungen ohne Bezug zur Heizung, zum Beispiel ein neues Bad, sind nicht förderfähig. Ich habe den Gesamtpreis angesetzt, die Förderung kann also niedriger ausfallen.');
    if (fo.z > 0) kurzText += ` | Förderung ca. ${de(fo.z)} €`;
    // 3. Persönliche Prüfung direkt im Blick
    h += `<div class="sac-cta"><h3>Genauer prüfen lassen</h3><p class="sea-hint">Der Kurzcheck vergleicht nur den Gesamtpreis. Persönlich prüfe ich Ihr Angebot Position für Position: Förderfähigkeit, Vollständigkeit und Preise, mit schriftlichem Prüfbericht und konkreten Fragen an den Betrieb, in der Regel am nächsten Werktag.</p>
      <div class="sea-tarife"><button type="button" class="sea-tarif sac-go" data-anz="1"><span class="sea-t-kopf">Angebotsbewertung</span><span class="sea-t-zeit">dieses Angebot</span><strong>${esc(C.preis)}</strong></button>
      <button type="button" class="sea-tarif sea-tarif-x sac-go" data-anz="3"><span class="sea-badge">Mit Gegenüberstellung</span><span class="sea-t-kopf">Angebotsvergleich</span><span class="sea-t-zeit">bis zu drei Angebote</span><strong>${esc(C.preis_vergleich)}</strong></button></div></div>`;
    // 4. Details
    h += `<h3>Weitere Hinweise zu Ihrem Angebot</h3>`;
    if (gaubeB || (multi() && bauSel().includes('gaube'))) fo.tips.unshift('Die Gaube selbst und die Fenster darin sind nicht förderfähig. Abriss und Neuaufbau, die zur Dämmung gehören, zum Beispiel die neue Eindeckung, sind dagegen förderfähig.' + (gaubeB ? ' Die Gauben habe ich herausgerechnet.' : ' Ich habe den Gesamtpreis angesetzt, der förderfähige Anteil ist also kleiner.'));
    if (fo.tips.length) h += `<div class="sea-box"><p><b>Zur Förderung</b></p><ul>${fo.tips.map(t => `<li>${esc(t)}</li>`).join('')}</ul></div>`;
    const tma = TMA[s[5]] || gews().map(g => TMA[g]).filter(Boolean).join(' ');
    if (tma) h += `<div class="sea-box"><p><b>Technische Mindestanforderungen für die Förderung</b><br>${esc(tma)} Ob das Angebot sie erfüllt, steht oft nur im Kleingedruckten oder gar nicht drin.</p></div>`;
    h += `<div class="sea-box"><p><b>Darauf sollten Sie im Angebot achten</b></p><ul>${gews().flatMap(g => LISTE[g] || []).map(t => `<li>${esc(t)}</li>`).join('')}</ul></div>`;
    h += `<p class="sea-hint">Alle Angaben ohne Gewähr. Der Kurzcheck ersetzt keine Prüfung des Angebots und keine Förderzusage.</p>`;
    $('kerg').innerHTML = h; $('kerg').hidden = false; $('kdirekt').hidden = true;
    kcSenden({ gewerk: val('kgew'), system: s[1], groesse: multi() ? bauFelder().map(x => x[1].split(',')[0] + ': ' + (val(x[0]) || '0')).join('; ') : gr, einheit: multi() ? '' : s[3], wallbox: wb ? 'ja' : '', zusatz: zl.join(','), zusatzbetrag: zusN ? Math.round(zusN) : '', preis: p, mwst: pv ? '0 %' : val('kmwst'), netto: Math.round(netto * 100) / 100, plz: val('kplz'),
      selbst: val('kselbst'), wohnungen: val('kwe'), ergebnis: kurzText, einwilligung: $('keinw').checked, website: val('hp') });
    const t = $('kerg').getBoundingClientRect().top + scrollY - 80; scrollTo({ top: t, behavior: 'smooth' });
  }
  $('krech').addEventListener('click', kurzcheck);

  // Übergabe vom Kurzcheck in die persönliche Prüfung
  function zurPruefung(anz) {
    const s = sys();
    if (val('kgew')) $('gewerk').value = gews()[0];
    if (gews().length > 1 && !val('frage')) $('frage').value = 'Gesamtangebot für: ' + gews().join(', ') + '.';
    if (zusFrage() && zusL().length && !val('frage')) $('frage').value = 'Im Angebot zusätzlich enthalten: ' + zusL().map(k => ZUS[k]).join(', ') + '.';
    if (s && s[6]) $('neu').value = s[6];
    if (val('kselbst')) $('selbst').value = val('kselbst');
    if (num(val('kwe')) >= 1 && !val('we')) $('we').value = Math.round(num(val('kwe')));
    const alt = { oel: 'oel', gas: 'gas', strom: 'strom' }[val('kalt')]; if (alt) $('alt').value = alt;
    if (/^\d{5}$/.test(val('kplz')) && !val('plz')) $('plz').value = val('kplz');
    if ($('kdatei').files.length && !$('a1').files.length) { const dt = new DataTransfer(); [...$('kdatei').files].forEach(f => dt.items.add(f)); $('a1').files = dt.files; $('a1').dispatchEvent(new Event('change')); }
    tarif(anz > 1 ? 'vergleich' : 'einzel'); sync(); show(1);
  }
  document.addEventListener('click', ev => { const b = ev.target.closest('#sac .sac-go'); if (b) zurPruefung(+b.dataset.anz); });
  $('kskip').addEventListener('click', ev => { ev.preventDefault(); zurPruefung(1); });

  // =====================================================================
  // Kacheln und Sichtbarkeit
  // =====================================================================
  // ---------- Gutscheincode wie beim Energieausweis: Prüfung bei Stripe, neuer Preis sofort sichtbar ----------
  const euro = x => parseFloat(String(x).replace(/[^\d,]/g, '').replace(',', '.')) || 0;
  const geld = n => (Math.round(n * 100) % 100 ? n.toFixed(2) : String(Math.round(n))).replace('.', ',');
  let gc = null, gcTimer = 0, gcFrage = '';
  function preisZeigen() {
    const vgl = $('anz').value === '3', basis = euro(vgl ? C.preis_vergleich : C.preis), info = $('gc-info');
    let rabatt = 0;
    if (gc && gc.status === 'ok') {
      if (gc[vgl ? 'vergleich' : 'einzel']) {
        rabatt = Math.min(basis, gc.betrag ? gc.betrag / 100 : Math.round(basis * gc.prozent) / 100);
        info.className = 'sea-gc-info ok'; info.textContent = `Gutschein ${gc.code}: −${geld(rabatt)} €`;
      } else { info.className = 'sea-gc-info no'; info.textContent = `Der Gutschein ${gc.code} gilt nicht für ${vgl ? 'den Angebotsvergleich' : 'die Angebotsbewertung'}.`; }
    } else if (gc && gc.status === 'ungueltig' && document.activeElement === $('gutschein')) { info.className = 'sea-gc-info'; info.textContent = '';
    } else if (gc && gc.status === 'ungueltig') { info.className = 'sea-gc-info no'; info.textContent = 'Diesen Gutscheincode gibt es nicht oder er ist abgelaufen.'; }
    else if (gc && gc.status === 'unbekannt') { info.className = 'sea-gc-info'; info.textContent = 'Der Code wird auf der Zahlungsseite geprüft und abgezogen.'; }
    else { info.className = 'sea-gc-info'; info.textContent = ''; }
    $('betrag').innerHTML = rabatt > 0 ? `<s>${geld(basis)} €</s> ${geld(basis - rabatt)} €` : esc(vgl ? C.preis_vergleich : C.preis);
  }
  async function gutscheinPruefen() {
    const code = val('gutschein').replace(/\s+/g, '').toUpperCase();
    if (code === gcFrage) return; gcFrage = code;
    if (!code) { gc = null; return preisZeigen(); }
    if (!C.gutschein) { gc = C.preview && code === 'TEST10' ? { status: 'ok', code, betrag: 1000, prozent: 0, einzel: true, vergleich: true } : { status: 'unbekannt' }; return preisZeigen(); }
    $('gc-info').className = 'sea-gc-info'; $('gc-info').textContent = document.activeElement === $('gutschein') ? '' : 'Code wird geprüft …';
    let r = null;
    try { const a = await fetch(C.gutschein + (C.gutschein.includes('?') ? '&' : '?') + 'code=' + encodeURIComponent(code)); r = a.ok ? await a.json() : null; } catch (e) {}
    if (code !== gcFrage) return;
    gc = r && r.status ? r : { status: 'unbekannt' }; preisZeigen();
  }
  // Während der Eingabe keine Meldung; geprüft wird nach 2 Sekunden Pause, beim Verlassen des Feldes oder mit Enter.
  $('gutschein').addEventListener('input', () => { clearTimeout(gcTimer); gc = null; gcFrage = ''; preisZeigen(); gcTimer = setTimeout(gutscheinPruefen, 2000); });
  $('gutschein').addEventListener('change', () => { clearTimeout(gcTimer); gutscheinPruefen(); });
  $('gutschein').addEventListener('blur', () => { if (gc) preisZeigen(); });
  $('gutschein').addEventListener('keydown', ev => { if (ev.key === 'Enter') { ev.preventDefault(); $('gutschein').blur(); } });
  { const u = new URLSearchParams(location.search), c = u.get('code'); if (c && /^[A-Za-z0-9_-]{2,40}$/.test(c)) { $('gutschein').value = c.toUpperCase(); gutscheinPruefen(); } }

  function tarif(t) { q(`input[name=sac-tarif][value=${t}]`).checked = true; $('anz').value = t === 'vergleich' ? '3' : '1'; }
  function sync() {
    document.querySelectorAll('#sac .sea-chips[data-for]').forEach(g => g.querySelectorAll('button').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.v === document.getElementById(g.dataset.for).value))));
    const wbb = q('#sac-ksysc [data-wb]'); if (wbb) wbb.setAttribute('aria-pressed', String(val('kwb') === 'ja'));
    // Kurzcheck
    const nwg = val('kart') === 'nwg'; $('knwg').hidden = !nwg; $('kwg').hidden = nwg; $('knav').hidden = nwg; $('kdirekt').hidden = nwg || !$('kerg').hidden;
    document.querySelectorAll('#sac [data-for="sac-kgew"] button').forEach(b => b.setAttribute('aria-pressed', String(gews().includes(b.dataset.v))));
    const sl = sysListe(), mb = multi() ? bauDefs() : null; $('ksysw').hidden = !sl.length && !mb;
    const key = mb ? 'M' + val('kgew') : sl.map(x => x[0]).join();
    if ($('ksysc').dataset.k !== key) {
      $('ksysc').dataset.k = key;
      if (mb) {
        $('ksysc').innerHTML = mb.map(b => `<button type="button" data-bt="${b.k}">${esc(b.t)}</button>`).join('');
        $('ksys').value = [...new Set([...bauSel(), ...gews().filter(g => BAU[g].length === 1).map(g => BAU[g][0].k)])].join(',');
        const alt = {}; document.querySelectorAll('#sac-kbau input').forEach(i => alt[i.id] = i.value);
        $('kbau').innerHTML = mb.map(b => `<div class="sac-bauk" data-b="${b.k}" hidden><p class="sac-bauh">${esc(b.t)}</p>` + b.f.map(x => `<label class="sac-zeile"><span class="sac-zl">${esc(x[1])}${x[5] ? `<small>${esc(x[5])}</small>` : ''}</span><span class="sac-einh" data-e="${esc(x[2])}"><input id="sac-${x[0]}" inputmode="decimal"${x[0] === 'n_tuer' ? ' value="1"' : ''}></span></label>`).join('') + '</div>').join('');
        q('#sac-e_gaube') && q('#sac-e_gaube').addEventListener('input', tausender);
        Object.entries(alt).forEach(([id, v]) => { const i = document.getElementById(id); if (i) i.value = v; });
      } else {
        $('ksysc').innerHTML = sl.map(x => `<button type="button" data-v="${x[0]}">${esc(x[1])}</button>`).join('') + (val('kgew') === 'Photovoltaik' ? '<button type="button" data-wb="1">mit Wallbox</button>' : '');
        $('kbau').innerHTML = '';
        if (!sl.some(x => x[0] === val('ksys'))) $('ksys').value = sl.length === 1 ? sl[0][0] : '';
      }
      return sync();
    }
    if (mb) { const sel = bauSel(); document.querySelectorAll('#sac-ksysc [data-bt]').forEach(b => b.setAttribute('aria-pressed', String(sel.includes(b.dataset.bt))));
      document.querySelectorAll('#sac-kbau .sac-bauk').forEach(l => l.hidden = !sel.includes(l.dataset.b)); }
    $('kbau').hidden = !mb || !bauSel().length;
    $('kgrw').hidden = !!mb;
    const s = sys(); $('kzahl').hidden = !s; $('kmwstw').hidden = !s || s[5] === 'pv'; $('kfoe').hidden = !s || s[5] === 'pv';
    if (s) { $('kgrl').textContent = 'Größe in ' + s[3]; $('kgr').placeholder = 'z. B. ' + s[4]; $('kgre').dataset.e = s[3].split(' ')[0]; }
    $('kaltw').hidden = !s || !['wp', 'bio'].includes(s[5]); $('kalterw').hidden = $('kaltw').hidden || !['gas', 'bio'].includes(val('kalt')); $('keinkw').hidden = !s || !['wp', 'bio', 'solar'].includes(s[5]) || val('kselbst') !== 'ja';
    $('kisfpw').hidden = !s || s[5] !== 'huelle';
    $('kzusw').hidden = !zusFrage(); $('kzusbw').hidden = $('kzusw').hidden || !zusL().length;
    document.querySelectorAll('#sac-kzusc [data-zu]').forEach(b => b.setAttribute('aria-pressed', String(val('kzus').split(',').includes(b.dataset.zu))));
    // Auftrag
    const e = ETR[$('alt').value]; $('einh').textContent = e ? `in ${e[1]}` : '(laut Abrechnung)';
    $('unter2w').hidden = val('unter1') !== 'ja';
    $('unter').value = val('unter1') === 'nein' ? 'nein' : val('unter1') === 'ja' && val('unter2') ? (val('unter2') === 'ja' ? 'ja' : 'ja-ohne') : '';
    $('unterhint').hidden = val('unter1') !== 'ja';
    const vgl = (q('input[name=sac-tarif]:checked') || {}).value === 'vergleich'; $('anz').value = vgl ? '3' : '1';
    $('u2').hidden = !vgl; $('u3').hidden = !vgl; document.querySelectorAll('#sac .sac-h1').forEach(x => x.hidden = vgl); document.querySelectorAll('#sac .sac-h3').forEach(x => x.hidden = !vgl); if (!vgl) $('nur1').hidden = true;
    const hz = istHz(), gw = val('gewerk');
    $('hz').hidden = !hz; $('buchbox').hidden = !hz; $('huelle').hidden = !gw || hz || gw === 'Photovoltaik';
    $('gw').textContent = gw ? '(' + gw + ')' : '';
    $('paket').textContent = vgl ? 'Angebotsvergleich' : 'Angebotsbewertung'; preisZeigen(); $('vgl-li').hidden = !vgl;
  }
  document.addEventListener('click', ev => {
    const b = ev.target.closest('#sac .sea-chips button'); if (!b) return;
    if (b.parentElement.dataset.for === 'sac-kgew') {
      const g = b.dataset.v, l = gews();
      $('kgew').value = BAU[g] && l.length && l.every(x => BAU[x]) ? (l.includes(g) ? l.filter(x => x !== g) : [...l, g]).join(',') : g;
      sync(); b.closest('.sea-frage').classList.remove('sea-err'); return;
    }
    if (b.dataset.zu) { const k = b.dataset.zu, l = val('kzus').split(',').filter(x => x && x !== 'nur'); $('kzus').value = k === 'nur' ? 'nur' : (l.includes(k) ? l.filter(x => x !== k) : [...l, k]).join(','); sync(); b.closest('.sea-frage').classList.remove('sea-err'); return; }
    if (b.dataset.wb) { $('kwb').value = val('kwb') === 'ja' ? '' : 'ja'; sync(); return; }
    if (b.dataset.bt) { const sel = bauSel(), k = b.dataset.bt; $('ksys').value = (sel.includes(k) ? sel.filter(x => x !== k) : [...sel, k]).join(','); sync(); b.closest('.sea-frage').classList.remove('sea-err'); return; }
    document.getElementById(b.parentElement.dataset.for).value = b.dataset.v; sync();
    b.closest('.sea-frage').classList.remove('sea-err');
  });
  document.querySelectorAll('#sac input[name=sac-tarif]').forEach(r => r.addEventListener('change', sync));

  // ---------- Dateien anzeigen und einzeln entfernen ----------
  const kb = n => n > 1e6 ? de(n / 1e6, 1) + ' MB' : Math.max(1, Math.round(n / 1e3)) + ' KB';
  document.querySelectorAll('#sac input[type=file]').forEach(inp => {
    const ul = document.createElement('ul'); ul.className = 'sea-files'; ul.hidden = true;
    inp.closest('.sea-upl').insertAdjacentElement('afterend', ul);
    const zeigen = () => { const fs = [...inp.files]; ul.hidden = !fs.length;
      ul.innerHTML = fs.map((f, i) => `<li><span>${esc(f.name)} <small>${kb(f.size)}${f.size > MAXDATEI ? ' – zu groß' : ''}</small></span><button type="button" class="sea-sec" data-weg="${i}" aria-label="${esc(f.name)} entfernen">✕ Entfernen</button></li>`).join('');
      if (fs.length && inp.id !== 'sac-a1') $('nur1').hidden = true; };
    inp.addEventListener('change', zeigen);
    ul.addEventListener('click', ev => { const b = ev.target.closest('[data-weg]'); if (!b) return;
      const dt = new DataTransfer(); [...inp.files].forEach((f, i) => { if (i !== +b.dataset.weg) dt.items.add(f); });
      inp.files = dt.files; inp.dispatchEvent(new Event('change', { bubbles: true })); });
  });
  const dateien = () => { const n = +$('anz').value || 1; return ['a1', 'a2', 'a3'].slice(0, n).flatMap(k => [...$(k).files].slice(0, MAXJE).map(f => [k, f])); };

  // ---------- Auswahl-Rad wie beim Energieausweis: antippen, wischen, übernehmen ----------
  const RH = 44, rad = document.createElement('div');
  rad.className = 'sea-rad'; rad.hidden = true;
  rad.innerHTML = '<div class="sea-rad-p" role="dialog" aria-modal="true" aria-label="Wert wählen"><div class="sea-rad-t"></div><div class="sea-rad-l" tabindex="0"></div><div class="sea-rad-n"><button type="button" class="sea-sec" data-radx>Abbrechen</button><button type="button" data-radok>Übernehmen</button></div></div>';
  document.getElementById('sac').appendChild(rad);
  const rl = rad.querySelector('.sea-rad-l');
  let radFeld = null, radVon = 0, radSchritt = 1, radRaf = 0;
  const radIdx = () => Math.max(0, Math.min(rl.children.length - 1, Math.round(rl.scrollTop / RH)));
  const radMark = () => { const i = radIdx(); [...rl.children].forEach((x, k) => x.classList.toggle('on', k === i)); };
  rl.addEventListener('scroll', () => { cancelAnimationFrame(radRaf); radRaf = requestAnimationFrame(radMark); });
  function radAuf(inp) {
    radFeld = inp; radVon = +inp.dataset.von; radSchritt = +inp.dataset.schritt || 1; const bis = +inp.dataset.bis || new Date().getFullYear(), einh = inp.dataset.einheit || '';
    rl.innerHTML = Array.from({ length: Math.floor((bis - radVon) / radSchritt) + 1 }, (_, i) => `<div data-j="${radVon + i * radSchritt}">${radVon + i * radSchritt}${einh}</div>`).join('');
    rad.querySelector('.sea-rad-t').textContent = inp.closest('label').firstChild.textContent.trim();
    rad.hidden = false;
    const start = Math.min(bis, Math.max(radVon, num(inp.value) || +inp.dataset.rad));
    rl.scrollTop = Math.round((start - radVon) / radSchritt) * RH; radMark(); rl.focus({ preventScroll: true });
  }
  function radZu(ok) {
    if (ok && radFeld) { radFeld.value = radVon + radIdx() * radSchritt; radFeld.dispatchEvent(new Event('input', { bubbles: true })); radFeld.dispatchEvent(new Event('change', { bubbles: true })); radFeld.classList.remove('sea-err'); }
    rad.hidden = true; radFeld = null;
  }
  document.querySelectorAll('#sac [data-rad]').forEach(inp => {
    inp.addEventListener('click', () => radAuf(inp));
    inp.addEventListener('keydown', ev => { if (ev.key === 'Enter' || ev.key === ' ' || ev.key === 'ArrowDown') { ev.preventDefault(); radAuf(inp); } });
  });
  rl.addEventListener('click', ev => { const d = ev.target.closest('[data-j]'); if (!d) return; const i = (+d.dataset.j - radVon) / radSchritt; if (i === radIdx()) radZu(true); else rl.scrollTo({ top: i * RH, behavior: 'smooth' }); });
  rl.addEventListener('keydown', ev => {
    if (ev.key === 'ArrowDown' || ev.key === 'ArrowUp') { ev.preventDefault(); rl.scrollTop = (radIdx() + (ev.key === 'ArrowDown' ? 1 : -1)) * RH; }
    if (ev.key === 'Enter') { ev.preventDefault(); radZu(true); }
  });
  rad.addEventListener('keydown', ev => { if (ev.key === 'Escape') radZu(false); });
  rad.addEventListener('click', ev => { if (ev.target === rad || ev.target.matches('[data-radx]')) radZu(false); if (ev.target.matches('[data-radok]')) radZu(true); });

  // ---------- Pflichtfelder ----------
  function markiere(sec, ids) {
    sec.querySelectorAll('.sea-err').forEach(x => x.classList.remove('sea-err'));
    const els = ids.map(i => { const x = $(i); if (!x) return null; if (x.type === 'checkbox') return x.closest('label'); if (x.type === 'hidden') return x.closest('.sea-frage'); if (x.type === 'file') return x.closest('.sea-upl'); return x; }).filter(Boolean);
    els.forEach(x => x.classList.add('sea-err'));
    if (els[0]) { const t = els[0].getBoundingClientRect().top + scrollY - 120; if (t < scrollY) scrollTo({ top: t }); }
    return !els.length;
  }
  function check(n) {
    const sec = q(`#sac section[data-step="${n}"]`), m = $('msg' + n), f = [];
    if (n === 1) {
      if (!val('gewerk')) f.push('gewerk');
      if (istHz()) { if (!val('neu')) f.push('neu'); if (!val('alt')) f.push('alt'); if (!val('hfl')) f.push('hfl'); }
      const bj = +val('bj'); if (!(bj >= 1800 && bj <= 2026)) f.push('bj');
      if (!(num(val('wfl')) >= 20)) f.push('wfl'); if (!(+val('we') >= 1)) f.push('we');
      if (!/^\d{5}$/.test(val('plz'))) f.push('plz');
      if (!val('selbst')) f.push('selbst'); if (!val('unter1')) f.push('unter1'); else if (val('unter1') === 'ja' && !val('unter2')) f.push('unter2');
    }
    if (n === 2) {
      if (!C.preview && !$('a1').files.length) f.push('a1');
      if (!$('eins').checked) f.push('eins');
      const fs = dateien();
      if (fs.some(([, x]) => x.size > MAXDATEI)) { m.textContent = 'Eine Datei ist größer als 10 MB. Bitte verkleinern oder als Foto mit geringerer Auflösung hochladen.'; return false; }
      if (fs.reduce((s, [, x]) => s + x.size, 0) > MAXSUMME) { m.textContent = 'Zusammen sind die Dateien zu groß (max. 60 MB). Bitte Fotos verkleinern oder PDFs nutzen.'; return false; }
      // Vergleich gewählt, aber nur ein Angebot hochgeladen: nachfragen
      if (!f.length && $('anz').value === '3' && !$('a2').files.length && !$('a3').files.length && !C.preview) {
        $('nur1').hidden = false; m.textContent = ''; $('nur1').scrollIntoView({ block: 'center' }); return false; }
    }
    if (n === 3) {
      if (!val('vorname')) f.push('vorname'); if (!val('nachname')) f.push('nachname');
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(val('email'))) f.push('email');
      if (!$('ds').checked) f.push('ds'); if (!$('widerruf').checked) f.push('widerruf');
    }
    const ok = markiere(sec, f);
    m.textContent = ok ? '' : 'Bitte die rot markierten Angaben ergänzen.';
    return ok;
  }
  $('nur1-ok').addEventListener('click', () => { tarif('einzel'); sync(); show(3); });
  $('nur1-mehr').addEventListener('click', () => { $('nur1').hidden = true; $('a2').click(); });

  // ---------- Vorprüfung für Stephan (nur grobe Richtwerte aus dem Verbrauch) ----------
  function vorpruefung() {
    const e = ETR[val('alt')], v = num(val('verbr')), a = num(val('wfl'));
    if (!istHz()) return '–';
    if (!e || !(v > 0) || !(a > 0)) return 'Kein Verbrauch angegeben, Heizlast nicht abschätzbar.';
    const kwh = v * e[2] * e[3], ww = 12.5 * a, hl = Math.max(3, (kwh - ww) / 2000);
    return `Wärmebedarf ca. ${de(kwh)} kWh/a (${de(kwh / a)} kWh/m²a), davon Warmwasser ca. ${de(ww)} kWh. Heizlast grob ${de(hl, 1)} kW (Verbrauch / 2000 h, ohne Gewähr).`;
  }
  function daten() {
    const e = ETR[val('alt')] || ['', ''], hz = istHz() ? { 'Angeboten': val('neu'), 'Heizung heute': e[0], 'Baujahr alte Heizung': val('bjhz') || 'k. A.',
      'Verbrauch letztes Jahr': val('verbr') ? `${val('verbr')} ${e[1]}` : 'k. A.', 'Heizflächen': val('hfl') } : {};
    const vgl = $('anz').value === '3';
    return {
      haus: { 'Gewerk': val('gewerk'), ...hz, 'Baujahr Haus': val('bj'), 'Wohnfläche': val('wfl') + ' m²', 'Wohnungen': val('we'), 'Selbst bewohnt': val('selbst'),
        'Schon unterschrieben': { nein: 'nein', ja: 'ja, mit Förder-Vorbehalt', 'ja-ohne': 'ja, ohne Vorbehalt / unklar' }[val('unter')] || '', 'PLZ': val('plz'),
        'Angebote hochgeladen': String(['a1', 'a2', 'a3'].slice(0, vgl ? 3 : 1).filter(k => $(k).files.length).length) },
      kontakt: { vorname: val('vorname'), nachname: val('nachname'), email: val('email'), tel: val('tel') },
      frage: val('frage'), vorpruefung: vorpruefung(), kurzcheck: kurzText, tarif: vgl ? 'vergleich' : 'einzel', website: val('hp')
    };
  }
  function uebersicht() {
    const d = daten(), n = dateien();
    $('sum').innerHTML = [['Haus', `${d.haus['Wohnfläche']}, Baujahr ${d.haus['Baujahr Haus']}, ${d.haus['Wohnungen']} Wohnung(en), PLZ ${d.haus.PLZ}`], ['Gewerk', d.haus.Angeboten ? `${d.haus.Gewerk}: ${d.haus['Heizung heute']} → ${d.haus.Angeboten}` : d.haus.Gewerk],
      ['Angebote', `${d.haus['Angebote hochgeladen']} Angebot(e), ${n.length} Datei(en)`], ['Kontakt', `${d.kontakt.vorname} ${d.kontakt.nachname}, ${d.kontakt.email}`]]
      .map(([a, b]) => `<dt>${a}</dt><dd>${esc(b)}</dd>`).join('');
    if (C.preview) $('mail').value = `Paket: ${d.tarif === 'vergleich' ? 'Angebotsvergleich ' + C.preis_vergleich : 'Angebotsbewertung ' + C.preis}\n` + Object.entries(d.haus).map(([k, v]) => `${k}: ${v}`).join('\n') + `\n\nKurzcheck: ${d.kurzcheck || '–'}\nVorprüfung: ${d.vorpruefung}\nFrage: ${d.frage || '–'}\nDateien: ${n.map(([k, f]) => k + ' ' + f.name).join(', ')}`;
  }

  $('pay').addEventListener('click', async () => {
    const m = $('msg4'); m.className = 'sea-msg';
    if (!C.endpoint) { m.className = 'sea-msg gut'; m.textContent = 'Vorschau: Hier geht es im Live-Betrieb zur Stripe-Zahlung. Der Auftrag geht mit allen Dateien an info@s-energies.de, sobald bezahlt ist.'; return; }
    const d = daten(), fd = new FormData();
    fd.append('daten', JSON.stringify(d));
    dateien().forEach(([k, f], i) => fd.append('datei' + i, f, k + '__' + f.name));
    $('pay').disabled = true; m.className = 'sea-msg gut'; m.textContent = 'Unterlagen werden übertragen …';
    try {
      const r = await fetch(C.endpoint, { method: 'POST', body: fd }); const j = await r.json().catch(() => ({}));
      if (!r.ok || !j.ok) throw new Error(j.fehler || '');
      const z = d.tarif === 'vergleich' ? C.zahlungslink_vergleich : C.zahlungslink;
      if (z) { m.textContent = 'Weiter zur Zahlung …'; location.href = z + (z.includes('?') ? '&' : '?') + 'client_reference_id=' + encodeURIComponent(j.id) + '&prefilled_email=' + encodeURIComponent(d.kontakt.email) + (val('gutschein') && !(gc && gc.status === 'ungueltig') ? '&prefilled_promo_code=' + encodeURIComponent(val('gutschein').replace(/\s+/g, '').toUpperCase()) : ''); return; }
      $('fertig').textContent = `Ihre Auftragsnummer ist ${j.id}. Ich melde mich per E-Mail mit dem Zahlungslink.`; show(5);
    } catch (e) { m.className = 'sea-msg'; m.textContent = (e.message || 'Die Übertragung hat nicht geklappt.') + ' Bitte versuchen Sie es noch einmal oder schreiben Sie an info@s-energies.de.'; $('pay').disabled = false; }
  });

  // ---------- Navigation ----------
  let step = 0;
  function show(n) {
    step = n;
    document.querySelectorAll('#sac [data-step]').forEach(s => s.hidden = +s.dataset.step !== n);
    $('steps').hidden = n < 1 || n > 4;
    document.querySelectorAll('#sac-steps li').forEach((li, i) => li.classList.toggle('on', i < n));
    if (n === 4) uebersicht();
    const top = $('f').getBoundingClientRect().top + scrollY - 90; if (scrollY > top) scrollTo({ top });
  }
  $('f').addEventListener('click', ev => {
    const t = ev.target;
    if (t.matches('[data-back]')) show(step - 1);
    if (t.matches('[data-next]') && check(step)) show(step + 1);
  });
  $('f').addEventListener('input', ev => { const x = ev.target; if (x.classList.contains('sea-err') && x.value) x.classList.remove('sea-err'); const l = x.closest('.sea-err'); if (l && (x.checked || x.files && x.files.length)) l.classList.remove('sea-err'); });
  $('f').addEventListener('submit', e => e.preventDefault());

  // ---------- Rückkehr von Stripe: Dankeseite und sofortige Zahlungsprüfung ----------
  { const u = new URLSearchParams(location.search);
    if (u.has('danke')) {
      document.querySelectorAll('#sac [data-step]').forEach(s => s.hidden = s.dataset.step !== '6');
      $('steps').hidden = false; document.querySelectorAll('#sac-steps li').forEach(li => li.classList.add('on'));
      const sid = u.get('session_id') || '';
      if (C.zahlung && /^cs_(live|test)_[A-Za-z0-9]+$/.test(sid)) fetch(C.zahlung + (C.zahlung.includes('?') ? '&' : '?') + 'sid=' + encodeURIComponent(sid)).catch(() => {});
    } }
  sync();

  if (C.preview) {
    const b = document.createElement('button'); b.type = 'button'; b.className = 'sea-sec'; b.textContent = 'Testdaten einfügen';
    b.style.cssText = 'margin-left:10px;padding:2px 10px;font-size:12px;color:#f2f1e5;border-color:rgba(242,241,229,.4)';
    $('tag').after(b);
    b.addEventListener('click', () => {
      Object.entries({ kgew: 'Heizung', kselbst: 'ja', kwe: 1, kalt: 'oel', bj: 1978, wfl: '145', we: 1, bjhz: 1998, verbr: '2400', plz: '91301', hfl: 'Heizkörper', unter1: 'nein', vorname: 'Anna', nachname: 'Muster', email: 'anna.muster@example.de', tel: '09191 123456' }).forEach(([k, x]) => $(k).value = x);
      sync(); $('ksys').value = 'wp'; $('kgr').value = '9'; $('kpreis').value = '38.900';
      ['ds', 'widerruf', 'eins'].forEach(k => $(k).checked = true); sync();
    });
  }
})();
