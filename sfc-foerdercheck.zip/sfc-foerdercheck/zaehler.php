<?php
// sENERGIEs Fördercheck: anonymer Nutzungszähler (seit 1.8.4, Angebotscheck seit 1.8.5). Speichert nur Tageszahlen je Ereignis,
// keine IP, keine Cookies, nichts im Browser. Anzeige im Dashboard-Widget „Fördercheck: Nutzung“.
if (!defined('ABSPATH')) exit;

const SFC_ZAEHLER_EREIGNISSE = [
  'aufruf' => 'Seite mit Rechner aufgerufen',
  'start' => 'Rechner begonnen (erste Auswahl)',
  'ergebnis' => 'Ergebnis erreicht',
  'anfrage' => 'Anfrage gesendet',
  'pdf' => 'PDF erstellt',
  'buch' => 'Buchhinweis geklickt',
  'partner_interesse' => 'PLZ im Ergebnis geprüft',
  'partner' => 'Aroundhome-Link geklickt',
  'ac_aufruf' => 'Angebotscheck: Seite aufgerufen',
  'ac_kc_start' => 'Angebotscheck: Kurzcheck begonnen',
  'ac_kc_ergebnis' => 'Angebotscheck: Kurzcheck-Ergebnis erreicht',
  'ac_pruefung' => 'Angebotscheck: persönliche Prüfung geöffnet',
  'ac_bestellung' => 'Angebotscheck: zur Zahlung weitergeleitet',
  'ac_ah' => 'Angebotscheck: Aroundhome-Link geklickt',
  'ac_buchung' => 'Angebotscheck: Online-Beratung angeklickt',
];

// Skript nur für Besucher, nicht für angemeldete Redakteure/Admins (deren Tests sollen nicht mitzählen)
function sfc_zaehler_einbinden() {
  if (is_user_logged_in() && current_user_can('edit_posts')) return;
  static $fertig = false; if ($fertig) return; $fertig = true;
  $dir = plugin_dir_path(__FILE__);
  wp_enqueue_script('sfc-zaehler', plugin_dir_url(__FILE__) . sfc_datei($dir, 'zaehler.js'), [], null, ['in_footer' => true, 'strategy' => 'defer']);
  $id = (is_singular() || is_front_page()) ? (int) get_queried_object_id() : 0;
  wp_add_inline_script('sfc-zaehler', 'window.SFC_ZAEHLER=' . wp_json_encode(['url' => rest_url('sfc/v1/zaehler'), 'id' => $id]) . ';', 'before');
}

// Seitenaufrufe (seit 1.9.11): Zähler-Skript auf allen Seiten und Beiträgen, damit sichtbar wird, ob Besucher (z. B. von Social Media) kommen
add_action('wp_enqueue_scripts', function () {
  if (is_admin() || !(is_singular() || is_front_page())) return;
  sfc_zaehler_einbinden();
});

const SFC_ZAEHLER_QUELLEN = ['direkt', 'google', 'suche', 'facebook', 'instagram', 'whatsapp', 'social', 'intern', 'andere'];

// Speichert einen Seitenaufruf: Option sfc_seiten [Tag][Seiten-ID][Quelle] = Anzahl (nur veröffentlichte Seiten/Beiträge)
function sfc_zaehler_seite($id, $q) {
  $id = (int) $id;
  if ($id <= 0 || get_post_status($id) !== 'publish' || !in_array(get_post_type($id), ['page', 'post'], true)) return false;
  if (!in_array($q, SFC_ZAEHLER_QUELLEN, true)) $q = 'andere';
  $z = get_option('sfc_seiten', []); if (!is_array($z)) $z = [];
  $tag = wp_date('Y-m-d');
  $z[$tag][$id][$q] = (int) ($z[$tag][$id][$q] ?? 0) + 1;
  if (count($z) > 400) { ksort($z); $z = array_slice($z, -400, null, true); }
  update_option('sfc_seiten', $z, false);
  return true;
}

// Summen je Seite für die letzten $tage Tage: [id => ['n' => gesamt, 'q' => [quelle => n]]], absteigend sortiert
function sfc_zaehler_seiten_summen($tage) {
  $z = get_option('sfc_seiten', []); if (!is_array($z)) $z = [];
  $heute = strtotime(wp_date('Y-m-d')); $s = [];
  foreach ($z as $tag => $seiten) {
    if (($heute - strtotime($tag)) / DAY_IN_SECONDS >= $tage) continue;
    foreach ($seiten as $id => $qs) foreach ($qs as $q => $n) {
      $s[$id]['n'] = ($s[$id]['n'] ?? 0) + (int) $n;
      $s[$id]['q'][$q] = ($s[$id]['q'][$q] ?? 0) + (int) $n;
    }
  }
  uasort($s, function ($a, $b) { return $b['n'] <=> $a['n']; });
  return $s;
}

add_action('rest_api_init', function () {
  register_rest_route('sfc/v1', '/zaehler', [
    ['methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => function (WP_REST_Request $r) {
      $e = (string) $r->get_param('e');
      if ($e !== 'seite' && !isset(SFC_ZAEHLER_EREIGNISSE[$e])) return new WP_REST_Response(['ok' => false], 400);
      $ua = (string) ($_SERVER['HTTP_USER_AGENT'] ?? '');
      if ($ua === '' || preg_match('/bot|crawl|spider|slurp|preview|headless|lighthouse|pagespeed|facebookexternalhit|whatsapp\/|python|curl|wget/i', $ua)) return new WP_REST_Response(['ok' => true], 202);
      if (is_user_logged_in() && current_user_can('edit_posts')) return new WP_REST_Response(['ok' => true], 202);
      if ($e === 'seite') {
        $ok = sfc_zaehler_seite($r->get_param('id'), (string) $r->get_param('q'));
        return new WP_REST_Response(['ok' => $ok], $ok ? 200 : 400);
      }
      $z = get_option('sfc_zaehler', []);
      if (!is_array($z)) $z = [];
      $tag = wp_date('Y-m-d');
      $z[$tag][$e] = (int) ($z[$tag][$e] ?? 0) + 1;
      if (count($z) > 400) { ksort($z); $z = array_slice($z, -400, null, true); }
      update_option('sfc_zaehler', $z, false);
      return new WP_REST_Response(['ok' => true], 200);
    }],
    // Lesen nur für Admins (z. B. für Auswertungen per REST)
    ['methods' => 'GET', 'permission_callback' => function () { return current_user_can('manage_options'); }, 'callback' => function () {
      $seiten = [];
      foreach ([7, 30] as $t) foreach (sfc_zaehler_seiten_summen($t) as $id => $w) {
        $seiten[$id]['titel'] = get_the_title($id); $seiten[$id]['pfad'] = wp_make_link_relative(get_permalink($id));
        $seiten[$id][(string) $t] = $w;
      }
      return ['tage' => get_option('sfc_zaehler', []), 'summen' => sfc_zaehler_summen(), 'seiten_tage' => get_option('sfc_seiten', []), 'seiten' => $seiten];
    }],
  ]);
});

function sfc_zaehler_summen() {
  $z = get_option('sfc_zaehler', []); if (!is_array($z)) $z = [];
  $heute = wp_date('Y-m-d'); $s = [];
  foreach (SFC_ZAEHLER_EREIGNISSE as $e => $l) {
    $s[$e] = ['heute' => 0, '7' => 0, '30' => 0, 'gesamt' => 0];
    foreach ($z as $tag => $w) {
      $n = (int) ($w[$e] ?? 0); if (!$n) continue;
      $alter = (strtotime($heute) - strtotime($tag)) / DAY_IN_SECONDS;
      $s[$e]['gesamt'] += $n;
      if ($alter < 30) $s[$e]['30'] += $n;
      if ($alter < 7) $s[$e]['7'] += $n;
      if ($alter < 1) $s[$e]['heute'] += $n;
    }
  }
  return $s;
}

add_action('wp_dashboard_setup', function () {
  if (!current_user_can('edit_posts')) return;
  wp_add_dashboard_widget('sfc_zaehler', 'Fördercheck: Nutzung', function () {
    $z = get_option('sfc_zaehler', []);
    if (!$z) { echo '<p>Noch keine Zahlen. Gezählt wird seit dem Update auf Version 1.8.4 (Angebotscheck seit 1.8.5), nur Besucher (deine eigenen Tests als angemeldeter Nutzer zählen nicht).</p>'; return; }
    $s = sfc_zaehler_summen();
    echo '<table class="widefat striped" style="border:0"><thead><tr><th></th><th style="text-align:right">Heute</th><th style="text-align:right">7 Tage</th><th style="text-align:right">30 Tage</th><th style="text-align:right">Gesamt</th></tr></thead><tbody>';
    foreach (SFC_ZAEHLER_EREIGNISSE as $e => $l) {
      if (in_array($e, ['partner_interesse', 'partner'], true) && !$s[$e]['gesamt']) continue;
      if ($e === 'ac_aufruf') echo '<tr><td colspan="5" style="padding-top:12px"><strong>Angebotscheck</strong></td></tr>';
      printf('<tr><td>%s</td><td style="text-align:right">%d</td><td style="text-align:right">%d</td><td style="text-align:right">%d</td><td style="text-align:right">%d</td></tr>', esc_html($l), $s[$e]['heute'], $s[$e]['7'], $s[$e]['30'], $s[$e]['gesamt']);
    }
    echo '</tbody></table>';
    $s7 = sfc_zaehler_seiten_summen(7); $s30 = sfc_zaehler_seiten_summen(30);
    if ($s30) {
      echo '<p style="margin:14px 0 4px"><strong>Seitenaufrufe</strong> (seit 1.9.11, Quelle = woher der Besucher kam)</p><table class="widefat striped" style="border:0"><thead><tr><th>Seite</th><th style="text-align:right">7 Tage</th><th style="text-align:right">30 Tage</th><th>Quellen (30 Tage)</th></tr></thead><tbody>';
      foreach (array_slice($s30, 0, 15, true) as $id => $w) {
        arsort($w['q']); $q = []; foreach ($w['q'] as $k => $n) $q[] = $k . ' ' . $n;
        printf('<tr><td>%s</td><td style="text-align:right">%d</td><td style="text-align:right">%d</td><td>%s</td></tr>', esc_html(get_the_title($id) ?: '#' . $id), (int) ($s7[$id]['n'] ?? 0), $w['n'], esc_html(implode(', ', $q)));
      }
      echo '</tbody></table>';
    }
    printf('<p class="description" style="margin-top:8px">Gezählt seit %s. Jedes Ereignis zählt höchstens einmal pro Seitenaufruf. Anonym: keine Cookies, keine IP-Adressen, keine Daten im Browser.</p>', esc_html(wp_date('d.m.Y', strtotime(min(array_keys($z))))));
  });
});
