<?php
// Lizenz-Server für Fördercheck Pro: Pro-Installationen fragen einmal am Tag, ob das Abo zur eingetragenen E-Mail aktiv ist.
// Geprüft wird bei Stripe mit einem eingeschränkten Schlüssel (nur Lesen: Kunden und Abos), eingetragen unter Einstellungen → Fördercheck-Lizenzen.
if (!defined('ABSPATH')) exit;

const SFC_LIZ_PRODUKT = 'prod_VW6huTj8ZBX82G'; // Stripe-Produkt „Fördercheck Pro“

add_action('rest_api_init', function () {
  register_rest_route('sfc/v1', '/lizenz', ['methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => 'sfc_liz_pruefen']);
});

function sfc_liz_stripe($pfad, array $q) {
  $key = (string) get_option('sfc_liz_stripe_key', '');
  if ($key === '') return null;
  $r = wp_remote_get('https://api.stripe.com/v1/' . $pfad . '?' . http_build_query($q), ['timeout' => 8, 'headers' => ['Authorization' => 'Bearer ' . $key]]);
  if (is_wp_error($r) || wp_remote_retrieve_response_code($r) !== 200) return null;
  $j = json_decode(wp_remote_retrieve_body($r), true);
  return is_array($j) ? $j : null;
}

// true = aktives Abo, false = keins, null = Prüfung nicht möglich (kein Schlüssel, Stripe nicht erreichbar)
function sfc_liz_status($mail) {
  $k = sfc_liz_stripe('customers', ['email' => $mail, 'limit' => 10]);
  if ($k === null) return null;
  foreach ($k['data'] ?? [] as $c) {
    $s = sfc_liz_stripe('subscriptions', ['customer' => $c['id'], 'status' => 'all', 'limit' => 20]);
    if ($s === null) return null;
    foreach ($s['data'] ?? [] as $sub) {
      if (!in_array($sub['status'] ?? '', ['active', 'trialing', 'past_due'], true)) continue;
      foreach ($sub['items']['data'] ?? [] as $it) if (($it['price']['product'] ?? '') === SFC_LIZ_PRODUKT) return true;
    }
  }
  return false;
}

function sfc_liz_pruefen(WP_REST_Request $r) {
  $mail = strtolower(sanitize_email((string) $r->get_param('mail')));
  $site = esc_url_raw((string) $r->get_param('site'));
  if (!is_email($mail)) return new WP_REST_Response(['aktiv' => false, 'grund' => 'mail'], 200);
  $ip = 'sfc_liz_rl_' . md5($_SERVER['REMOTE_ADDR'] ?? '');
  $n = (int) get_transient($ip);
  if ($n >= 60) return new WP_REST_Response(['aktiv' => null], 200);
  set_transient($ip, $n + 1, HOUR_IN_SECONDS);
  $ck = 'sfc_liz_' . md5($mail);
  $a = get_transient($ck);
  if ($a === false) {
    $st = sfc_liz_status($mail);
    $a = $st === null ? 'x' : ($st ? '1' : '0');
    if ($st !== null) set_transient($ck, $a, 6 * HOUR_IN_SECONDS);
  }
  $aktiv = $a === 'x' ? null : $a === '1';
  // Protokoll der letzten 100 Abfragen für die Übersicht
  $log = get_option('sfc_liz_log', []);
  $log[$mail . '|' . $site] = ['mail' => $mail, 'site' => $site, 'aktiv' => $aktiv, 'zeit' => time()];
  uasort($log, function ($x, $y) { return $y['zeit'] <=> $x['zeit']; });
  update_option('sfc_liz_log', array_slice($log, 0, 100, true), false);
  return new WP_REST_Response(['aktiv' => $aktiv], 200);
}

add_action('admin_menu', function () {
  add_options_page('Fördercheck-Lizenzen', 'Fördercheck-Lizenzen', 'manage_options', 'sfc-lizenzen', function () {
    if (isset($_POST['sfc_liz_save']) && check_admin_referer('sfc_liz_save')) {
      $k = trim(sanitize_text_field(wp_unslash($_POST['stripe_key'] ?? '')));
      if ($k !== '') update_option('sfc_liz_stripe_key', $k, false);
      echo '<div class="updated"><p>Gespeichert.</p></div>';
    }
    $hat = get_option('sfc_liz_stripe_key', '') !== '';
    echo '<div class="wrap"><h1>Fördercheck-Lizenzen</h1><p>Fördercheck Pro fragt hier einmal am Tag, ob das Abo des Kunden noch läuft. Ohne aktives Abo zeigt Pro nur noch den Rechner (ohne Anfrageformular und PDF) und bekommt keine Updates mehr.</p>';
    echo '<form method="post">'; wp_nonce_field('sfc_liz_save');
    echo '<table class="form-table"><tr><th><label for="stripe_key">Stripe-Schlüssel (eingeschränkt)</label></th><td><input type="password" id="stripe_key" name="stripe_key" class="regular-text" autocomplete="off" placeholder="' . ($hat ? 'gespeichert, nur zum Ändern neu eintragen' : 'rk_live_…') . '">'
      . '<p class="description">Stripe → Entwickler → API-Schlüssel → „Eingeschränkten Schlüssel erstellen“, Rechte: Customers „Lesen“, Subscriptions „Lesen“, Checkout Sessions „Lesen“ (Zahlungsprüfung der Energieausweis-Aufträge), Coupons und Promotion Codes „Lesen“ (Gutscheinpreis im Formular), sonst nichts.</p></td></tr></table>';
    echo '<p><button class="button button-primary" name="sfc_liz_save" value="1">Speichern</button></p></form>';
    echo '<h2>Letzte Abfragen</h2><table class="widefat striped"><thead><tr><th>Website</th><th>E-Mail</th><th>Abo</th><th>Zeit</th></tr></thead><tbody>';
    foreach (get_option('sfc_liz_log', []) as $l) printf('<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>', esc_html($l['site']), esc_html($l['mail']), $l['aktiv'] === null ? 'nicht prüfbar' : ($l['aktiv'] ? 'aktiv' : 'kein Abo'), esc_html(wp_date('d.m.Y H:i', $l['zeit'])));
    echo '</tbody></table></div>';
  });
});
