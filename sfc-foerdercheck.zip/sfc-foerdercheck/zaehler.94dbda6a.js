/* sENERGIEs Fördercheck: anonymer Nutzungszähler. Keine Cookies, kein Speicher im Browser, keine IP:
   jedes Ereignis wird höchstens einmal pro Seitenaufruf als reine Zahl an WordPress gemeldet. */
(function () {
  var Z = window.SFC_ZAEHLER; if (!Z || !Z.url) return;
  if (navigator.webdriver) return; // automatisierte Browser (Tests, Bots) zählen nicht
  var gemeldet = {};
  function melde(e) {
    if (gemeldet[e]) return; gemeldet[e] = 1;
    var u = Z.url + (Z.url.indexOf('?') < 0 ? '?' : '&') + 'e=' + e;
    try { if (navigator.sendBeacon && navigator.sendBeacon(u)) return; } catch (x) {}
    try { fetch(u, { method: 'POST', keepalive: true }); } catch (x) {}
  }
  // Für andere Formulare (z. B. Angebotscheck): window.sfcZaehle('ac_…')
  window.sfcZaehle = melde;
  // Seitenaufruf mit grober Herkunft (nur Kategorie, keine Adresse): utm_source oder Referrer-Domain
  function quelle() {
    var m = /[?&]utm_source=([^&#]+)/i.exec(location.search), r = '';
    if (m) r = decodeURIComponent(m[1]).toLowerCase();
    else { try { r = document.referrer ? new URL(document.referrer).hostname.toLowerCase() : ''; } catch (x) {} }
    if (!r) return 'direkt';
    if (r === location.hostname) return 'intern';
    if (/instagram|^ig$/.test(r)) return 'instagram';
    if (/facebook|^fb$|fb\.com|fb\.me/.test(r)) return 'facebook';
    if (/whatsapp|wa\.me/.test(r)) return 'whatsapp';
    if (/google/.test(r)) return 'google';
    if (/bing|duckduckgo|ecosia|yahoo|qwant|startpage/.test(r)) return 'suche';
    if (/linkedin|t\.co$|twitter|x\.com|pinterest|youtube|tiktok|threads/.test(r)) return 'social';
    return 'andere';
  }
  function seite() {
    if (!Z.id) return;
    var u = Z.url + (Z.url.indexOf('?') < 0 ? '?' : '&') + 'e=seite&id=' + Z.id + '&q=' + quelle();
    try { if (navigator.sendBeacon && navigator.sendBeacon(u)) return; } catch (x) {}
    try { fetch(u, { method: 'POST', keepalive: true }); } catch (x) {}
  }
  function start() {
    seite();
    if (document.getElementById('sac')) melde('ac_aufruf');
    var box = document.querySelector('.sfc'); if (!box) return;
    melde('aufruf');
    // erste Eingabe im Rechner
    box.addEventListener('click', function (ev) {
      var t = ev.target.closest ? ev.target.closest('button,a') : null; if (!t) return;
      if (t.closest('.sfk .tiles, .sfk .chips')) melde('start');
      if (t.closest('.sfk .buch')) melde('buch');
      if (t.closest('.sfk .ad a, [data-sfc-partner]')) melde('partner');
      if (t.id === 'sfk-adBtn') melde('partner_interesse');
    }, true);
    box.addEventListener('input', function () { melde('start'); }, true);
    // Ergebnis erreicht (Kachel-Ansicht zeigt „fertig“), Anfrage gesendet, PDF erstellt
    var schritt = document.getElementById('sfk-stepN'), ok = document.getElementById('leadOk');
    new MutationObserver(function () {
      if (schritt && schritt.textContent === 'fertig') melde('ergebnis');
      if (ok && !ok.hidden) melde('anfrage');
      if (document.documentElement.classList.contains('sfc-printing')) melde('pdf');
    }).observe(document.documentElement, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ['hidden', 'class'] });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
