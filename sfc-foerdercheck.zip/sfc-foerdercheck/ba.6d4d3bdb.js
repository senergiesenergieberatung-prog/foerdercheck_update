/* sENERGIEs Online-Bedarfsausweis: Vorab-Prüfung, Bestellung, Weiter zu Stripe. Die Hausdaten erfasst der Kunde danach über den Link aus arbeitsTAKT. */
(function () {
  const C = Object.assign({ endpoint: '', gutschein: '', zahlung: '', zahlungslink: '', preis: '279 €', maxwe: 2, maxwfl: 200, vorschau: false, bild: '', datenschutz: '/datenschutzerklaerung/' }, window.SBA_CFG || {});
  const $ = id => document.getElementById('sba-' + id);
  const q = (s, r = document) => r.querySelector(s);
  if (!$('f')) return;
  const val = id => ($(id).value || '').trim();
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const eur = s => parseFloat(String(s).replace(/[^\d,]/g, '').replace(',', '.')) || 0;
  const geld = n => (Math.round(n * 100) % 100 ? n.toFixed(2) : String(Math.round(n))).replace('.', ',');
  const mailOk = s => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(s);
  let step = 1;

  if (C.vorschau) $('tag').hidden = false;
  if (C.bild) q('#sba .sea-kopf').style.backgroundImage = `linear-gradient(rgba(44,41,39,.78),rgba(44,41,39,.78)),url("${C.bild}")`;
  $('dslink').href = C.datenschutz;
  $('preis').textContent = C.preis;

  // Kacheln: Knopf setzt den Wert des versteckten Felds
  const chipsSync = () => document.querySelectorAll('#sba .sea-chips').forEach(g => g.querySelectorAll('button').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.v === document.getElementById(g.dataset.for).value))));
  $('f').addEventListener('click', ev => {
    const b = ev.target.closest('.sea-chips button'); if (!b) return;
    document.getElementById(b.parentElement.dataset.for).value = b.dataset.v;
    chipsSync(); b.parentElement.closest('.sea-err')?.classList.remove('sea-err'); vorab();
  });
  chipsSync();
  function markiere(sec, liste) {
    sec.querySelectorAll('.sea-err').forEach(x => x.classList.remove('sea-err'));
    const els = liste.filter(Boolean).map(x => typeof x === 'string' ? $(x) : x).map(x => x.type === 'checkbox' ? x.closest('label') : x.type === 'hidden' ? x.closest('.sea-frage') : x);
    els.forEach(x => x.classList.add('sea-err'));
    if (els[0]) { const t = els[0].getBoundingClientRect().top + scrollY - 120; if (t < scrollY) scrollTo({ top: t }); }
    return !els.length;
  }
  ['input', 'change'].forEach(e => $('f').addEventListener(e, ev => { const x = ev.target; x.classList.remove('sea-err'); x.closest('.sea-err')?.classList.remove('sea-err'); }, true));

  // ---------- Schritt 1: passt es? ----------
  const kontakt = 'Schreiben Sie mir kurz an <a href="mailto:info@s-energies.de?subject=Bedarfsausweis">info@s-energies.de</a>, dann mache ich Ihnen ein passendes Angebot.';
  function vorab() {
    const u = $('urteil'), we = +val('we') || 0, wfl = +val('wfl') || 0, art = val('art'), mass = val('mass');
    let t = '', ok = true;
    if (art === 'nwg') { ok = false; t = '<b>Für Nichtwohngebäude kann ich leider keinen Ausweis ausstellen.</b> Bitte wenden Sie sich an einen Energieberater aus der <a href="https://www.energie-effizienz-experten.de/" target="_blank" rel="noopener">Energieeffizienz-Expertenliste</a>.'; }
    else if (we > C.maxwe || wfl > C.maxwfl) { ok = false; t = `<b>Der Online-Preis gilt für Häuser mit bis zu ${C.maxwe} Wohnungen und ${C.maxwfl} m² Wohnfläche.</b> Für größere Häuser geht es auch, nur nicht über diese Seite. ` + kontakt; }
    else if (mass === '0') t = '<b>Kein Problem.</b> Sie können auch mit ungefähren Maßen beginnen. Was fehlt, klären wir gemeinsam in einem kurzen Video-Termin, ohne Aufpreis.';
    else if (art && val('anlass') && we && wfl && mass) t = '<b>Passt.</b> Ihr Haus lässt sich online erfassen.';
    u.innerHTML = t; u.hidden = !t;
    return ok;
  }
  ['we', 'wfl'].forEach(id => $(id).addEventListener('input', () => vorab()));
  function check1() {
    const ok = markiere(q('section[data-step="1"]'), [!val('art') && 'art', !val('anlass') && 'anlass', !(+val('we') > 0) && 'we', !(+val('wfl') >= 20) && 'wfl', !val('mass') && 'mass']);
    $('msg1').textContent = ok ? '' : 'Bitte alle Fragen beantworten.';
    return vorab() && ok;
  }
  function check2() {
    const bj = +val('bj');
    const ok = markiere(q('section[data-step="2"]'), [!val('str') && 'str', !val('hnr') && 'hnr', !/^\d{5}$/.test(val('plz')) && 'plz', !val('ort') && 'ort', !(bj >= 1700 && bj <= new Date().getFullYear() + 1) && 'bj']);
    $('msg2').textContent = ok ? '' : 'Bitte die markierten Felder ausfüllen.';
    return ok;
  }
  function check3() {
    const anders = $('andere').checked;
    const ok = markiere(q('section[data-step="3"]'), [!val('nachname') && 'nachname', !mailOk(val('email')) && 'email', !val('tel') && 'tel',
      anders && !val('kstr') && 'kstr', anders && !val('kplz') && 'kplz', anders && !val('kort') && 'kort',
      !$('wahr').checked && 'wahr', !$('ds').checked && 'ds', !$('widerruf').checked && 'widerruf']);
    $('msg3').textContent = ok ? '' : 'Bitte die markierten Felder ausfüllen und die Häkchen setzen.';
    return ok;
  }
  $('andere').addEventListener('change', () => { $('kadr').hidden = !$('andere').checked; });

  function daten() {
    const anders = $('andere').checked;
    return {
      gebaeude: { strasse: val('str'), hausnummer: val('hnr'), plz: val('plz'), ort: val('ort'), baujahr: val('bj'), we: val('we'), wohnflaeche: val('wfl'), anlass: val('anlass'), masse: val('mass') === '1' ? 'ja' : 'eher nicht' },
      kunde: { anrede: $('anrede').value, vorname: val('vorname'), nachname: val('nachname'), email: val('email'), telefon: val('tel'),
        strasse: anders ? val('kstr') : val('str'), hausnummer: anders ? val('khnr') : val('hnr'), plz: anders ? val('kplz') : val('plz'), ort: anders ? val('kort') : val('ort') },
      anmerkung: val('anm'), website: val('hp'),
    };
  }
  function uebersicht() {
    const d = daten(), g = d.gebaeude, k = d.kunde;
    const z = [['Gebäude', `${g.strasse} ${g.hausnummer}, ${g.plz} ${g.ort}`], ['Baujahr', g.baujahr], ['Wohnungen / Wohnfläche', `${g.we} / ca. ${g.wohnflaeche} m²`], ['Anlass', g.anlass],
      ['Name', [k.anrede, k.vorname, k.nachname].filter(Boolean).join(' ')], ['E-Mail', k.email], ['Telefon', k.telefon]];
    if ($('andere').checked) z.push(['Ihre Anschrift', `${k.strasse} ${k.hausnummer}, ${k.plz} ${k.ort}`]);
    if (d.anmerkung) z.push(['Anmerkung', d.anmerkung]);
    $('sum').innerHTML = z.map(([a, b]) => `<dt>${esc(a)}</dt><dd>${esc(b)}</dd>`).join('');
  }

  // ---------- Gutschein (Stripe-Rabattcode vorab prüfen, abgezogen wird bei Stripe) ----------
  let gc = null, gcTimer = 0;
  function preisZeigen() {
    const p = eur(C.preis), info = $('gc-info');
    if (gc && gc.status === 'ok' && gc.ba) {
      const neu = Math.max(0, gc.prozent ? p * (1 - gc.prozent / 100) : p - gc.betrag / 100);
      $('preis').innerHTML = `<s>${esc(C.preis)}</s>${geld(neu)} €`;
      info.className = 'sea-gc-info ok'; info.textContent = `Code ${gc.code} gilt: ${gc.prozent ? geld(gc.prozent) + ' %' : geld(gc.betrag / 100) + ' €'} Rabatt. Abgezogen wird er auf der Zahlungsseite.`;
    } else {
      $('preis').textContent = C.preis;
      info.className = 'sea-gc-info' + (gc && gc.status !== 'unbekannt' ? ' no' : '');
      info.textContent = !gc ? '' : gc.status === 'unbekannt' ? 'Der Code wird auf der Zahlungsseite geprüft.' : gc.status === 'ok' ? 'Dieser Code gilt nicht für den Bedarfsausweis.' : 'Diesen Code kennen wir nicht. Bitte Schreibweise prüfen.';
    }
  }
  async function gutscheinPruefen() {
    const code = val('gutschein').replace(/\s+/g, '').toUpperCase();
    if (!code) { gc = null; return preisZeigen(); }
    if (!C.gutschein) { gc = { status: 'unbekannt' }; return preisZeigen(); }
    let r = null;
    try { const a = await fetch(C.gutschein + (C.gutschein.includes('?') ? '&' : '?') + 'code=' + encodeURIComponent(code)); r = a.ok ? await a.json() : null; } catch (e) {}
    gc = r && r.status ? r : { status: 'unbekannt' }; preisZeigen();
  }
  $('gutschein').addEventListener('input', () => { clearTimeout(gcTimer); gc = null; preisZeigen(); gcTimer = setTimeout(gutscheinPruefen, 1500); });
  $('gutschein').addEventListener('change', () => { clearTimeout(gcTimer); gutscheinPruefen(); });

  // ---------- Bestellen: Auftrag speichern, dann zu Stripe ----------
  $('pay').addEventListener('click', async () => {
    const m = $('msg4');
    if (!C.endpoint) { m.className = 'sea-msg gut'; m.textContent = 'Vorschau: Hier geht es im Live-Betrieb zur Zahlung.'; return; }
    $('pay').disabled = true; m.className = 'sea-msg gut'; m.textContent = 'Bestellung wird übertragen …';
    try {
      const r = await fetch(C.endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(daten()) });
      const j = await r.json();
      if (!r.ok || !j.ok) throw new Error(j.fehler || '');
      const z = C.zahlungslink;
      if (!z) throw new Error('Die Zahlung ist gerade nicht erreichbar.');
      m.textContent = 'Weiter zur Zahlung …';
      location.href = z + (z.includes('?') ? '&' : '?') + 'client_reference_id=' + encodeURIComponent(j.id) + '&prefilled_email=' + encodeURIComponent(val('email'))
        + (val('gutschein') && !(gc && gc.status === 'ungueltig') ? '&prefilled_promo_code=' + encodeURIComponent(val('gutschein').replace(/\s+/g, '').toUpperCase()) : '');
    } catch (e) { m.className = 'sea-msg'; m.textContent = (e.message || 'Die Übertragung hat nicht geklappt.') + ' Bitte versuchen Sie es noch einmal oder schreiben Sie an info@s-energies.de.'; $('pay').disabled = false; }
  });

  // ---------- Navigation ----------
  function show(n) {
    step = n;
    document.querySelectorAll('#sba [data-step]').forEach(s => s.hidden = +s.dataset.step !== n);
    document.querySelectorAll('#sba-steps li').forEach((li, i) => li.classList.toggle('on', i < n));
    if (n === 4) uebersicht();
    const top = $('f').getBoundingClientRect().top + scrollY - 90; if (scrollY > top) scrollTo({ top });
  }
  $('f').addEventListener('click', ev => {
    const t = ev.target;
    if (t.matches('[data-back]')) show(step - 1);
    if (t.matches('[data-next]')) {
      if (step === 1 && !check1()) return;
      if (step === 2 && !check2()) return;
      if (step === 3 && !check3()) return;
      show(step + 1);
    }
  });
  { const u = new URLSearchParams(location.search), c = u.get('code'); if (c && /^[A-Za-z0-9_-]{2,40}$/.test(c)) { $('gutschein').value = c.toUpperCase(); gutscheinPruefen(); } }
  // ---------- Rückkehr von Stripe: Dankeseite und sofortige Zahlungsprüfung ----------
  { const u = new URLSearchParams(location.search);
    if (u.has('danke')) {
      document.querySelectorAll('#sba [data-step]').forEach(s => s.hidden = s.dataset.step !== '5');
      document.querySelectorAll('#sba-steps li').forEach(li => li.classList.add('on'));
      const sid = u.get('session_id') || '';
      if (C.zahlung && /^cs_(live|test)_[A-Za-z0-9]+$/.test(sid)) fetch(C.zahlung + (C.zahlung.includes('?') ? '&' : '?') + 'sid=' + encodeURIComponent(sid)).catch(() => {});
    } }
})();
