<?php
// Online-Verbrauchsausweis: Shortcode [sfc_energieausweis], Auftragsannahme mit .evea-Datei für EVEBI, danach weiter zum Stripe-Zahlungslink.
// Attribute: partnerlink="…" (Vermittlung für Bedarfsausweise außerhalb der Region, sonst Expertenliste), zahlungslink="https://buy.stripe.com/…" (Auftragsnummer geht als client_reference_id mit), preis="59 €", zahlungslink_express="…", preis_express="79 €" (24-h-Express, Knopf nur sichtbar, wenn beide Links gesetzt), vorschau="1" (zeigt CSV und Testdaten).
if (!defined('ABSPATH')) exit;
require_once __DIR__ . '/evea.php';

// Spalten wie in der Envisys-Musterdatei EA_Verbrauch_WG plus Kundendaten aus der EVEBI-Schnittstellenbeschreibung
const SFC_EA_SPALTEN = ['BOM', 'ID', 'Anlass', 'PLZ', 'Ort', 'Straße', 'Hausnr', 'isGebaeudehuelle', 'Baujahr', 'Wohneinheiten', 'Wohnfläche', 'gebaeudeteil', 'Keller_beheizt', 'bilderStreams_0', 'bilderStreams_1', 'bilderStreams_2', 'Klimatisiert', 'kuehlWfl', 'passiveKuehlung', 'fernKuehlung', 'stromKuehlung', 'waermeKuehlung', 'kaiAnzahl', 'kaiDatum', 'baujahrHzErz', 'TW_Solar', 'HZ_Solar', 'TW_WP', 'HZ_WP', 'Fensterlüftung', 'Schachtlüftung', 'L_Mit_WRG', 'L_Ohne_WRG', 'Modernisierung', 'Dach1_Dämmung', 'Wand1_Dämmung', 'Boden1_Dämmung', 'bjFensterAustausch', 'ETr1_Kategorie', 'ETr1_Anteil_erneuerbar', 'ETr1_Anteil_KWK', 'ETr1_isFw', 'ETr1_gebaeudeNahErzeugt', 'ETr1_Jahr1_von', 'ETr1_Jahr1_bis', 'ETr1_Jahr1_Menge', 'ETr1_TWW', 'ETr1_Jahr1_Menge_TWW', 'ETr1_Jahr1_Leerstand', 'ETr1_Jahr2_von', 'ETr1_Jahr2_bis', 'ETr1_Jahr2_Menge', 'ETr1_Jahr2_Menge_TWW', 'ETr1_Jahr2_Leerstand', 'ETr1_Jahr3_von', 'ETr1_Jahr3_bis', 'ETr1_Jahr3_Menge', 'ETr1_Jahr3_Menge_TWW', 'ETr1_Jahr3_Leerstand', 'ETr1_PrimFaktor', 'ETr2_Kategorie', 'ETr2_Jahr1_von', 'ETr2_Jahr1_bis', 'ETr2_Jahr1_Menge', 'ETr2_TWW', 'ETr2_Jahr1_Menge_TWW', 'ETr2_Jahr1_Leerstand', 'ETr2_Jahr2_von', 'ETr2_Jahr2_bis', 'ETr2_Jahr2_Menge', 'ETr2_Jahr2_Menge_TWW', 'ETr2_Jahr2_Leerstand', 'ETr2_Jahr3_von', 'ETr2_Jahr3_bis', 'ETr2_Jahr3_Menge', 'ETr2_Jahr3_Menge_TWW', 'ETr2_Jahr3_Leerstand', 'ETr1_Heizung', 'ETr2_Heizung', 'ETr2_PrimFaktor', 'Gebäudetyp', 'Datenerhebung', 'BedarfVerbrauch', 'ETr2_Anteil_KWK', 'ETr2_Anteil_erneuerbar', 'ETr2_isFw', 'ETr2_gebaeudeNahErzeugt', 'Kunden_Anrede', 'Kunden_Vorname', 'Kunden_Nachname', 'Kunden_Straße', 'Kunden_Hausnr', 'Kunden_PLZ', 'Kunden_Ort', 'Kunden_email', 'Kunden_telefon'];

add_action('init', function () {
  register_post_type('sfc_ea_auftrag', [
    'label' => 'Energieausweis-Aufträge', 'labels' => ['singular_name' => 'Energieausweis-Auftrag'],
    'public' => false, 'show_ui' => true, 'show_in_menu' => 'edit.php?post_type=sfc_anfrage',
    'supports' => ['title', 'editor'], 'capability_type' => 'post',
    'capabilities' => ['create_posts' => 'do_not_allow'], 'map_meta_cap' => true,
  ]);
});

add_shortcode('sfc_energieausweis', function ($atts = []) {
  $a = shortcode_atts(['zahlungslink' => 'https://buy.stripe.com/eVq00ld8KcWLbiz4wH9Zm02', 'partnerlink' => '', 'preis' => '59 €', 'zahlungslink_express' => 'https://buy.stripe.com/00w14pgkW8Gvaev9R19Zm03', 'preis_express' => '79 €', 'vorschau' => '0', 'bild' => content_url('uploads/2025/11/Welt_Beleuchtet.webp')], $atts);
  $dir = plugin_dir_path(__FILE__); $url = plugin_dir_url(__FILE__);
  wp_enqueue_style('sfc-ea', $url . sfc_datei($dir, 'ea.css'), [], null);
  wp_enqueue_script('sfc-ea', $url . sfc_datei($dir, 'ea.js'), [], null, ['in_footer' => true, 'strategy' => 'defer']);
  wp_add_inline_script('sfc-ea', 'window.SEA_CFG=' . wp_json_encode([
    'endpoint' => rest_url('sfc/v1/energieausweis'), 'adresse' => rest_url('sfc/v1/adresse'), 'gutschein' => rest_url('sfc/v1/gutschein'), 'anfrage' => rest_url('sfc/v1/anfrage'), 'zahlungslink' => esc_url_raw($a['zahlungslink']), 'zahlungslink_express' => esc_url_raw($a['zahlungslink_express']), 'preis_express' => $a['preis_express'], 'partnerlink' => esc_url_raw($a['partnerlink']),
    'preis' => $a['preis'], 'preview' => $a['vorschau'] === '1', 'bild' => esc_url_raw($a['bild']),
    'datenschutz' => get_privacy_policy_url() ?: home_url('/datenschutzerklaerung/')]) . ';', 'before');
  return str_replace('class="sea"', 'class="sea sea-wp"', file_get_contents($dir . 'ea.html'));
});

add_action('rest_api_init', function () {
  register_rest_route('sfc/v1', '/energieausweis', ['methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => 'sfc_ea_auftrag']);
  register_rest_route('sfc/v1', '/adresse', ['methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => 'sfc_ea_adresse']);
  register_rest_route('sfc/v1', '/gutschein', ['methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => 'sfc_ea_gutschein']);
});

// ---------- Gutscheincode vorab prüfen, damit der Kunde den reduzierten Preis vor der Bestellung sieht ----------
// Liest Stripe-Rabattcodes mit dem eingeschränkten Schlüssel (Recht „Coupons: Lesen“). Abgezogen wird der Rabatt trotzdem erst von Stripe.
const SFC_EA_PRODUKTE = ['normal' => 'prod_VXqAsgiJLWRlLo', 'express' => 'prod_VXqIdjKeL11aLi'];
function sfc_ea_gutschein(WP_REST_Request $r) {
  $code = strtoupper(preg_replace('/[^A-Za-z0-9_-]/', '', (string) $r->get_param('code')));
  if (strlen($code) < 2 || strlen($code) > 40) return new WP_REST_Response(['status' => 'ungueltig'], 200);
  $cache = 'sfc_ea_gc_' . md5($code);
  if (($c = get_transient($cache)) !== false) return new WP_REST_Response($c, 200);
  $key = 'sfc_ea_gcl_' . md5($_SERVER['REMOTE_ADDR'] ?? '');
  $n = (int) get_transient($key);
  if ($n >= 30) return new WP_REST_Response(['status' => 'unbekannt'], 200);
  set_transient($key, $n + 1, HOUR_IN_SECONDS);
  $unbekannt = new WP_REST_Response(['status' => 'unbekannt'], 200);
  if (!function_exists('sfc_liz_stripe')) return $unbekannt;
  $l = sfc_liz_stripe('promotion_codes', ['code' => $code, 'active' => 'true', 'limit' => 1]);
  if ($l === null) return $unbekannt;
  $erg = ['status' => 'ungueltig'];
  $pc = $l['data'][0] ?? null;
  if ($pc && strcasecmp($pc['code'] ?? '', $code) === 0
      && (empty($pc['expires_at']) || $pc['expires_at'] > time())
      && (empty($pc['max_redemptions']) || ($pc['times_redeemed'] ?? 0) < $pc['max_redemptions'])) {
    $cid = $pc['promotion']['coupon'] ?? $pc['coupon'] ?? '';
    if (is_array($cid)) $cid = $cid['id'] ?? '';
    $cp = $cid ? sfc_liz_stripe('coupons/' . rawurlencode($cid), ['expand' => ['applies_to']]) : null;
    if ($cp === null) return $unbekannt;
    if (!empty($cp['valid']) && (empty($cp['amount_off']) || strtolower($cp['currency'] ?? '') === 'eur')) {
      $prod = $cp['applies_to']['products'] ?? [];
      $erg = ['status' => 'ok', 'code' => $pc['code'], 'betrag' => (int) ($cp['amount_off'] ?? 0), 'prozent' => (float) ($cp['percent_off'] ?? 0),
        'normal' => !$prod || in_array(SFC_EA_PRODUKTE['normal'], $prod, true), 'express' => !$prod || in_array(SFC_EA_PRODUKTE['express'], $prod, true)];
    }
  }
  set_transient($cache, $erg, 10 * MINUTE_IN_SECONDS);
  return new WP_REST_Response($erg, 200);
}

// Wert für die CSV: keine Trennzeichen, keine Formeln (Excel)
function sfc_ea_wert($v) {
  $v = trim(preg_replace('/[;"\r\n\t]+/', ' ', sanitize_text_field((string) $v)));
  return mb_substr(ltrim($v, '=+@'), 0, 120);
}

// Ablage für Fotos und CSV, von außen gesperrt
function sfc_ea_ordner() {
  $u = wp_upload_dir();
  $d = trailingslashit($u['basedir']) . 'sfc-ea-' . substr(wp_hash('sfc-ea'), 0, 12);
  if (!is_dir($d)) {
    wp_mkdir_p($d);
    file_put_contents("$d/.htaccess", "Require all denied\nDeny from all\n");
    file_put_contents("$d/index.php", '<?php // leer');
  }
  return $d;
}

function sfc_ea_auftrag(WP_REST_Request $r) {
  $d = json_decode((string) $r->get_param('daten'), true);
  if (!is_array($d) || !empty($d['website']) || !is_array($d['v'] ?? null)) return new WP_REST_Response(['ok' => false], 400);
  $v = array_merge(array_fill_keys(SFC_EA_SPALTEN, ''), array_map('sfc_ea_wert', array_intersect_key($d['v'], array_flip(SFC_EA_SPALTEN))));
  $mail = sanitize_email($d['v']['Kunden_email'] ?? '');
  if (!is_email($mail) || ($v['Kunden_Nachname'] ?? '') === '' || !preg_match('/^\d{5}$/', $v['PLZ'] ?? '') || ($v['ETr1_Jahr1_Menge'] ?? '') === '')
    return new WP_REST_Response(['ok' => false, 'fehler' => 'Es fehlen Angaben.'], 422);

  // max. 5 Aufträge pro IP und Stunde
  $key = 'sfc_ea_rl_' . md5($_SERVER['REMOTE_ADDR'] ?? '');
  $n = (int) get_transient($key);
  if ($n >= 5) return new WP_REST_Response(['ok' => false, 'fehler' => 'Zu viele Aufträge in kurzer Zeit.'], 429);
  set_transient($key, $n + 1, HOUR_IN_SECONDS);

  $titel = "{$v['Straße']} {$v['Hausnr']}, {$v['PLZ']} {$v['Ort']} – {$v['Kunden_Nachname']}";
  $pid = wp_insert_post(['post_type' => 'sfc_ea_auftrag', 'post_status' => 'private', 'post_title' => $titel]);
  if (!$pid || is_wp_error($pid)) return new WP_REST_Response(['ok' => false], 500);
  $id = 'VA' . wp_date('ymd') . '-' . $pid;
  $v['ID'] = $id;

  // Fotos prüfen und ablegen
  $ordner = sfc_ea_ordner(); $anh = [];
  $namen = ['ansicht', 'heizung', 'fenster'];
  foreach ([0, 1, 2] as $i) {
    $v["bilderStreams_$i"] = '';
    $f = $_FILES["foto$i"] ?? null;
    if (!$f || $f['error'] !== UPLOAD_ERR_OK || $f['size'] > 8 * MB_IN_BYTES) continue;
    $t = wp_check_filetype_and_ext($f['tmp_name'], $f['name'], ['jpg|jpeg' => 'image/jpeg', 'png' => 'image/png']);
    if (empty($t['ext']) || !@getimagesize($f['tmp_name'])) continue;
    $name = "{$id}_{$namen[$i]}." . ($t['ext'] === 'png' ? 'png' : 'jpg');
    if (move_uploaded_file($f['tmp_name'], "$ordner/$name")) { $anh[] = "$ordner/$name"; $v["bilderStreams_$i"] = $name; }
  }
  // Abrechnungen (Fotos oder PDF) nur als Mail-Anhang, nicht in die .evea
  $belege = [];
  for ($i = 0; $i < 5; $i++) {
    $f = $_FILES["beleg$i"] ?? null;
    if (!$f || $f['error'] !== UPLOAD_ERR_OK || $f['size'] > 8 * MB_IN_BYTES) continue;
    $t = wp_check_filetype_and_ext($f['tmp_name'], $f['name'], ['jpg|jpeg' => 'image/jpeg', 'png' => 'image/png', 'pdf' => 'application/pdf']);
    if (empty($t['ext'])) continue;
    if ($t['ext'] !== 'pdf' && !@getimagesize($f['tmp_name'])) continue;
    if ($t['ext'] === 'pdf' && file_get_contents($f['tmp_name'], false, null, 0, 5) !== '%PDF-') continue;
    $name = "{$id}_abrechnung" . ($i + 1) . '.' . ($t['ext'] === 'jpeg' ? 'jpg' : $t['ext']);
    if (move_uploaded_file($f['tmp_name'], "$ordner/$name")) $belege[] = "$ordner/$name";
  }

  $zeile = array_map(fn($h) => $v[$h] ?? '', SFC_EA_SPALTEN);
  $csv = "\xEF\xBB\xBF" . implode(';', SFC_EA_SPALTEN) . "\r\n" . implode(';', $zeile) . "\r\n";
  // EVEBI-Projektdatei aus der leeren Vorlage (Fotos werden eingebettet, Erläuterung als kurzer Empfehlungssatz)
  $evea = "$ordner/{$id}_" . sanitize_file_name("{$v['Straße']}_{$v['Hausnr']}") . '.evea';
  $fotos = array_values(array_filter($anh, fn($p) => strpos($p, '_ansicht.') !== false));
  $fotos = array_merge($fotos, array_values(array_diff($anh, $fotos)));
  if (class_exists('ZipArchive') && class_exists('DOMDocument') && sfc_ea_evea($v, $fotos, __DIR__ . '/vorlage-projekt.xml', $evea)) array_unshift($anh, $evea);
  else { file_put_contents("$ordner/$id.csv", $csv); array_unshift($anh, "$ordner/$id.csv"); }

  $zusatz = '';
  foreach ((array) ($d['zusatz'] ?? []) as $k => $w) $zusatz .= sanitize_text_field($k) . ': ' . sanitize_text_field($w) . "\n";
  $text = "Auftragsnummer: $id\nGebäude: $titel\nBaujahr / WE / Wohnfläche: {$v['Baujahr']} / {$v['Wohneinheiten']} / {$v['Wohnfläche']} m²\n"
    . "Kunde: {$v['Kunden_Vorname']} {$v['Kunden_Nachname']}, {$v['Kunden_Straße']} {$v['Kunden_Hausnr']}, {$v['Kunden_PLZ']} {$v['Kunden_Ort']}\nE-Mail: $mail\nTelefon: {$v['Kunden_telefon']}\n\n$zusatz";
  wp_update_post(['ID' => $pid, 'post_title' => "$id – $titel", 'post_content' => nl2br(esc_html($text)) . '<pre>' . esc_html(substr($csv, 3)) . '</pre>']);
  $anh = array_merge($anh, $belege);
  update_post_meta($pid, '_sfc_ea_dateien', $anh);

  // Mails gehen erst nach Zahlungseingang raus (sfc_ea_zahlungen_pruefen), bis dahin wartet der Auftrag
  update_post_meta($pid, '_sfc_ea_express', empty($d['express']) ? 0 : 1);
  update_post_meta($pid, '_sfc_ea_status', 'offen');
  update_post_meta($pid, '_sfc_ea_id', $id);
  update_post_meta($pid, '_sfc_ea_kunde', $mail);
  update_post_meta($pid, '_sfc_ea_nachname', $v['Kunden_Nachname']);
  update_post_meta($pid, '_sfc_ea_titel', $titel);
  update_post_meta($pid, '_sfc_ea_text', $text);
  wp_update_post(['ID' => $pid, 'post_title' => "[wartet auf Zahlung] $id – $titel"]);
  wp_schedule_single_event(time() + 120, 'sfc_ea_zahlungen'); // kurz nach der Zahlung einmal extra nachsehen
  return new WP_REST_Response(['ok' => true, 'id' => $id], 200);
}

// Autoptimize nicht an das Skript lassen (wie beim Rechner)

// Adressprüfung: fragt OpenStreetMap (Nominatim) vom Server aus, damit die IP des Besuchers nicht weitergeht. Nur Gebäudeadresse, keine Namen.
// Antwort: treffer = haus | strasse | plz | keiner, ort = Ort zur PLZ laut OSM. Ergebnisse 30 Tage zwischengespeichert, max. 30 Abfragen je IP und Stunde.
function sfc_ea_osm(array $p) {
  $url = add_query_arg(array_merge($p, ['country' => 'de', 'format' => 'jsonv2', 'addressdetails' => 1, 'limit' => 1]), 'https://nominatim.openstreetmap.org/search');
  $r = wp_remote_get($url, ['timeout' => 6, 'headers' => ['User-Agent' => 'sENERGIEs-Energieausweis/1.0 (' . SFC_EMPFAENGER . ')', 'Accept-Language' => 'de']]);
  if (is_wp_error($r) || wp_remote_retrieve_response_code($r) !== 200) return null;
  $j = json_decode(wp_remote_retrieve_body($r), true);
  return is_array($j) ? ($j[0] ?? false) : null;
}
function sfc_ea_adresse(WP_REST_Request $r) {
  // Prüft nur Postleitzahl und Ort (Straßen fehlen in kleinen Ortsteilen oft in der Karte, z. B. „Möchs“).
  $plz = preg_replace('/\D/', '', (string) $r->get_param('plz'));
  if (strlen($plz) !== 5) return new WP_REST_Response(['treffer' => 'keiner'], 200);
  $ortIn = sanitize_text_field((string) $r->get_param('ort'));
  $cache = 'sfc_ea_adr2_' . md5(strtolower("$plz|$ortIn"));
  if (($c = get_transient($cache)) !== false) return new WP_REST_Response($c, 200);
  $key = 'sfc_ea_adrl_' . md5($_SERVER['REMOTE_ADDR'] ?? '');
  $n = (int) get_transient($key);
  if ($n >= 30) return new WP_REST_Response(['treffer' => ''], 200);
  set_transient($key, $n + 1, HOUR_IN_SECONDS);
  $norm = function ($x) { return preg_replace('/[^a-z0-9äöü]/u', '', str_replace('ß', 'ss', mb_strtolower((string) $x))); };
  $p = sfc_ea_osm(['postalcode' => $plz]);
  if ($p === null) return new WP_REST_Response(['treffer' => ''], 200);
  if (!$p) { $erg = ['treffer' => 'keiner', 'ort' => '']; set_transient($cache, $erg, 30 * DAY_IN_SECONDS); return new WP_REST_Response($erg, 200); }
  $x = $p['address'] ?? [];
  $ort = $x['city'] ?? $x['town'] ?? $x['village'] ?? $x['municipality'] ?? '';
  $erg = ['treffer' => 'plz', 'ort' => $ort];
  if ($ortIn !== '') {
    $o = $norm($ortIn); $teile = [];
    foreach (explode(',', (string) ($p['display_name'] ?? '')) as $t) if (strpos($t, '(') === false) $teile[] = $norm($t);
    foreach (array_merge([$norm($ort)], $teile) as $t) if ($t !== '' && $o !== '' && (strpos($t, $o) !== false || strpos($o, $t) !== false) && !ctype_digit($t)) $erg['treffer'] = 'ort';
    if ($erg['treffer'] !== 'ort') {
      usleep(1100000); // Nominatim: höchstens eine Abfrage pro Sekunde
      $h = sfc_ea_osm(['postalcode' => $plz, 'city' => $ortIn]);
      if ($h === null) return new WP_REST_Response(['treffer' => ''], 200);
      if ($h && ($h['address']['postcode'] ?? '') === $plz) $erg['treffer'] = 'ort'; // Ortsteile wie „Möchs“
    }
  }
  set_transient($cache, $erg, 30 * DAY_IN_SECONDS);
  return new WP_REST_Response($erg, 200);
}

// ---------- Zahlung abwarten: Auftragsmail mit .evea erst, wenn Stripe die Zahlung bestätigt ----------
// Liest Checkout-Sitzungen mit dem eingeschränkten Stripe-Schlüssel (Einstellungen → Fördercheck-Lizenzen, Recht „Checkout Sessions: Lesen“)
// und ordnet sie über client_reference_id (= Auftragsnummer) zu. Läuft alle 5 Minuten über WP-Cron.
add_filter('cron_schedules', function ($s) { $s['sfc_5min'] = ['interval' => 300, 'display' => 'Alle 5 Minuten']; return $s; });
add_action('init', function () { if (!wp_next_scheduled('sfc_ea_zahlungen')) wp_schedule_event(time() + 60, 'sfc_5min', 'sfc_ea_zahlungen'); });
add_action('sfc_ea_zahlungen', 'sfc_ea_zahlungen_pruefen');

function sfc_ea_zahlungen_pruefen() {
  if (get_transient('sfc_ea_zp_lauf')) return;
  set_transient('sfc_ea_zp_lauf', 1, 120);
  $offen = get_posts(['post_type' => 'sfc_ea_auftrag', 'post_status' => 'private', 'numberposts' => 50, 'meta_key' => '_sfc_ea_status', 'meta_value' => 'offen']);
  if (!$offen) { delete_transient('sfc_ea_zp_lauf'); return; }
  $nach = [];
  $alt = time();
  foreach ($offen as $p) { $nach[get_post_meta($p->ID, '_sfc_ea_id', true)] = $p; $alt = min($alt, strtotime($p->post_date_gmt . ' UTC')); }
  $sitzungen = []; $start = null; $fehler = false;
  for ($seite = 0; $seite < 5; $seite++) {
    $q = ['limit' => 100, 'created' => ['gte' => $alt - 3600]];
    if ($start) $q['starting_after'] = $start;
    $j = function_exists('sfc_liz_stripe') ? sfc_liz_stripe('checkout/sessions', $q) : null;
    if ($j === null) { $fehler = true; break; }
    $sitzungen = array_merge($sitzungen, $j['data'] ?? []);
    if (empty($j['has_more']) || empty($j['data'])) break;
    $start = end($j['data'])['id'];
  }
  foreach ($sitzungen as $s) {
    $ref = $s['client_reference_id'] ?? '';
    if (!isset($nach[$ref]) || !in_array($s['payment_status'] ?? '', ['paid', 'no_payment_required'], true)) continue;
    sfc_ea_versand($nach[$ref]->ID, $s);
    unset($nach[$ref]);
  }
  // Fehler melden (höchstens einmal am Tag), damit kein bezahlter Auftrag unbemerkt liegen bleibt
  if ($fehler && !get_transient('sfc_ea_zp_warnung')) {
    set_transient('sfc_ea_zp_warnung', 1, DAY_IN_SECONDS);
    wp_mail(SFC_EMPFAENGER, 'Energieausweis: Zahlungsprüfung bei Stripe nicht möglich',
      "Die Website kann gerade nicht bei Stripe nachsehen, ob Energieausweis-Aufträge bezahlt sind. Wartende Aufträge: " . implode(', ', array_keys($nach)) . ".\n\n"
      . "Bitte prüfen: Ist unter Einstellungen → Fördercheck-Lizenzen der Stripe-Schlüssel eingetragen, und hat er das Recht „Checkout Sessions: Lesen“?\nDie Aufträge stehen im WordPress-Menü unter Energieausweis-Aufträge.");
  }
  // unbezahlte Aufträge nach 7 Tagen verwerfen (Fotos und Abrechnungen löschen), aber nur wenn Stripe sicher geantwortet hat
  if (!$fehler) foreach ($nach as $p) {
    if (time() - strtotime($p->post_date_gmt . ' UTC') < 7 * DAY_IN_SECONDS) continue;
    foreach ((array) get_post_meta($p->ID, '_sfc_ea_dateien', true) as $datei) if (is_string($datei) && is_file($datei)) @unlink($datei);
    update_post_meta($p->ID, '_sfc_ea_status', 'verfallen');
    wp_update_post(['ID' => $p->ID, 'post_title' => str_replace('[wartet auf Zahlung]', '[nicht bezahlt, Dateien gelöscht]', $p->post_title)]);
  }
  delete_transient('sfc_ea_zp_lauf');
}

function sfc_ea_versand($pid, array $s) {
  if (get_post_meta($pid, '_sfc_ea_status', true) !== 'offen') return;
  update_post_meta($pid, '_sfc_ea_status', 'bezahlt');
  update_post_meta($pid, '_sfc_ea_stripe', $s['id'] ?? '');
  $id = get_post_meta($pid, '_sfc_ea_id', true); $titel = get_post_meta($pid, '_sfc_ea_titel', true); $text = get_post_meta($pid, '_sfc_ea_text', true);
  $mail = get_post_meta($pid, '_sfc_ea_kunde', true); $name = get_post_meta($pid, '_sfc_ea_nachname', true);
  $express = (bool) get_post_meta($pid, '_sfc_ea_express', true);
  $netto = (int) ($s['amount_subtotal'] ?? 0); $gezahlt = (int) ($s['amount_total'] ?? 0);
  $betrag = number_format($gezahlt / 100, 2, ',', '.') . ' €';
  $warn = $express && $netto > 0 && $netto < 7900 ? "\nACHTUNG: Express gewählt, aber der normale Preis bezahlt. Bitte normal liefern oder nachfragen.\n" : '';
  $anh = array_values(array_filter((array) get_post_meta($pid, '_sfc_ea_dateien', true), 'is_file'));
  wp_update_post(['ID' => $pid, 'post_title' => str_replace('[wartet auf Zahlung]', '[bezahlt]', get_the_title($pid))]);
  wp_mail(SFC_EMPFAENGER, ($express ? 'EXPRESS 24 h – ' : '') . "Energieausweis-Auftrag $id: $titel (bezahlt)",
    "Neuer bezahlter Auftrag für einen Verbrauchsausweis.\nBezahlt: $betrag (Stripe " . ($s['id'] ?? '') . ")\n$warn\n$text\nDie .evea-Datei im Anhang in EVEBI öffnen (Fotos und Erläuterung sind enthalten), rechnen lassen und mit den angehängten Abrechnungen abgleichen.\n",
    ["Reply-To: $name <$mail>"], $anh);
  wp_mail($mail, "Ihr Energieausweis-Auftrag $id",
    "Guten Tag,\n\nvielen Dank für Ihren Auftrag und Ihre Zahlung für einen Verbrauchsausweis für $titel.\n\nIch prüfe jetzt Ihre Angaben und melde mich bei Rückfragen. Den fertigen Ausweis erhalten Sie als PDF per E-Mail, " . ($express ? 'innerhalb von 24 Stunden an Werktagen (Express).' : 'in der Regel innerhalb von 3 Werktagen.') . "\n\n"
    . "Mit freundlichen Grüßen\nStephan Hecky\nsENERGIEs Energieberatung\nMöchs 33, 91355 Hiltpoltstein · Tel. +49 155 65134339 · info@s-energies.de", ['Reply-To: sENERGIEs Energieberatung <' . SFC_EMPFAENGER . '>']);
}
