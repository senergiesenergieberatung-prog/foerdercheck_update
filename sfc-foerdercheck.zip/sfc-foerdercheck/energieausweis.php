<?php
// Online-Verbrauchsausweis: Shortcode [sfc_energieausweis], Auftragsannahme mit .evea-Datei für EVEBI, danach weiter zum Stripe-Zahlungslink.
// Attribute: partnerlink="…" (Vermittlung für Bedarfsausweise außerhalb der Region, sonst Expertenliste), zahlungslink="https://buy.stripe.com/…" (Auftragsnummer geht als client_reference_id mit), preis="59 €", zahlungslink_express="…", preis_express="79 €" (24-h-Express, Knopf nur sichtbar, wenn beide Links gesetzt), vorschau="1" (zeigt CSV und Testdaten).
if (!defined('ABSPATH')) exit;
require_once __DIR__ . '/evea.php';

// Spalten wie in der Envisys-Musterdatei EA_Verbrauch_WG plus Kundendaten aus der EVEBI-Schnittstellenbeschreibung
const SFC_EA_SPALTEN = ['BOM', 'ID', 'Anlass', 'PLZ', 'Ort', 'Straße', 'Hausnr', 'isGebaeudehuelle', 'Baujahr', 'Wohneinheiten', 'Wohnfläche', 'gebaeudeteil', 'Keller_beheizt', 'bilderStreams_0', 'bilderStreams_1', 'bilderStreams_2', 'Klimatisiert', 'kuehlWfl', 'passiveKuehlung', 'fernKuehlung', 'stromKuehlung', 'waermeKuehlung', 'kaiAnzahl', 'kaiDatum', 'baujahrHzErz', 'TW_Solar', 'HZ_Solar', 'TW_WP', 'HZ_WP', 'Fensterlüftung', 'Schachtlüftung', 'L_Mit_WRG', 'L_Ohne_WRG', 'Modernisierung', 'Dach1_Dämmung', 'Wand1_Dämmung', 'Boden1_Dämmung', 'bjFensterAustausch', 'ETr1_Kategorie', 'ETr1_Anteil_erneuerbar', 'ETr1_Anteil_KWK', 'ETr1_isFw', 'ETr1_gebaeudeNahErzeugt', 'ETr1_Jahr1_von', 'ETr1_Jahr1_bis', 'ETr1_Jahr1_Menge', 'ETr1_TWW', 'ETr1_Jahr1_Menge_TWW', 'ETr1_Jahr1_Leerstand', 'ETr1_Jahr2_von', 'ETr1_Jahr2_bis', 'ETr1_Jahr2_Menge', 'ETr1_Jahr2_Menge_TWW', 'ETr1_Jahr2_Leerstand', 'ETr1_Jahr3_von', 'ETr1_Jahr3_bis', 'ETr1_Jahr3_Menge', 'ETr1_Jahr3_Menge_TWW', 'ETr1_Jahr3_Leerstand', 'ETr1_PrimFaktor', 'ETr2_Kategorie', 'ETr2_Jahr1_von', 'ETr2_Jahr1_bis', 'ETr2_Jahr1_Menge', 'ETr2_TWW', 'ETr2_Jahr1_Menge_TWW', 'ETr2_Jahr1_Leerstand', 'ETr2_Jahr2_von', 'ETr2_Jahr2_bis', 'ETr2_Jahr2_Menge', 'ETr2_Jahr2_Menge_TWW', 'ETr2_Jahr2_Leerstand', 'ETr2_Jahr3_von', 'ETr2_Jahr3_bis', 'ETr2_Jahr3_Menge', 'ETr2_Jahr3_Menge_TWW', 'ETr2_Jahr3_Leerstand', 'ETr1_Heizung', 'ETr2_Heizung', 'ETr2_PrimFaktor', 'Gebäudetyp', 'Datenerhebung', 'BedarfVerbrauch', 'ETr2_Anteil_KWK', 'ETr2_Anteil_erneuerbar', 'ETr2_isFw', 'ETr2_gebaeudeNahErzeugt', 'Kunden_Anrede', 'Kunden_Vorname', 'Kunden_Nachname', 'Kunden_Straße', 'Kunden_Hausnr', 'Kunden_PLZ', 'Kunden_Ort', 'Kunden_email', 'Kunden_telefon'];

add_action('init', function () {
  register_post_type('sfc_ea_auftrag', [
    'label' => 'Energieausweis-Aufträge', 'labels' => ['singular_name' => 'Energieausweis-Auftrag'],
    'public' => false, 'show_ui' => true, 'show_in_menu' => 'edit.php?post_type=sfc_anfrage',
    'supports' => ['title', 'editor'], 'capability_type' => 'post',
    'capabilities' => ['create_posts' => 'do_not_allow'], 'map_meta_cap' => true,
  ]);
});

add_shortcode('sfc_energieausweis', function ($atts = []) {
  $a = shortcode_atts(['zahlungslink' => 'https://buy.stripe.com/eVq00ld8KcWLbiz4wH9Zm02', 'partnerlink' => '', 'preis' => '59 €', 'zahlungslink_express' => 'https://buy.stripe.com/00w14pgkW8Gvaev9R19Zm03', 'preis_express' => '79 €', 'vorschau' => '0', 'bild' => content_url('uploads/2025/11/Welt_Beleuchtet.webp')], $atts);
  $dir = plugin_dir_path(__FILE__); $url = plugin_dir_url(__FILE__);
  wp_enqueue_style('sfc-ea', $url . 'ea.css', [], filemtime(__DIR__ . '/ea.css'));
  wp_enqueue_script('sfc-ea', $url . 'ea.js', [], filemtime(__DIR__ . '/ea.js'), ['in_footer' => true, 'strategy' => 'defer']);
  wp_add_inline_script('sfc-ea', 'window.SEA_CFG=' . wp_json_encode([
    'endpoint' => rest_url('sfc/v1/energieausweis'), 'adresse' => rest_url('sfc/v1/adresse'), 'anfrage' => rest_url('sfc/v1/anfrage'), 'zahlungslink' => esc_url_raw($a['zahlungslink']), 'zahlungslink_express' => esc_url_raw($a['zahlungslink_express']), 'preis_express' => $a['preis_express'], 'partnerlink' => esc_url_raw($a['partnerlink']),
    'preis' => $a['preis'], 'preview' => $a['vorschau'] === '1', 'bild' => esc_url_raw($a['bild']),
    'datenschutz' => get_privacy_policy_url() ?: home_url('/datenschutzerklaerung/')]) . ';', 'before');
  return str_replace('class="sea"', 'class="sea sea-wp"', file_get_contents($dir . 'ea.html'));
});

add_action('rest_api_init', function () {
  register_rest_route('sfc/v1', '/energieausweis', ['methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => 'sfc_ea_auftrag']);
  register_rest_route('sfc/v1', '/adresse', ['methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => 'sfc_ea_adresse']);
});

// Wert für die CSV: keine Trennzeichen, keine Formeln (Excel)
function sfc_ea_wert($v) {
  $v = trim(preg_replace('/[;"\r\n\t]+/', ' ', sanitize_text_field((string) $v)));
  return mb_substr(ltrim($v, '=+@'), 0, 120);
}

// Ablage für Fotos und CSV, von außen gesperrt
function sfc_ea_ordner() {
  $u = wp_upload_dir();
  $d = trailingslashit($u['basedir']) . 'sfc-ea-' . substr(wp_hash('sfc-ea'), 0, 12);
  if (!is_dir($d)) {
    wp_mkdir_p($d);
    file_put_contents("$d/.htaccess", "Require all denied\nDeny from all\n");
    file_put_contents("$d/index.php", '<?php // leer');
  }
  return $d;
}

function sfc_ea_auftrag(WP_REST_Request $r) {
  $d = json_decode((string) $r->get_param('daten'), true);
  if (!is_array($d) || !empty($d['website']) || !is_array($d['v'] ?? null)) return new WP_REST_Response(['ok' => false], 400);
  $v = array_merge(array_fill_keys(SFC_EA_SPALTEN, ''), array_map('sfc_ea_wert', array_intersect_key($d['v'], array_flip(SFC_EA_SPALTEN))));
  $mail = sanitize_email($d['v']['Kunden_email'] ?? '');
  if (!is_email($mail) || ($v['Kunden_Nachname'] ?? '') === '' || !preg_match('/^\d{5}$/', $v['PLZ'] ?? '') || ($v['ETr1_Jahr1_Menge'] ?? '') === '')
    return new WP_REST_Response(['ok' => false, 'fehler' => 'Es fehlen Angaben.'], 422);

  // max. 5 Aufträge pro IP und Stunde
  $key = 'sfc_ea_rl_' . md5($_SERVER['REMOTE_ADDR'] ?? '');
  $n = (int) get_transient($key);
  if ($n >= 5) return new WP_REST_Response(['ok' => false, 'fehler' => 'Zu viele Aufträge in kurzer Zeit.'], 429);
  set_transient($key, $n + 1, HOUR_IN_SECONDS);

  $titel = "{$v['Straße']} {$v['Hausnr']}, {$v['PLZ']} {$v['Ort']} – {$v['Kunden_Nachname']}";
  $pid = wp_insert_post(['post_type' => 'sfc_ea_auftrag', 'post_status' => 'private', 'post_title' => $titel]);
  if (!$pid || is_wp_error($pid)) return new WP_REST_Response(['ok' => false], 500);
  $id = 'VA' . wp_date('ymd') . '-' . $pid;
  $v['ID'] = $id;

  // Fotos prüfen und ablegen
  $ordner = sfc_ea_ordner(); $anh = [];
  $namen = ['ansicht', 'heizung', 'fenster'];
  foreach ([0, 1, 2] as $i) {
    $v["bilderStreams_$i"] = '';
    $f = $_FILES["foto$i"] ?? null;
    if (!$f || $f['error'] !== UPLOAD_ERR_OK || $f['size'] > 8 * MB_IN_BYTES) continue;
    $t = wp_check_filetype_and_ext($f['tmp_name'], $f['name'], ['jpg|jpeg' => 'image/jpeg', 'png' => 'image/png']);
    if (empty($t['ext']) || !@getimagesize($f['tmp_name'])) continue;
    $name = "{$id}_{$namen[$i]}." . ($t['ext'] === 'png' ? 'png' : 'jpg');
    if (move_uploaded_file($f['tmp_name'], "$ordner/$name")) { $anh[] = "$ordner/$name"; $v["bilderStreams_$i"] = $name; }
  }
  // Abrechnungen (Fotos oder PDF) nur als Mail-Anhang, nicht in die .evea
  $belege = [];
  for ($i = 0; $i < 5; $i++) {
    $f = $_FILES["beleg$i"] ?? null;
    if (!$f || $f['error'] !== UPLOAD_ERR_OK || $f['size'] > 8 * MB_IN_BYTES) continue;
    $t = wp_check_filetype_and_ext($f['tmp_name'], $f['name'], ['jpg|jpeg' => 'image/jpeg', 'png' => 'image/png', 'pdf' => 'application/pdf']);
    if (empty($t['ext'])) continue;
    if ($t['ext'] !== 'pdf' && !@getimagesize($f['tmp_name'])) continue;
    if ($t['ext'] === 'pdf' && file_get_contents($f['tmp_name'], false, null, 0, 5) !== '%PDF-') continue;
    $name = "{$id}_abrechnung" . ($i + 1) . '.' . ($t['ext'] === 'jpeg' ? 'jpg' : $t['ext']);
    if (move_uploaded_file($f['tmp_name'], "$ordner/$name")) $belege[] = "$ordner/$name";
  }

  $zeile = array_map(fn($h) => $v[$h] ?? '', SFC_EA_SPALTEN);
  $csv = "\xEF\xBB\xBF" . implode(';', SFC_EA_SPALTEN) . "\r\n" . implode(';', $zeile) . "\r\n";
  // EVEBI-Projektdatei aus der leeren Vorlage (Fotos werden eingebettet, Erläuterung als kurzer Empfehlungssatz)
  $evea = "$ordner/{$id}_" . sanitize_file_name("{$v['Straße']}_{$v['Hausnr']}") . '.evea';
  $fotos = array_values(array_filter($anh, fn($p) => strpos($p, '_ansicht.') !== false));
  $fotos = array_merge($fotos, array_values(array_diff($anh, $fotos)));
  if (class_exists('ZipArchive') && class_exists('DOMDocument') && sfc_ea_evea($v, $fotos, __DIR__ . '/vorlage-projekt.xml', $evea)) array_unshift($anh, $evea);
  else { file_put_contents("$ordner/$id.csv", $csv); array_unshift($anh, "$ordner/$id.csv"); }

  $zusatz = '';
  foreach ((array) ($d['zusatz'] ?? []) as $k => $w) $zusatz .= sanitize_text_field($k) . ': ' . sanitize_text_field($w) . "\n";
  $text = "Auftragsnummer: $id\nGebäude: $titel\nBaujahr / WE / Wohnfläche: {$v['Baujahr']} / {$v['Wohneinheiten']} / {$v['Wohnfläche']} m²\n"
    . "Kunde: {$v['Kunden_Vorname']} {$v['Kunden_Nachname']}, {$v['Kunden_Straße']} {$v['Kunden_Hausnr']}, {$v['Kunden_PLZ']} {$v['Kunden_Ort']}\nE-Mail: $mail\nTelefon: {$v['Kunden_telefon']}\n\n$zusatz";
  wp_update_post(['ID' => $pid, 'post_title' => "$id – $titel", 'post_content' => nl2br(esc_html($text)) . '<pre>' . esc_html(substr($csv, 3)) . '</pre>']);
  $anh = array_merge($anh, $belege);
  update_post_meta($pid, '_sfc_ea_dateien', $anh);

  $express = !empty($d['express']);
  if ($express) update_post_meta($pid, '_sfc_ea_express', 1);
  wp_mail(SFC_EMPFAENGER, ($express ? 'EXPRESS 24 h – ' : '') . "Energieausweis-Auftrag $id: $titel (Zahlung prüfen)",
    "Neuer Auftrag für einen Verbrauchsausweis.\n\n$text\nDie .evea-Datei im Anhang in EVEBI öffnen (Fotos und Erläuterung sind enthalten), rechnen lassen und mit den angehängten Abrechnungen abgleichen.\n"
    . "Bezahlt? In Stripe unter Zahlungen nach der Referenz $id suchen.\n", ["Reply-To: {$v['Kunden_Nachname']} <$mail>"], $anh);
  wp_mail($mail, "Ihr Energieausweis-Auftrag $id",
    "Guten Tag,\n\nvielen Dank für Ihren Auftrag für einen Verbrauchsausweis für $titel.\n\nNach Eingang der Zahlung prüfe ich Ihre Angaben und melde mich bei Rückfragen. Den fertigen Ausweis erhalten Sie als PDF per E-Mail, " . ($express ? 'innerhalb von 24 Stunden an Werktagen (Express).' : 'in der Regel innerhalb von 3 Werktagen.') . "\n\n"
    . "Mit freundlichen Grüßen\nStephan Hecky\nsENERGIEs Energieberatung\nMöchs 33, 91355 Hiltpoltstein · Tel. +49 155 65134339 · info@s-energies.de", ['Reply-To: sENERGIEs Energieberatung <' . SFC_EMPFAENGER . '>']);

  return new WP_REST_Response(['ok' => true, 'id' => $id], 200);
}

// Autoptimize nicht an das Skript lassen (wie beim Rechner)
add_filter('autoptimize_filter_js_exclude', function ($ex) { return $ex . ', ea.js'; });

// Adressprüfung: fragt OpenStreetMap (Nominatim) vom Server aus, damit die IP des Besuchers nicht weitergeht. Nur Gebäudeadresse, keine Namen.
// Antwort: treffer = haus | strasse | plz | keiner, ort = Ort zur PLZ laut OSM. Ergebnisse 30 Tage zwischengespeichert, max. 30 Abfragen je IP und Stunde.
function sfc_ea_osm(array $p) {
  $url = add_query_arg(array_merge($p, ['country' => 'de', 'format' => 'jsonv2', 'addressdetails' => 1, 'limit' => 1]), 'https://nominatim.openstreetmap.org/search');
  $r = wp_remote_get($url, ['timeout' => 6, 'headers' => ['User-Agent' => 'sENERGIEs-Energieausweis/1.0 (' . SFC_EMPFAENGER . ')', 'Accept-Language' => 'de']]);
  if (is_wp_error($r) || wp_remote_retrieve_response_code($r) !== 200) return null;
  $j = json_decode(wp_remote_retrieve_body($r), true);
  return is_array($j) ? ($j[0] ?? false) : null;
}
function sfc_ea_adresse(WP_REST_Request $r) {
  $plz = preg_replace('/\D/', '', (string) $r->get_param('plz'));
  if (strlen($plz) !== 5) return new WP_REST_Response(['treffer' => 'keiner'], 200);
  $str = sanitize_text_field((string) $r->get_param('str')); $hnr = sanitize_text_field((string) $r->get_param('hnr'));
  $cache = 'sfc_ea_adr_' . md5(strtolower("$plz|$str|$hnr"));
  if (($c = get_transient($cache)) !== false) return new WP_REST_Response($c, 200);
  $key = 'sfc_ea_adrl_' . md5($_SERVER['REMOTE_ADDR'] ?? '');
  $n = (int) get_transient($key);
  if ($n >= 30) return new WP_REST_Response(['treffer' => ''], 200);
  set_transient($key, $n + 1, HOUR_IN_SECONDS);
  $ort = function ($a) { $x = $a['address'] ?? []; return $x['city'] ?? $x['town'] ?? $x['village'] ?? $x['municipality'] ?? ''; };
  $plzTreffer = sfc_ea_osm(['postalcode' => $plz]);
  if ($plzTreffer === null) return new WP_REST_Response(['treffer' => ''], 200);
  $erg = ['treffer' => $plzTreffer ? 'plz' : 'keiner', 'ort' => $plzTreffer ? $ort($plzTreffer) : ''];
  if ($plzTreffer && $str !== '') {
    usleep(1100000); // Nominatim: höchstens eine Abfrage pro Sekunde
    $h = sfc_ea_osm(['street' => trim("$hnr $str"), 'postalcode' => $plz]);
    if ($h) $erg['treffer'] = !empty($h['address']['house_number']) ? 'haus' : 'strasse';
    elseif ($hnr !== '') { usleep(1100000); if (sfc_ea_osm(['street' => $str, 'postalcode' => $plz])) $erg['treffer'] = 'strasse'; }
  }
  set_transient($cache, $erg, 30 * DAY_IN_SECONDS);
  return new WP_REST_Response($erg, 200);
}
