/* sENERGIEs Fördercheck: anonymer Nutzungszähler. Keine Cookies, kein Speicher im Browser, keine IP:
   jedes Ereignis wird höchstens einmal pro Seitenaufruf als reine Zahl an WordPress gemeldet. */
(function () {
  var Z = window.SFC_ZAEHLER; if (!Z || !Z.url) return;
  var gemeldet = {};
  function melde(e) {
    if (gemeldet[e]) return; gemeldet[e] = 1;
    var u = Z.url + (Z.url.indexOf('?') < 0 ? '?' : '&') + 'e=' + e;
    try { if (navigator.sendBeacon && navigator.sendBeacon(u)) return; } catch (x) {}
    try { fetch(u, { method: 'POST', keepalive: true }); } catch (x) {}
  }
  function start() {
    var box = document.querySelector('.sfc'); if (!box) return;
    melde('aufruf');
    // erste Eingabe im Rechner
    box.addEventListener('click', function (ev) {
      var t = ev.target.closest ? ev.target.closest('button,a') : null; if (!t) return;
      if (t.closest('.sfk .tiles, .sfk .chips')) melde('start');
      if (t.closest('.sfk .buch')) melde('buch');
      if (t.closest('.sfk .ad a, [data-sfc-partner]')) melde('partner');
      if (t.id === 'sfk-adBtn') melde('partner_interesse');
    }, true);
    box.addEventListener('input', function () { melde('start'); }, true);
    // Ergebnis erreicht (Kachel-Ansicht zeigt „fertig“), Anfrage gesendet, PDF erstellt
    var schritt = document.getElementById('sfk-stepN'), ok = document.getElementById('leadOk');
    new MutationObserver(function () {
      if (schritt && schritt.textContent === 'fertig') melde('ergebnis');
      if (ok && !ok.hidden) melde('anfrage');
      if (document.documentElement.classList.contains('sfc-printing')) melde('pdf');
    }).observe(document.documentElement, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ['hidden', 'class'] });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
