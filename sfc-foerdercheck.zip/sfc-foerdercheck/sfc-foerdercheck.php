<?php
/**
 * Plugin Name: sENERGIEs Fördercheck
 * Description: Förderrechner für Heizung, Dämmung und Fenster (BEG ab 21.07.2026) mit Anfrageformular. Einbinden mit dem Shortcode [foerdercheck]. Online-Verbrauchsausweis mit [sfc_energieausweis], Angebotscheck mit kostenlosem Kurzcheck mit [sfc_angebotscheck].
 * Version: 1.9.0
 * Author: sENERGIEs Energieberatung
 * Requires PHP: 7.4
 */
if (!defined('ABSPATH')) exit;

require_once __DIR__ . '/updater.php';
sfc_updater(__FILE__, 'https://raw.githubusercontent.com/senergiesenergieberatung-prog/foerdercheck_update/main/sfc-foerdercheck.json');

// Dateien mit Inhalts-Prüfsumme im Namen (z. B. kacheln.1a2b3c4d.js): jede Änderung bekommt eine neue Adresse,
// Browser und Optimierungs-Plugins können kein altes Skript mehr liefern. Ohne Prüfsummen-Datei: normaler Name.
if (!function_exists('sfc_datei')) {
  function sfc_datei($dir, $name) {
    $i = pathinfo($name);
    $g = glob($dir . $i['filename'] . '.*.' . $i['extension']) ?: [];
    usort($g, function ($a, $b) { return filemtime($b) <=> filemtime($a); });
    return $g ? basename($g[0]) : $name;
  }
}


define('SFC_EMPFAENGER', 'info@s-energies.de');

// Aroundhome (Awin) nur für Häuser außerhalb des Einsatzgebiets (ca. 50 km um Hiltpoltstein, PLZ-Liste aus GeoNames, Stand 2026-11-05).
// Einstellung „sfc_aroundhome“: ['aktiv' => 1, 'berater' => URL, 'heizung' => URL]. Ohne „aktiv“ bleibt das Ergebnis wie bisher.
// Kostenlose Online-Beratung (Microsoft Bookings), in beiden Fällen
define('SFC_BUCHUNG', 'https://outlook.office.com/book/sENERGIEs1@s-energies.de/s/hIzin_zUn0OESAmxRsT0bw2');
define('SFC_REGION_PLZ', '90051 90290 90291 90292 90293 90300 90310 90311 90312 90313 90316 90318 90319 90321 90324 90325 90327 90328 90329 90330 90331 90332 90334 90335 90336 90337 90338 90339 90340 90341 90344 90345 90346 90347 90351 90352 90353 90356 90357 90359 90360 90402 90403 90408 90409 90411 90419 90425 90427 90429 90431 90439 90441 90443 90449 90451 90453 90455 90457 90459 90461 90469 90471 90473 90475 90478 90480 90482 90489 90491 90499 90511 90513 90518 90522 90530 90537 90542 90546 90547 90552 90556 90559 90562 90571 90574 90579 90584 90587 90592 90596 90602 90607 90610 90613 90614 90617 90725 90742 90744 90752 90754 90762 90763 90765 90766 90768 91048 91050 91051 91052 91054 91056 91058 91060 91072 91074 91077 91080 91083 91085 91086 91088 91090 91091 91093 91094 91096 91097 91099 91124 91125 91126 91152 91154 91186 91189 91205 91207 91217 91220 91224 91227 91230 91233 91235 91236 91238 91239 91241 91242 91244 91245 91247 91249 91257 91275 91278 91281 91282 91284 91286 91287 91289 91299 91301 91315 91320 91322 91325 91327 91330 91332 91334 91336 91338 91341 91344 91346 91347 91349 91350 91352 91353 91355 91356 91358 91359 91361 91362 91364 91365 91367 91369 91448 91452 91462 91466 91468 91469 91475 91486 91487 91489 92219 92224 92237 92240 92241 92242 92245 92249 92256 92259 92260 92262 92265 92268 92271 92274 92275 92278 92280 92281 92283 92284 92289 92318 92348 92353 92361 92367 92369 92655 92676 92690 92700 92720 92724 95326 95336 95349 95359 95367 95440 95442 95444 95445 95447 95448 95455 95460 95463 95466 95469 95473 95478 95485 95488 95490 95491 95494 95496 95497 95499 95500 95502 95503 95505 95506 95508 95511 95512 95514 95515 95517 95519 96044 96045 96047 96049 96050 96052 96060 96061 96077 96103 96110 96114 96117 96120 96123 96129 96135 96138 96142 96146 96148 96149 96155 96158 96163 96164 96167 96170 96172 96173 96175 96178 96187 96191 96193 96194 96196 96197 96199 96260');
function sfc_vor_ort_cfg() {
  $o = get_option('sfc_aroundhome', []);
  if (!is_array($o) || empty($o['aktiv'])) return [];
  return ['region' => explode(' ', SFC_REGION_PLZ), 'ah' => ['berater' => esc_url_raw($o['berater'] ?? ''), 'heizung' => esc_url_raw($o['heizung'] ?? ''), 'buchung' => esc_url_raw($o['buchung'] ?? SFC_BUCHUNG)]];
}
add_action('init', function () {
  register_setting('options', 'sfc_aroundhome', ['type' => 'object', 'default' => [], 'show_in_rest' => ['schema' => ['type' => 'object', 'properties' => ['aktiv' => ['type' => 'integer'], 'berater' => ['type' => 'string'], 'heizung' => ['type' => 'string'], 'buchung' => ['type' => 'string']]]]]);
});
require_once __DIR__ . '/urlaub.php';
require_once __DIR__ . '/energieausweis.php';
require_once __DIR__ . '/angebotscheck.php';
require_once __DIR__ . '/kurzcheck.php';
require_once __DIR__ . '/lizenz-server.php';
require_once __DIR__ . '/llms.php';
require_once __DIR__ . '/zaehler.php';

// Anfragen als eigener Beitragstyp, sichtbar im Admin-Menü
add_action('init', function () {
  register_post_type('sfc_anfrage', [
    'label' => 'Fördercheck-Anfragen',
    'labels' => ['singular_name' => 'Anfrage', 'menu_name' => 'Fördercheck'],
    'public' => false, 'show_ui' => true, 'menu_icon' => 'dashicons-calculator',
    'supports' => ['title', 'editor'], 'capability_type' => 'post',
    'capabilities' => ['create_posts' => 'do_not_allow'], 'map_meta_cap' => true,
  ]);
});

add_shortcode('foerdercheck', function ($atts = []) {
  // ueberschrift="h2", wenn die Seite schon eine H1 hat
  // bild="URL" ersetzt das Hintergrundbild im Kopfbereich
  // ansicht="kacheln" zeigt den Klick-Rechner mit großen Kacheln statt des Formulars
  $a = shortcode_atts(['ueberschrift' => 'h1', 'bild' => content_url('uploads/2025/11/Welt_Beleuchtet.webp'), 'ansicht' => 'formular'], $atts);
  $kacheln = $a['ansicht'] === 'kacheln';
  $htag = $a['ueberschrift'] === 'h2' ? 'h2' : 'h1';
  $dir = plugin_dir_path(__FILE__); $url = plugin_dir_url(__FILE__);
  wp_enqueue_style('sfc', $url . sfc_datei($dir, 'assets.css'), [], null);
  if ($kacheln) wp_enqueue_style('sfc-kacheln', $url . sfc_datei($dir, 'kacheln.css'), ['sfc'], null);
  wp_enqueue_script('sfc', $url . sfc_datei($dir, $kacheln ? 'kacheln.js' : 'foerdercheck.js'), [], null, ['in_footer' => true, 'strategy' => 'defer']);
  wp_add_inline_script('sfc', 'window.SFC_CFG=' . wp_json_encode(['endpoint' => rest_url('sfc/v1/anfrage'), 'datenschutz' => get_privacy_policy_url() ?: home_url('/datenschutz/'), 'logo' => content_url('uploads/2026/02/Logo-100x100.webp'),
    'firma' => 'sENERGIEs Energieberatung', 'kontakt' => 'Möchs 33, 91355 Hiltpoltstein · Tel. +49 155 65134339 · info@s-energies.de · s-energies.de',
    'buch' => ['url' => 'https://www.amazon.de/dp/B0HPY77NZP', 'cover' => content_url('uploads/2026/10/heizungstausch-2027-cover.webp'), 'titel' => 'Buch „Heizungstausch 2027“',
      'text' => 'Alle Förderregeln, Fristen und Fallstricke beim Heizungstausch ausführlich erklärt. Von Stephan Hecky, sENERGIEs. E-Book 4,99 €, Taschenbuch 12,99 €.']] + sfc_vor_ort_cfg()) . ';', 'before');
  sfc_zaehler_einbinden();
  $html = file_get_contents($dir . ($kacheln ? 'kacheln.html' : 'markup.html'));
  [$gross, $klein] = sfc_hero_bilder($a['bild']);
  return strtr($html, ['{{DATENSCHUTZ}}' => esc_url(get_privacy_policy_url() ?: home_url('/datenschutz/')), '{{HTAG}}' => $htag, '{{HERO}}' => esc_url($gross), '{{HERO_KLEIN}}' => esc_url($klein)]);
});

// Kopfbild in voller Größe und als 768er-Variante fürs Handy (falls die Mediathek eine hat)
function sfc_hero_bilder($bild) {
  $id = attachment_url_to_postid($bild);
  $klein = $id ? wp_get_attachment_image_url($id, 'medium_large') : '';
  return [$bild, $klein ?: $bild];
}

// Kopfbild vorladen, damit der Browser es nicht erst nach dem CSS entdeckt (größte sichtbare Fläche).
// Die Seite ist mit Elementor gebaut, der Shortcode steht dann in _elementor_data statt im Inhalt.
add_action('wp_head', function () {
  if (!is_singular()) return;
  $post = get_post();
  $text = $post->post_content . (string) get_post_meta($post->ID, '_elementor_data', true);
  if (strpos($text, '[foerdercheck') === false || strpos($text, 'bild=') !== false) return;
  [$gross, $klein] = sfc_hero_bilder(content_url('uploads/2025/11/Welt_Beleuchtet.webp'));
  if ($klein === $gross) { printf('<link rel="preload" as="image" fetchpriority="high" href="%s">' . "\n", esc_url($gross)); return; }
  // gleiche Grenze wie in assets.css, sonst lädt das Handy beide Bilder
  printf('<link rel="preload" as="image" fetchpriority="high" href="%s" media="(max-width: 768px)">' . "\n", esc_url($klein));
  printf('<link rel="preload" as="image" fetchpriority="high" href="%s" media="(min-width: 769px)">' . "\n", esc_url($gross));
}, 1);

// Poppins 400 (Fließtext) vorladen: Astra lädt nur 600 und DM Serif vorab, sonst springt der Text beim Nachladen (CLS).
// Astra kann die Dateinamen bei Updates ändern, deshalb nur ausgeben, wenn die Datei existiert.
add_action('wp_head', function () {
  $datei = 'astra-local-fonts/poppins/pxiEyp8kv8JHgFVrJJfecg.woff2';
  if (!file_exists(WP_CONTENT_DIR . '/' . $datei)) return;
  printf('<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url(content_url($datei)));
}, 1);

add_action('rest_api_init', function () {
  register_rest_route('sfc/v1', '/anfrage', ['methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => 'sfc_anfrage']);
});

function sfc_anfrage(WP_REST_Request $r) {
  $d = $r->get_json_params();
  if (!is_array($d) || !empty($d['website'])) return new WP_REST_Response(['ok' => false], 400); // Honeypot
  $c = fn($k, $n = 200) => mb_substr(sanitize_text_field((string)($d[$k] ?? '')), 0, $n);
  $name = $c('name'); $mail = sanitize_email($d['mail'] ?? ''); $plz = $c('plz', 5);
  if ($name === '' || !is_email($mail) || !preg_match('/^\d{5}$/', $plz)) return new WP_REST_Response(['ok' => false], 422);

  // max. 5 Anfragen pro IP und Stunde
  $key = 'sfc_rl_' . md5($_SERVER['REMOTE_ADDR'] ?? '');
  $n = (int) get_transient($key);
  if ($n >= 5) return new WP_REST_Response(['ok' => false], 429);
  set_transient($key, $n + 1, HOUR_IN_SECONDS);

  $felder = ['Name' => $name, 'E-Mail' => $mail, 'Telefon' => $c('tel', 40), 'PLZ' => $plz, 'Anliegen' => $c('wunsch'),
    'Zuschuss (geschätzt)' => $c('zuschuss', 12) . ' €', 'Kosten gesamt' => $c('kosten', 12) . ' €', 'Aufteilung' => $c('details', 600),
    'Wohneinheiten' => $c('we', 4), 'Nutzung' => $c('nutzung', 20), 'Effizienzklasse' => $c('klasse', 3),
    'Heizung alt' => $c('alt', 20), 'Heizung neu' => $c('neu', 20), 'iSFP' => !empty($d['isfp']) ? 'ja' : 'nein',
    'Angaben (Kachel-Rechner)' => $c('angaben', 800)];
  $felder = array_filter($felder, fn($v) => $v !== '');
  $text = '';
  foreach ($felder as $k => $v) $text .= "$k: $v\n";

  wp_insert_post(['post_type' => 'sfc_anfrage', 'post_status' => 'private',
    'post_title' => "$plz – $name – " . $felder['Zuschuss (geschätzt)'], 'post_content' => nl2br(esc_html($text))]);
  wp_mail(SFC_EMPFAENGER, "Fördercheck-Anfrage $plz: $name", "Neue Anfrage aus dem Fördercheck\n\n$text", ["Reply-To: $name <$mail>"]);
  return new WP_REST_Response(['ok' => true], 200);
}

// Autoptimize nicht an das Rechner-Skript lassen: der Minifier entfernt Leerzeichen in den Texten
add_filter('autoptimize_filter_js_exclude', function ($ex) { return $ex . ', sfc-foerdercheck/foerdercheck., sfc-foerdercheck/kacheln., sfc-foerdercheck/ea., sfc-foerdercheck/ac., sfc-foerdercheck/ac-lesen., sfc-foerdercheck/pdfjs/'; });
add_filter('autoptimize_filter_js_minify_excluded', function ($minify, $url = '') { return preg_match('/(foerdercheck|kacheln|ea|ac|ac-lesen)(\.[0-9a-f]{8})?\.js|pdfjs\//', (string) $url) ? false : $minify; }, 10, 2);
