<?php
/**
 * Plugin Name: sENERGIEs Fördercheck
 * Description: Förderrechner für Heizung, Dämmung und Fenster (BEG ab 21.07.2026) mit Anfrageformular. Einbinden mit dem Shortcode [foerdercheck]. Online-Verbrauchsausweis mit [sfc_energieausweis].
 * Version: 1.7.15
 * Author: sENERGIEs Energieberatung
 * Requires PHP: 7.4
 */
if (!defined('ABSPATH')) exit;

require_once __DIR__ . '/updater.php';
sfc_updater(__FILE__, 'https://raw.githubusercontent.com/senergiesenergieberatung-prog/foerdercheck_update/main/sfc-foerdercheck.json');

// Dateien mit Inhalts-Prüfsumme im Namen (z. B. kacheln.1a2b3c4d.js): jede Änderung bekommt eine neue Adresse,
// Browser und Optimierungs-Plugins können kein altes Skript mehr liefern. Ohne Prüfsummen-Datei: normaler Name.
if (!function_exists('sfc_datei')) {
  function sfc_datei($dir, $name) {
    $i = pathinfo($name);
    $g = glob($dir . $i['filename'] . '.*.' . $i['extension']) ?: [];
    usort($g, function ($a, $b) { return filemtime($b) <=> filemtime($a); });
    return $g ? basename($g[0]) : $name;
  }
}


define('SFC_EMPFAENGER', 'info@s-energies.de');
require_once __DIR__ . '/energieausweis.php';
require_once __DIR__ . '/lizenz-server.php';

// Anfragen als eigener Beitragstyp, sichtbar im Admin-Menü
add_action('init', function () {
  register_post_type('sfc_anfrage', [
    'label' => 'Fördercheck-Anfragen',
    'labels' => ['singular_name' => 'Anfrage', 'menu_name' => 'Fördercheck'],
    'public' => false, 'show_ui' => true, 'menu_icon' => 'dashicons-calculator',
    'supports' => ['title', 'editor'], 'capability_type' => 'post',
    'capabilities' => ['create_posts' => 'do_not_allow'], 'map_meta_cap' => true,
  ]);
});

add_shortcode('foerdercheck', function ($atts = []) {
  // ueberschrift="h2", wenn die Seite schon eine H1 hat
  // bild="URL" ersetzt das Hintergrundbild im Kopfbereich
  // ansicht="kacheln" zeigt den Klick-Rechner mit großen Kacheln statt des Formulars
  $a = shortcode_atts(['ueberschrift' => 'h1', 'bild' => content_url('uploads/2025/11/Welt_Beleuchtet.webp'), 'ansicht' => 'formular'], $atts);
  $kacheln = $a['ansicht'] === 'kacheln';
  $htag = $a['ueberschrift'] === 'h2' ? 'h2' : 'h1';
  $dir = plugin_dir_path(__FILE__); $url = plugin_dir_url(__FILE__);
  wp_enqueue_style('sfc', $url . sfc_datei($dir, 'assets.css'), [], null);
  if ($kacheln) wp_enqueue_style('sfc-kacheln', $url . sfc_datei($dir, 'kacheln.css'), ['sfc'], null);
  wp_enqueue_script('sfc', $url . sfc_datei($dir, $kacheln ? 'kacheln.js' : 'foerdercheck.js'), [], null, ['in_footer' => true, 'strategy' => 'defer']);
  wp_add_inline_script('sfc', 'window.SFC_CFG=' . wp_json_encode(['endpoint' => rest_url('sfc/v1/anfrage'), 'datenschutz' => get_privacy_policy_url() ?: home_url('/datenschutz/'), 'logo' => content_url('uploads/2026/02/Logo-100x100.webp'),
    'firma' => 'sENERGIEs Energieberatung', 'kontakt' => 'Möchs 33, 91355 Hiltpoltstein · Tel. +49 155 65134339 · info@s-energies.de · s-energies.de',
    'buch' => ['url' => 'https://www.amazon.de/dp/B0HPY77NZP', 'cover' => content_url('uploads/2026/10/heizungstausch-2027-cover.webp'), 'titel' => 'Buch „Heizungstausch 2027“',
      'text' => 'Alle Förderregeln, Fristen und Fallstricke beim Heizungstausch ausführlich erklärt. Von Stephan Hecky, sENERGIEs. E-Book 4,99 €, Taschenbuch 12,14 €.']]) . ';', 'before');
  $html = file_get_contents($dir . ($kacheln ? 'kacheln.html' : 'markup.html'));
  [$gross, $klein] = sfc_hero_bilder($a['bild']);
  return strtr($html, ['{{DATENSCHUTZ}}' => esc_url(get_privacy_policy_url() ?: home_url('/datenschutz/')), '{{HTAG}}' => $htag, '{{HERO}}' => esc_url($gross), '{{HERO_KLEIN}}' => esc_url($klein)]);
});

// Kopfbild in voller Größe und als 768er-Variante fürs Handy (falls die Mediathek eine hat)
function sfc_hero_bilder($bild) {
  $id = attachment_url_to_postid($bild);
  $klein = $id ? wp_get_attachment_image_url($id, 'medium_large') : '';
  return [$bild, $klein ?: $bild];
}

// Kopfbild vorladen, damit der Browser es nicht erst nach dem CSS entdeckt (größte sichtbare Fläche).
// Die Seite ist mit Elementor gebaut, der Shortcode steht dann in _elementor_data statt im Inhalt.
add_action('wp_head', function () {
  if (!is_singular()) return;
  $post = get_post();
  $text = $post->post_content . (string) get_post_meta($post->ID, '_elementor_data', true);
  if (strpos($text, '[foerdercheck') === false || strpos($text, 'bild=') !== false) return;
  [$gross, $klein] = sfc_hero_bilder(content_url('uploads/2025/11/Welt_Beleuchtet.webp'));
  if ($klein === $gross) { printf('<link rel="preload" as="image" fetchpriority="high" href="%s">' . "\n", esc_url($gross)); return; }
  // gleiche Grenze wie in assets.css, sonst lädt das Handy beide Bilder
  printf('<link rel="preload" as="image" fetchpriority="high" href="%s" media="(max-width: 768px)">' . "\n", esc_url($klein));
  printf('<link rel="preload" as="image" fetchpriority="high" href="%s" media="(min-width: 769px)">' . "\n", esc_url($gross));
}, 1);

// Poppins 400 (Fließtext) vorladen: Astra lädt nur 600 und DM Serif vorab, sonst springt der Text beim Nachladen (CLS).
// Astra kann die Dateinamen bei Updates ändern, deshalb nur ausgeben, wenn die Datei existiert.
add_action('wp_head', function () {
  $datei = 'astra-local-fonts/poppins/pxiEyp8kv8JHgFVrJJfecg.woff2';
  if (!file_exists(WP_CONTENT_DIR . '/' . $datei)) return;
  printf('<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url(content_url($datei)));
}, 1);

add_action('rest_api_init', function () {
  register_rest_route('sfc/v1', '/anfrage', ['methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => 'sfc_anfrage']);
});

function sfc_anfrage(WP_REST_Request $r) {
  $d = $r->get_json_params();
  if (!is_array($d) || !empty($d['website'])) return new WP_REST_Response(['ok' => false], 400); // Honeypot
  $c = fn($k, $n = 200) => mb_substr(sanitize_text_field((string)($d[$k] ?? '')), 0, $n);
  $name = $c('name'); $mail = sanitize_email($d['mail'] ?? ''); $plz = $c('plz', 5);
  if ($name === '' || !is_email($mail) || !preg_match('/^\d{5}$/', $plz)) return new WP_REST_Response(['ok' => false], 422);

  // max. 5 Anfragen pro IP und Stunde
  $key = 'sfc_rl_' . md5($_SERVER['REMOTE_ADDR'] ?? '');
  $n = (int) get_transient($key);
  if ($n >= 5) return new WP_REST_Response(['ok' => false], 429);
  set_transient($key, $n + 1, HOUR_IN_SECONDS);

  $felder = ['Name' => $name, 'E-Mail' => $mail, 'Telefon' => $c('tel', 40), 'PLZ' => $plz, 'Anliegen' => $c('wunsch'),
    'Zuschuss (geschätzt)' => $c('zuschuss', 12) . ' €', 'Kosten gesamt' => $c('kosten', 12) . ' €', 'Aufteilung' => $c('details', 600),
    'Wohneinheiten' => $c('we', 4), 'Nutzung' => $c('nutzung', 20), 'Effizienzklasse' => $c('klasse', 3),
    'Heizung alt' => $c('alt', 20), 'Heizung neu' => $c('neu', 20), 'iSFP' => !empty($d['isfp']) ? 'ja' : 'nein',
    'Angaben (Kachel-Rechner)' => $c('angaben', 800)];
  $felder = array_filter($felder, fn($v) => $v !== '');
  $text = '';
  foreach ($felder as $k => $v) $text .= "$k: $v\n";

  wp_insert_post(['post_type' => 'sfc_anfrage', 'post_status' => 'private',
    'post_title' => "$plz – $name – " . $felder['Zuschuss (geschätzt)'], 'post_content' => nl2br(esc_html($text))]);
  wp_mail(SFC_EMPFAENGER, "Fördercheck-Anfrage $plz: $name", "Neue Anfrage aus dem Fördercheck\n\n$text", ["Reply-To: $name <$mail>"]);
  return new WP_REST_Response(['ok' => true], 200);
}

// Autoptimize nicht an das Rechner-Skript lassen: der Minifier entfernt Leerzeichen in den Texten
add_filter('autoptimize_filter_js_exclude', function ($ex) { return $ex . ', sfc-foerdercheck/foerdercheck., sfc-foerdercheck/kacheln., sfc-foerdercheck/ea.'; });
add_filter('autoptimize_filter_js_minify_excluded', function ($minify, $url = '') { return preg_match('/(foerdercheck|kacheln|ea)(\.[0-9a-f]{8})?\.js/', (string) $url) ? false : $minify; }, 10, 2);
