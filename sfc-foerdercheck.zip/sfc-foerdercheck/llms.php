<?php
/**
 * /llms.txt aus der WP-Option „sfc_llms_txt“ ausliefern.
 * Lesen und Schreiben per REST nur für Administratoren (manage_options):
 *   GET  /wp-json/sfc/v1/llms
 *   POST /wp-json/sfc/v1/llms   {"inhalt": "..."}   (leer = Auslieferung aus, dann greift wieder die bisherige Quelle)
 * Zusätzlich als Einstellung „sfc_llms_txt“ unter /wp-json/wp/v2/settings sichtbar.
 */
if (!defined('ABSPATH')) exit;

define('SFC_LLMS_OPTION', 'sfc_llms_txt');
define('SFC_LLMS_MAX', 200000); // Zeichen

function sfc_llms_bereinigen($wert) {
  $t = is_string($wert) ? $wert : '';
  $t = wp_check_invalid_utf8($t);
  $t = str_replace(["\r\n", "\r"], "\n", $t);
  $t = str_replace("\0", '', $t);
  if (function_exists('mb_substr')) $t = mb_substr($t, 0, SFC_LLMS_MAX);
  else $t = substr($t, 0, SFC_LLMS_MAX);
  return $t;
}

add_action('init', function () {
  register_setting('general', SFC_LLMS_OPTION, [
    'type' => 'string',
    'description' => 'Inhalt von /llms.txt (sENERGIEs Fördercheck)',
    'sanitize_callback' => 'sfc_llms_bereinigen',
    'show_in_rest' => true,
    'default' => '',
  ]);
});

add_action('rest_api_init', function () {
  $admin = function () { return current_user_can('manage_options'); };
  register_rest_route('sfc/v1', '/llms', [
    [
      'methods' => 'GET',
      'permission_callback' => $admin,
      'callback' => function () {
        $t = (string) get_option(SFC_LLMS_OPTION, '');
        return ['inhalt' => $t, 'aktiv' => trim($t) !== '', 'url' => home_url('/llms.txt')];
      },
    ],
    [
      'methods' => 'POST',
      'permission_callback' => $admin,
      'args' => ['inhalt' => ['required' => true, 'type' => 'string']],
      'callback' => function (WP_REST_Request $r) {
        $t = sfc_llms_bereinigen($r->get_param('inhalt'));
        update_option(SFC_LLMS_OPTION, $t, false);
        return ['gespeichert' => true, 'zeichen' => strlen($t), 'aktiv' => trim($t) !== '', 'url' => home_url('/llms.txt')];
      },
    ],
  ]);
});

// Möglichst früh ausliefern, damit andere Plugins mit eigener llms.txt nicht dazwischenfunken.
// Ist die Option leer, passiert nichts und die bisherige Quelle bleibt aktiv.
add_action('plugins_loaded', 'sfc_llms_ausliefern', -1000);
function sfc_llms_ausliefern() {
  if (!isset($_SERVER['REQUEST_URI'])) return;
  $m = isset($_SERVER['REQUEST_METHOD']) ? strtoupper($_SERVER['REQUEST_METHOD']) : 'GET';
  if ($m !== 'GET' && $m !== 'HEAD') return;
  $pfad = (string) parse_url((string) $_SERVER['REQUEST_URI'], PHP_URL_PATH);
  $basis = (string) parse_url(home_url('/'), PHP_URL_PATH);
  if (rtrim($pfad, '/') !== rtrim($basis, '/') . '/llms.txt') return;
  $t = (string) get_option(SFC_LLMS_OPTION, '');
  if (trim($t) === '') return;
  if (!headers_sent()) {
    status_header(200);
    header('Content-Type: text/plain; charset=utf-8');
    header('X-Robots-Tag: noindex');
    header('Cache-Control: public, max-age=3600');
    header('Content-Length: ' . strlen($t));
  }
  if ($m === 'GET') echo $t;
  exit;
}
