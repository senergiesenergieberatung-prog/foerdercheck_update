/* sENERGIEs Angebotscheck: kostenloser Kurzcheck (Preisvergleich mit der Preisdatenbank + Förderschätzung, läuft nur im Browser),
   danach persönliche Prüfung: Angebotsbewertung (1 Angebot) oder Angebotsvergleich (bis zu 3 Angebote) mit Upload und Stripe-Zahlung. */
(function () {
  const C = Object.assign({ preview: false, endpoint: '', zahlung: '', zahlungslink: '', zahlungslink_vergleich: '', preis: '49 €', preis_vergleich: '79 €', datenschutz: '/datenschutzerklaerung/', bild: '', preise: null, kc_endpoint: '', pdfjs: 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js', pdfworker: 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js', foerderrechner: '/foerdercheck/' }, window.SAC_CFG || {});
  const $ = id => document.getElementById('sac-' + id);
  const q = (s, r = document) => r.querySelector(s);
  if (!$('f')) return;
  const val = id => ($(id).value || '').trim();
  const istHz = () => val('gewerk') === 'Heizung';
  const num = s => { s = String(s ?? '').trim().replace(/\s|€/g, ''); if (!s) return NaN; if (/,/.test(s)) s = s.replace(/\./g, '').replace(',', '.'); else if (/^\d{1,3}(\.\d{3})+$/.test(s)) s = s.replace(/\./g, ''); return parseFloat(s); };
  const de = (n, d = 0) => isFinite(n) ? (Math.round(n * 10 ** d) / 10 ** d).toLocaleString('de-DE') : '';
  const eur = n => de(n) + ' €';
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const MAXDATEI = 10e6, MAXJE = 6, MAXSUMME = 60e6;

  // Energieträger: Name, Einheit auf der Abrechnung, kWh je Einheit, Nutzungsgrad (Wärmepumpe: Jahresarbeitszahl ca. 3)
  const ETR = { gas: ['Erdgas', 'kWh', 1, .9], oel: ['Heizöl', 'Liter', 10, .85], fluessig: ['Flüssiggas', 'Liter', 6.57, .9], pellet: ['Pellets', 'kg', 4.9, .85],
    holz: ['Scheitholz', 'Ster', 1750, .7], strom: ['Strom / Nachtspeicher', 'kWh', 1, 1], fw: ['Fernwärme', 'kWh', 1, .98], wp: ['Wärmepumpe', 'kWh Strom', 1, 3] };

  if (C.preview) { $('tag').hidden = false; $('vorschau').hidden = false; }
  if (C.bild) q('#sac .sea-kopf').style.backgroundImage = `linear-gradient(rgba(44,41,39,.78),rgba(44,41,39,.78)),url("${C.bild}")`;
  $('dslink').href = C.datenschutz; document.querySelectorAll('#sac .sac-dslink').forEach(a => a.href = C.datenschutz); $('p1').textContent = C.preis; $('p2').textContent = C.preis_vergleich;

  // =====================================================================
  // Kostenloser Kurzcheck
  // =====================================================================
  // System: [Schlüssel, Name, Schlüssel in der Preisdatenbank (null = noch keine Vergleichswerte), Einheit, Beispiel, Förderart, Name im Auftragsformular]
  const SYS = {
    'Heizung': [['wp', 'Luft-Wasser-Wärmepumpe', 'WP Luft/Wasser|€/kW', 'kW Heizleistung', '9', 'wp', 'Luft-Wasser-Wärmepumpe'],
      ['wpe', 'Erdwärmepumpe', null, 'kW Heizleistung', '9', 'wp', 'Erdwärmepumpe'],
      ['pellet', 'Pelletkessel', 'Pellet|€/kW', 'kW Nennleistung', '15', 'bio', 'Pellet- oder Hackschnitzelheizung'],
      ['hack', 'Hackschnitzelkessel', 'Hackschnitzel|€/kW', 'kW Nennleistung', '30', 'bio', 'Pellet- oder Hackschnitzelheizung'],
      ['scheit', 'Scheitholzkessel', 'Scheitholz|€/kW', 'kW Nennleistung', '25', 'bio', 'Scheitholz- oder Kombikessel'],
      ['kombi', 'Kombikessel Scheitholz/Pellet', 'Pellet/Scheitholz-Kombi|€/kW', 'kW Nennleistung', '25', 'bio', 'Scheitholz- oder Kombikessel'],
      ['solar', 'Solarthermie', 'Solarthermie|€/m²', 'm² Kollektorfläche', '10', 'solar', 'Solarthermie']],
    'Dach / oberste Geschossdecke': [['auf', 'Aufsparrendämmung mit neuer Eindeckung', 'Aufsparrendämmung|€/m²', 'm² Dachfläche', '160', 'huelle'],
      ['aufin', 'Aufsparrendämmung mit neuer Innenverkleidung', 'Aufsparrendämmung inkl. Innenbekleidung|€/m²', 'm² Dachfläche', '160', 'huelle'],
      ['zwi', 'Zwischen- oder Untersparrendämmung von innen', null, 'm² Dachfläche', '120', 'huelle'],
      ['ogd', 'Dämmung der obersten Geschossdecke', 'OGD-Dämmung|€/m²', 'm² Deckenfläche', '80', 'huelle']],
    'Außenwand / Fassade': [['wdvs', 'Wärmedämmverbundsystem', null, 'm² Wandfläche', '180', 'huelle'],
      ['vhf', 'Vorgehängte Fassade', null, 'm² Wandfläche', '180', 'huelle'],
      ['kern', 'Kern- oder Innendämmung', null, 'm² Wandfläche', '180', 'huelle']],
    'Fenster und Außentüren': [['fen', 'Fenster', 'Fenster Kunststoff|€/m²', 'm² Fensterfläche (Breite × Höhe, alle Fenster)', '25', 'huelle'],
      ['tuer', 'Haustür', 'Haustür|€/Stück', 'Stück', '1', 'huelle']],
    'Kellerdecke / Bodenplatte': [['kd', 'Dämmung der Kellerdecke', null, 'm² Deckenfläche', '90', 'huelle']],
    'Lüftungsanlage': [['zl', 'Zentrale Lüftung mit Wärmerückgewinnung', null, 'm² Wohnfläche', '140', 'huelle'],
      ['dl', 'Dezentrale Lüfter mit Wärmerückgewinnung', null, 'Stück', '6', 'huelle']],
    'Photovoltaik': [['pvs', 'PV-Anlage mit Speicher', 'PV mit Batterie|€/kWp', 'kWp', '10', 'pv'],
      ['pv', 'PV-Anlage ohne Speicher', null, 'kWp', '10', 'pv']]
  };
  // Technische Mindestanforderungen (Kurzfassung) und worauf man im Angebot achten sollte
  const TMA = { wp: 'Jahresarbeitszahl mindestens 3,0, Geräuschgrenzwert der Außeneinheit eingehalten, hydraulischer Abgleich.', bio: 'Emissionsgrenzwerte für Staub und Kohlenmonoxid, ausreichend großer Pufferspeicher, hydraulischer Abgleich.', solar: 'Kollektoren mit Solar-Keymark-Zertifikat, hydraulischer Abgleich.',
    'Dach / oberste Geschossdecke': 'U-Wert höchstens 0,14 W/(m²K), Dachflächenfenster Uw höchstens 1,0 W/(m²K).',
    'Außenwand / Fassade': 'U-Wert höchstens 0,20 W/(m²K) (Innendämmung und Fachwerk mit Sonderregeln).',
    'Fenster und Außentüren': 'Fenster Uw höchstens 0,95 W/(m²K), Haustüren Ud höchstens 1,3 W/(m²K). Lüftungskonzept nötig, wenn viele Fenster getauscht werden.',
    'Kellerdecke / Bodenplatte': 'U-Wert höchstens 0,25 W/(m²K).',
    'Lüftungsanlage': 'Wärmerückgewinnung und Effizienzwerte nach Förderrichtlinie, Planung nach DIN 1946-6.' };
  const LISTE = {
    'Heizung': ['raumweise Heizlastberechnung', 'hydraulischer Abgleich (Verfahren B)', 'Demontage und Entsorgung der alten Heizung und des Tanks', 'Elektroanschluss und Zählerschrank', 'Aufstellung: Fundament, Kernbohrungen, Leitungen nach außen', 'Speicher für Warmwasser und Puffer', 'Inbetriebnahme und Einweisung'],
    'Dach / oberste Geschossdecke': ['Gerüst und Absturzsicherung', 'Abbruch und Entsorgung', 'Dampfbremse bzw. luftdichte Ebene mit allen Anschlüssen', 'Dachrinnen und Blechanschlüsse', 'Anschlüsse an Kamin, Dachfenster und Giebel', 'Dämmstoff, Dicke und U-Wert genannt'],
    'Außenwand / Fassade': ['Gerüst', 'Untergrundvorbereitung', 'Fensterbänke und Laibungen', 'Sockeldämmung', 'Anschlüsse an Dach und Fenster', 'Dämmstoff, Dicke und U-Wert genannt'],
    'Fenster und Außentüren': ['Ausbau und Entsorgung der alten Fenster', 'Montage nach RAL (innen luftdicht, außen schlagregendicht)', 'Fensterbänke innen und außen', 'Laibungen beiputzen', 'Uw-Wert jedes Elements genannt', 'Rollläden und Insektenschutz, falls gewünscht'],
    'Kellerdecke / Bodenplatte': ['Vorbereitung des Untergrunds', 'Umgang mit Leitungen und Leuchten', 'Dämmstoff, Dicke und U-Wert genannt', 'Randbereiche und Kellertreppe'],
    'Lüftungsanlage': ['Lüftungskonzept nach DIN 1946-6', 'Kanäle, Durchbrüche und Verschließen', 'Elektroanschluss', 'Einregulierung und Protokoll', 'Filter und Wartung'],
    'Photovoltaik': ['Gerüst', 'Zählerschrank nach den Vorgaben des Netzbetreibers', 'Anmeldung beim Netzbetreiber', 'Unterkonstruktion passend zur Dacheindeckung', 'Überspannungsschutz', 'nutzbare Speicherkapazität genannt'] };

  const sysListe = () => SYS[val('kgew')] || [];
  const sys = () => sysListe().find(s => s[0] === val('ksys'));

  // Stichtage der Reform vom 21.07.2026: Klimageschwindigkeitsbonus und Kostengrenze der 1. Wohneinheit (wie kacheln.js)
  function stufe(d) {
    const t = d.toISOString().slice(0, 10);
    const s = [['2027-02-01', 16, 28000], ['2027-08-01', 12, 27250], ['2028-02-01', 8, 26500], ['2028-08-01', 4, 25750]];
    for (const [bis, kb, cap] of s) if (t < bis) return { kb, cap };
    const halbj = Math.floor((d.getFullYear() - 2028) * 2 + (d.getMonth() >= 7 ? 1 : 0));
    return { kb: 0, cap: Math.max(22000, 25750 - 750 * Math.max(0, halbj)) };
  }

  function foerderung(s, brutto) {
    const art = s[5], we = Math.max(1, Math.round(num(val('kwe')) || 1)), selbst = val('kselbst') === 'ja';
    if (art === 'pv') return { z: 0, text: 'Photovoltaik wird über die Gebäudeförderung (BEG) nicht bezuschusst. Ihr Vorteil: Für PV-Anlagen und Speicher auf Wohnhäusern gilt 0 % Mehrwertsteuer. Steht im Angebot Mehrwertsteuer, fragen Sie nach.', tips: [] };
    if (art === 'huelle') {
      const isfp = val('kisfp') === 'ja';
      const capH = (isfp ? 60000 : 30000) + Math.min(we - 1, 5) * (isfp ? 30000 : 15000), ohne = 30000 + Math.min(we - 1, 5) * 15000;
      const f = Math.min(brutto, capH), z = f * .15 + (isfp ? Math.max(0, f - ohne) * .05 : 0);
      const tips = ['Für Dämmung, Fenster und Lüftung ist ein Energieeffizienz-Experte Pflicht. Seine Baubegleitung wird zusätzlich mit 50 % bezuschusst.'];
      if (brutto > capH) tips.push(`Förderfähig sind höchstens ${eur(capH)} je Jahr. Größere Vorhaben lassen sich auf zwei Jahre verteilen.`);
      if (!isfp) tips.push('Mit einem Sanierungsfahrplan (iSFP) steigt die Förderung um 5 Prozentpunkte und die förderfähigen Kosten verdoppeln sich.');
      if (selbst) { const st = Math.min(Math.min(brutto, 200000) * .2, 40000); if (st > z) tips.push(`Als Alternative zur BAFA-Förderung: Über den Steuerbonus (§ 35c EStG) wären bis zu ${eur(st)} über drei Jahre möglich.`); }
      return { z, text: `15 %${isfp ? ' plus 5 % iSFP-Bonus' : ''} auf ${eur(f)} förderfähige Kosten (BAFA).`, tips };
    }
    // Heizung (KfW 458)
    const { kb, cap } = stufe(new Date());
    const capAll = cap + Math.min(we - 1, 5) * 15000 + Math.max(0, we - 6) * 8000, ff = Math.min(brutto, capAll);
    const klimaOk = selbst && art !== 'solar' && (['oel', 'strom'].includes(val('kalt')) || (['gas', 'bio'].includes(val('kalt')) && val('kalter') === 'alt'));
    const zve = +val('keink') || 0, eink = selbst ? ({ 30: 40, 40: 30, 50: 10 }[zve] || 0) : 0, deckel = selbst && zve === 30 ? 80 : 70;
    const satz = Math.min(deckel, 30 + (klimaOk ? kb : 0) + eink), eigen = selbst ? ff / we : 0, z = eigen * satz / 100 + (ff - eigen) * .3;
    const t = ['30 % Grundförderung']; if (klimaOk) t.push(kb + ' % Klimabonus'); if (eink) t.push(eink + ' % Einkommensbonus');
    const tips = [];
    if (brutto > capAll) tips.push(`Förderfähig sind höchstens ${eur(capAll)}. Den Rest kann die KfW mit einem Ergänzungskredit finanzieren.`);
    if (klimaOk && kb === 16) tips.push('Ab 1. Februar 2027 sinkt der Klimabonus auf 12 %. Rechtzeitig beantragen lohnt sich.');
    if (selbst && !zve) tips.push('Den Einkommensbonus (bis zu 40 %) habe ich ohne Angabe nicht eingerechnet.');
    if (art === 'wp') tips.push('Ab dem ersten Quartal 2027 sinkt die Grundförderung für Wärmepumpen, die nicht in der EU hergestellt werden, auf 15 %. Fragen Sie nach dem Herstellungsort.');
    tips.push('Der Antrag muss vor Beginn der Arbeiten gestellt sein, und der Vertrag braucht eine Förder-Bedingung.');
    return { z, text: `${t.join(' + ')}${satz < 30 + (klimaOk ? kb : 0) + eink ? `, gedeckelt auf ${deckel} %` : ''} auf ${eur(ff)} förderfähige Kosten (KfW).${we > 1 && selbst ? ' Boni nur für die selbst genutzte Wohnung.' : ''}`, tips };
  }

  // ---------- Angebot im Browser auslesen (nur Text-PDFs; Scans und Fotos: Handeingabe) ----------
  let pdfLaden = null;
  const ladePdf = () => pdfLaden || (pdfLaden = new Promise((ok, nein) => {
    if (window.pdfjsLib) return ok(window.pdfjsLib);
    const sc = document.createElement('script'); sc.src = C.pdfjs; sc.onerror = nein;
    sc.onload = () => { window.pdfjsLib.GlobalWorkerOptions.workerSrc = C.pdfworker; ok(window.pdfjsLib); }; document.head.appendChild(sc); }));
  async function pdfZeilen(f) {
    const lib = await ladePdf(), doc = await lib.getDocument({ data: new Uint8Array(await f.arrayBuffer()) }).promise, out = [];
    for (let p = 1; p <= Math.min(doc.numPages, 30); p++) {
      const c = await (await doc.getPage(p)).getTextContent(), rows = {};
      c.items.forEach(it => { const y = Math.round(it.transform[5]); (rows[y] = rows[y] || []).push([it.transform[4], it.str]); });
      Object.keys(rows).sort((a, b) => b - a).forEach(y => out.push(rows[y].sort((a, b) => a[0] - b[0]).map(x => x[1]).join(' ').replace(/\s+/g, ' ').trim()));
    }
    return out.filter(Boolean);
  }
  $('kdatei').addEventListener('change', async () => {
    const fs = [...$('kdatei').files], m = $('klesen'), pdf = fs.find(f => /pdf$/i.test(f.type) || /\.pdf$/i.test(f.name));
    m.hidden = !fs.length; if (!fs.length) return;
    $('kdatei').closest('.sea-upl').classList.remove('sea-err');
    if (!pdf || !window.sacLesen) { m.textContent = 'Fotos kann ich nicht automatisch auslesen. Bitte tragen Sie Gewerk, Größe und Preis unten ein.'; return; }
    m.textContent = 'Ich lese Ihr Angebot …';
    try {
      const r = window.sacLesen(await pdfZeilen(pdf)), gef = [];
      if (r.gewerk && !val('kgew')) { $('kgew').value = r.gewerk; sync(); gef.push(r.gewerk); }
      if (r.sys && val('kgew') === r.gewerk && !val('ksys')) { $('ksys').value = r.sys; sync(); const s = sys(); if (s) gef.push(s[1]); }
      if (r.gr && !val('kgr')) { $('kgr').value = de(r.gr, 2); gef.push(de(r.gr, 2) + ' ' + (sys() ? sys()[3].split(' ')[0] : '')); }
      if (r.preis && !val('kpreis')) { $('kpreis').value = de(r.preis, 2); $('kmwst').value = r.nullSteuer ? 'brutto' : r.mwst; gef.push(eur(r.preis) + (r.mwst === 'netto' ? ' netto' : '')); }
      sync();
      m.textContent = gef.length ? `Aus Ihrem Angebot ausgelesen: ${gef.join(', ')}. Bitte prüfen Sie die Werte und ergänzen Sie, was fehlt.` : 'Ich konnte keine Werte sicher auslesen. Bitte tragen Sie Gewerk, Größe und Preis unten ein.';
    } catch (e) { m.textContent = 'Das Auslesen hat nicht geklappt. Bitte tragen Sie Gewerk, Größe und Preis unten ein.'; }
  });

  // ---------- Angebot für die Preisdatenbank übertragen (nur mit Einwilligung) ----------
  function kcSenden(daten) {
    if (!C.kc_endpoint || val('hp')) return;
    const fd = new FormData(); fd.append('daten', JSON.stringify(daten));
    [...$('kdatei').files].slice(0, MAXJE).filter(f => f.size <= MAXDATEI).forEach((f, i) => fd.append('datei' + i, f, f.name));
    fetch(C.kc_endpoint, { method: 'POST', body: fd }).catch(() => {});
  }

  let kurzText = '';
  function kurzcheck() {
    const s = sys(), gr = num(val('kgr')), p = num(val('kpreis')), m = $('msg0'), f = [];
    if (!$('kdatei').files.length) f.push('kdatei');
    if (!val('kgew')) f.push('kgew'); else if (!s) f.push('ksys');
    if (s && !(gr > 0)) f.push('kgr'); if (s && !(p > 100)) f.push('kpreis');
    if (s && !/^\d{5}$/.test(val('kplz'))) f.push('kplz');
    if (s && s[5] !== 'pv' && !val('kselbst')) f.push('kselbst');
    if (!$('keinw').checked) f.push('keinw');
    if ([...$('kdatei').files].some(x => x.size > MAXDATEI)) { m.textContent = 'Eine Datei ist größer als 10 MB. Bitte verkleinern.'; return; }
    if (s && (s[5] === 'wp' || s[5] === 'bio') && !val('kalt')) f.push('kalt');
    if (!$('kalterw').hidden && !val('kalter')) f.push('kalter');
    if (!markiere(q('#sac section[data-step="0"]'), f)) { m.textContent = 'Bitte die rot markierten Angaben ergänzen.'; return; }
    m.textContent = '';
    const pv = s[5] === 'pv', netto = pv || val('kmwst') === 'netto' ? p : p / 1.19, brutto = pv ? p : (val('kmwst') === 'netto' ? p * 1.19 : p);
    const je = netto / gr, einh = s[3].split(' ')[0], r = s[2] && C.preise && C.preise.systeme ? C.preise.systeme[s[2]] : null;
    let h = `<h2>Ihr Ergebnis</h2>`;
    // 1. Preis
    if (r) {
      const weit = r.n < 3 ? .2 : .15, lo = r.min * (1 - weit), hi = r.max * (1 + weit);
      const [cls, urteil] = je < lo ? ['no', 'Auffällig günstig. Prüfen Sie, ob alle nötigen Leistungen enthalten sind, sonst kommen Nachträge.']
        : je > hi ? ['no', 'Über meinen Vergleichswerten. Nachfragen und ein zweites Angebot lohnen sich.']
        : je > r.median * 1.1 ? ['', 'Im üblichen Rahmen, eher im oberen Bereich.']
        : je < r.median * .9 ? ['', 'Im üblichen Rahmen, eher im unteren Bereich.'] : ['', 'Im üblichen Rahmen.'];
      const a = Math.min(lo, je) * .9, b = Math.max(hi, je) * 1.05, pos = x => Math.max(0, Math.min(100, (x - a) / (b - a) * 100));
      h += `<div class="sea-urteil ${cls}"><b>Preis: ${urteil}</b><br>Ihr Angebot: <b>${eur(je)} je ${esc(einh)}</b> netto (${eur(netto)} netto für ${de(gr, 1)} ${esc(einh)}).<br>
        Vergleichswerte aus geprüften Angeboten meiner Kundinnen und Kunden: ${eur(Math.round(lo / 10) * 10)} bis ${eur(Math.round(hi / 10) * 10)} je ${esc(einh)} netto.
        <div class="sac-bar" aria-hidden="true"><span class="sac-band" style="left:${pos(lo)}%;width:${pos(hi) - pos(lo)}%"></span><span class="sac-mark" style="left:${pos(je)}%"></span></div>
        <small>Richtwert. Preise schwanken mit Region, Zugänglichkeit und Ausstattung${s[0] === 'wp' ? ', und kleine Wärmepumpen kosten je kW mehr als große' : ''}.</small></div>`;
      kurzText = `${s[1]}: ${de(je)} €/${einh} netto, Spanne ${de(lo)}–${de(hi)} (n=${r.n}) → ${urteil}`;
    } else {
      h += `<div class="sea-urteil"><b>Preis:</b> Ihr Angebot entspricht ${eur(je)} je ${esc(einh)} netto. Für „${esc(s[1])}“ habe ich noch keine belastbaren Vergleichswerte. In der persönlichen Prüfung bewerte ich die einzelnen Positionen.</div>`;
      kurzText = `${s[1]}: ${de(je)} €/${einh} netto, keine Vergleichswerte`;
    }
    // 2. Förderung mit Knopf zum Förderrechner
    const fo = foerderung(s, brutto), mass = { Heizung: 'heizung', 'Fenster und Außentüren': 'fenster' }[val('kgew')] || 'daemmung';
    const fr = `${C.foerderrechner}${C.foerderrechner.includes('?') ? '&' : '?'}massnahme=${mass}&kosten=${Math.round(brutto)}`;
    h += fo.z > 0 ? `<div class="sea-box"><p><b>Förderung: etwa ${eur(fo.z)} Zuschuss</b><br>${esc(fo.text)} Ihr Eigenanteil läge bei etwa ${eur(brutto - fo.z)}.</p>
        <p><a class="sac-knopf" href="${esc(fr)}" target="_blank" rel="noopener">Förderung genau berechnen im Förderrechner</a></p></div>`
      : `<div class="sea-box"><p><b>Förderung</b><br>${esc(fo.text)}</p></div>`;
    if (fo.z > 0) kurzText += ` | Förderung ca. ${de(fo.z)} €`;
    // 3. Persönliche Prüfung direkt im Blick
    h += `<div class="sac-cta"><h3>Genauer prüfen lassen</h3><p class="sea-hint">Der Kurzcheck vergleicht nur den Gesamtpreis. Persönlich prüfe ich Ihr Angebot Position für Position: Förderfähigkeit, Vollständigkeit und Preise, mit schriftlichem Prüfbericht und konkreten Fragen an den Betrieb, in der Regel innerhalb von 3 Werktagen.</p>
      <div class="sea-tarife"><button type="button" class="sea-tarif sac-go" data-anz="1"><span class="sea-t-kopf">Angebotsbewertung</span><span class="sea-t-zeit">dieses Angebot</span><strong>${esc(C.preis)}</strong></button>
      <button type="button" class="sea-tarif sea-tarif-x sac-go" data-anz="3"><span class="sea-badge">Mit Gegenüberstellung</span><span class="sea-t-kopf">Angebotsvergleich</span><span class="sea-t-zeit">bis zu drei Angebote</span><strong>${esc(C.preis_vergleich)}</strong></button></div></div>`;
    // 4. Details
    h += `<h3>Weitere Hinweise zu Ihrem Angebot</h3>`;
    if (fo.tips.length) h += `<div class="sea-box"><p><b>Zur Förderung</b></p><ul>${fo.tips.map(t => `<li>${esc(t)}</li>`).join('')}</ul></div>`;
    const tma = TMA[s[5]] || TMA[val('kgew')];
    if (tma) h += `<div class="sea-box"><p><b>Technische Mindestanforderungen für die Förderung</b><br>${esc(tma)} Ob das Angebot sie erfüllt, steht oft nur im Kleingedruckten oder gar nicht drin.</p></div>`;
    h += `<div class="sea-box"><p><b>Darauf sollten Sie im Angebot achten</b></p><ul>${(LISTE[val('kgew')] || []).map(t => `<li>${esc(t)}</li>`).join('')}</ul></div>`;
    h += `<p class="sea-hint">Alle Angaben ohne Gewähr. Der Kurzcheck ersetzt keine Prüfung des Angebots und keine Förderzusage.</p>`;
    $('kerg').innerHTML = h; $('kerg').hidden = false; $('kdirekt').hidden = true;
    kcSenden({ gewerk: val('kgew'), system: s[1], groesse: gr, einheit: s[3], preis: p, mwst: pv ? '0 %' : val('kmwst'), netto: Math.round(netto * 100) / 100, plz: val('kplz'),
      selbst: val('kselbst'), wohnungen: val('kwe'), ergebnis: kurzText, einwilligung: $('keinw').checked, website: val('hp') });
    const t = $('kerg').getBoundingClientRect().top + scrollY - 80; scrollTo({ top: t, behavior: 'smooth' });
  }
  $('krech').addEventListener('click', kurzcheck);

  // Übergabe vom Kurzcheck in die persönliche Prüfung
  function zurPruefung(anz) {
    const s = sys();
    if (val('kgew')) $('gewerk').value = val('kgew');
    if (s && s[6]) $('neu').value = s[6];
    if (val('kselbst')) $('selbst').value = val('kselbst');
    if (num(val('kwe')) >= 1 && !val('we')) $('we').value = Math.round(num(val('kwe')));
    const alt = { oel: 'oel', gas: 'gas', strom: 'strom' }[val('kalt')]; if (alt) $('alt').value = alt;
    if (/^\d{5}$/.test(val('kplz')) && !val('plz')) $('plz').value = val('kplz');
    if ($('kdatei').files.length && !$('a1').files.length) { const dt = new DataTransfer(); [...$('kdatei').files].forEach(f => dt.items.add(f)); $('a1').files = dt.files; $('a1').dispatchEvent(new Event('change')); }
    tarif(anz > 1 ? 'vergleich' : 'einzel'); sync(); show(1);
  }
  document.addEventListener('click', ev => { const b = ev.target.closest('#sac .sac-go'); if (b) zurPruefung(+b.dataset.anz); });
  $('kskip').addEventListener('click', ev => { ev.preventDefault(); zurPruefung(1); });

  // =====================================================================
  // Kacheln und Sichtbarkeit
  // =====================================================================
  function tarif(t) { q(`input[name=sac-tarif][value=${t}]`).checked = true; $('anz').value = t === 'vergleich' ? '3' : '1'; }
  function sync() {
    document.querySelectorAll('#sac .sea-chips').forEach(g => g.querySelectorAll('button').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.v === document.getElementById(g.dataset.for).value))));
    // Kurzcheck
    const nwg = val('kart') === 'nwg'; $('knwg').hidden = !nwg; $('kwg').hidden = nwg; $('knav').hidden = nwg; $('kdirekt').hidden = nwg || !$('kerg').hidden;
    const sl = sysListe(); $('ksysw').hidden = !sl.length;
    const key = sl.map(x => x[0]).join();
    if ($('ksysc').dataset.k !== key) {
      $('ksysc').dataset.k = key; $('ksysc').innerHTML = sl.map(x => `<button type="button" data-v="${x[0]}">${esc(x[1])}</button>`).join('');
      if (!sl.some(x => x[0] === val('ksys'))) $('ksys').value = sl.length === 1 ? sl[0][0] : '';
      return sync();
    }
    const s = sys(); $('kzahl').hidden = !s; $('kmwstw').hidden = !s || s[5] === 'pv'; $('kfoe').hidden = !s || s[5] === 'pv';
    if (s) { $('kgrl').textContent = 'Größe in ' + s[3]; $('kgr').placeholder = 'z. B. ' + s[4]; }
    $('kaltw').hidden = !s || !['wp', 'bio'].includes(s[5]); $('kalterw').hidden = $('kaltw').hidden || !['gas', 'bio'].includes(val('kalt')); $('keinkw').hidden = !s || !['wp', 'bio', 'solar'].includes(s[5]) || val('kselbst') !== 'ja';
    $('kisfpw').hidden = !s || s[5] !== 'huelle';
    // Auftrag
    const e = ETR[$('alt').value]; $('einh').textContent = e ? `in ${e[1]}` : '(laut Abrechnung)';
    $('unterhint').hidden = !/^ja/.test($('unter').value);
    const vgl = (q('input[name=sac-tarif]:checked') || {}).value === 'vergleich'; $('anz').value = vgl ? '3' : '1';
    $('u2').hidden = !vgl; $('u3').hidden = !vgl; if (!vgl) $('nur1').hidden = true;
    const hz = istHz(), gw = val('gewerk');
    $('hz').hidden = !hz; $('buchbox').hidden = !hz; $('huelle').hidden = !gw || hz || gw === 'Photovoltaik';
    $('gw').textContent = gw ? '(' + gw + ')' : '';
    $('paket').textContent = vgl ? 'Angebotsvergleich' : 'Angebotsbewertung'; $('betrag').textContent = vgl ? C.preis_vergleich : C.preis; $('vgl-li').hidden = !vgl;
  }
  document.addEventListener('click', ev => {
    const b = ev.target.closest('#sac .sea-chips button'); if (!b) return;
    document.getElementById(b.parentElement.dataset.for).value = b.dataset.v; sync();
    b.closest('.sea-frage').classList.remove('sea-err');
  });
  document.querySelectorAll('#sac input[name=sac-tarif]').forEach(r => r.addEventListener('change', sync));

  // ---------- Dateien anzeigen und einzeln entfernen ----------
  const kb = n => n > 1e6 ? de(n / 1e6, 1) + ' MB' : Math.max(1, Math.round(n / 1e3)) + ' KB';
  document.querySelectorAll('#sac input[type=file]').forEach(inp => {
    const ul = document.createElement('ul'); ul.className = 'sea-files'; ul.hidden = true;
    inp.closest('.sea-upl').insertAdjacentElement('afterend', ul);
    const zeigen = () => { const fs = [...inp.files]; ul.hidden = !fs.length;
      ul.innerHTML = fs.map((f, i) => `<li><span>${esc(f.name)} <small>${kb(f.size)}${f.size > MAXDATEI ? ' – zu groß' : ''}</small></span><button type="button" class="sea-sec" data-weg="${i}" aria-label="${esc(f.name)} entfernen">✕ Entfernen</button></li>`).join('');
      if (fs.length && inp.id !== 'sac-a1') $('nur1').hidden = true; };
    inp.addEventListener('change', zeigen);
    ul.addEventListener('click', ev => { const b = ev.target.closest('[data-weg]'); if (!b) return;
      const dt = new DataTransfer(); [...inp.files].forEach((f, i) => { if (i !== +b.dataset.weg) dt.items.add(f); });
      inp.files = dt.files; inp.dispatchEvent(new Event('change', { bubbles: true })); });
  });
  const dateien = () => { const n = +$('anz').value || 1; return ['a1', 'a2', 'a3'].slice(0, n).flatMap(k => [...$(k).files].slice(0, MAXJE).map(f => [k, f])); };

  // ---------- Pflichtfelder ----------
  function markiere(sec, ids) {
    sec.querySelectorAll('.sea-err').forEach(x => x.classList.remove('sea-err'));
    const els = ids.map(i => { const x = $(i); if (!x) return null; if (x.type === 'checkbox') return x.closest('label'); if (x.type === 'hidden') return x.closest('.sea-frage'); if (x.type === 'file') return x.closest('.sea-upl'); return x; }).filter(Boolean);
    els.forEach(x => x.classList.add('sea-err'));
    if (els[0]) { const t = els[0].getBoundingClientRect().top + scrollY - 120; if (t < scrollY) scrollTo({ top: t }); }
    return !els.length;
  }
  function check(n) {
    const sec = q(`#sac section[data-step="${n}"]`), m = $('msg' + n), f = [];
    if (n === 1) {
      if (!val('gewerk')) f.push('gewerk');
      if (istHz()) { if (!val('neu')) f.push('neu'); if (!val('alt')) f.push('alt'); if (!val('hfl')) f.push('hfl'); }
      const bj = +val('bj'); if (!(bj >= 1800 && bj <= 2026)) f.push('bj');
      if (!(num(val('wfl')) >= 20)) f.push('wfl'); if (!(+val('we') >= 1)) f.push('we');
      if (!/^\d{5}$/.test(val('plz'))) f.push('plz');
      if (!val('selbst')) f.push('selbst'); if (!val('unter')) f.push('unter');
    }
    if (n === 2) {
      if (!C.preview && !$('a1').files.length) f.push('a1');
      const fs = dateien();
      if (fs.some(([, x]) => x.size > MAXDATEI)) { m.textContent = 'Eine Datei ist größer als 10 MB. Bitte verkleinern oder als Foto mit geringerer Auflösung hochladen.'; return false; }
      if (fs.reduce((s, [, x]) => s + x.size, 0) > MAXSUMME) { m.textContent = 'Zusammen sind die Dateien zu groß (max. 60 MB). Bitte Fotos verkleinern oder PDFs nutzen.'; return false; }
      // Vergleich gewählt, aber nur ein Angebot hochgeladen: nachfragen
      if (!f.length && $('anz').value === '3' && !$('a2').files.length && !$('a3').files.length && !C.preview) {
        $('nur1').hidden = false; m.textContent = ''; $('nur1').scrollIntoView({ block: 'center' }); return false; }
    }
    if (n === 3) {
      if (!val('vorname')) f.push('vorname'); if (!val('nachname')) f.push('nachname');
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(val('email'))) f.push('email');
      if (!$('ds').checked) f.push('ds'); if (!$('widerruf').checked) f.push('widerruf');
    }
    const ok = markiere(sec, f);
    m.textContent = ok ? '' : 'Bitte die rot markierten Angaben ergänzen.';
    return ok;
  }
  $('nur1-ok').addEventListener('click', () => { tarif('einzel'); sync(); show(3); });
  $('nur1-mehr').addEventListener('click', () => { $('nur1').hidden = true; $('a2').click(); });

  // ---------- Vorprüfung für Stephan (nur grobe Richtwerte aus dem Verbrauch) ----------
  function vorpruefung() {
    const e = ETR[val('alt')], v = num(val('verbr')), a = num(val('wfl'));
    if (!istHz()) return '–';
    if (!e || !(v > 0) || !(a > 0)) return 'Kein Verbrauch angegeben, Heizlast nicht abschätzbar.';
    const kwh = v * e[2] * e[3], ww = 12.5 * a, hl = Math.max(3, (kwh - ww) / 2000);
    return `Wärmebedarf ca. ${de(kwh)} kWh/a (${de(kwh / a)} kWh/m²a), davon Warmwasser ca. ${de(ww)} kWh. Heizlast grob ${de(hl, 1)} kW (Verbrauch / 2000 h, ohne Gewähr).`;
  }
  function daten() {
    const e = ETR[val('alt')] || ['', ''], hz = istHz() ? { 'Angeboten': val('neu'), 'Heizung heute': e[0], 'Baujahr alte Heizung': val('bjhz') || 'k. A.',
      'Verbrauch letztes Jahr': val('verbr') ? `${val('verbr')} ${e[1]}` : 'k. A.', 'Heizflächen': val('hfl') } : {};
    const vgl = $('anz').value === '3';
    return {
      haus: { 'Gewerk': val('gewerk'), ...hz, 'Baujahr Haus': val('bj'), 'Wohnfläche': val('wfl') + ' m²', 'Wohnungen': val('we'), 'Selbst bewohnt': val('selbst'),
        'Schon unterschrieben': { nein: 'nein', ja: 'ja, mit Förder-Vorbehalt', 'ja-ohne': 'ja, ohne Vorbehalt / unklar' }[val('unter')] || '', 'PLZ': val('plz'),
        'Angebote hochgeladen': String(['a1', 'a2', 'a3'].slice(0, vgl ? 3 : 1).filter(k => $(k).files.length).length) },
      kontakt: { vorname: val('vorname'), nachname: val('nachname'), email: val('email'), tel: val('tel') },
      frage: val('frage'), vorpruefung: vorpruefung(), kurzcheck: kurzText, tarif: vgl ? 'vergleich' : 'einzel', website: val('hp')
    };
  }
  function uebersicht() {
    const d = daten(), n = dateien();
    $('sum').innerHTML = [['Haus', `${d.haus['Wohnfläche']}, Baujahr ${d.haus['Baujahr Haus']}, ${d.haus['Wohnungen']} Wohnung(en), PLZ ${d.haus.PLZ}`], ['Gewerk', d.haus.Angeboten ? `${d.haus.Gewerk}: ${d.haus['Heizung heute']} → ${d.haus.Angeboten}` : d.haus.Gewerk],
      ['Angebote', `${d.haus['Angebote hochgeladen']} Angebot(e), ${n.length} Datei(en)`], ['Kontakt', `${d.kontakt.vorname} ${d.kontakt.nachname}, ${d.kontakt.email}`]]
      .map(([a, b]) => `<dt>${a}</dt><dd>${esc(b)}</dd>`).join('');
    if (C.preview) $('mail').value = `Paket: ${d.tarif === 'vergleich' ? 'Angebotsvergleich ' + C.preis_vergleich : 'Angebotsbewertung ' + C.preis}\n` + Object.entries(d.haus).map(([k, v]) => `${k}: ${v}`).join('\n') + `\n\nKurzcheck: ${d.kurzcheck || '–'}\nVorprüfung: ${d.vorpruefung}\nFrage: ${d.frage || '–'}\nDateien: ${n.map(([k, f]) => k + ' ' + f.name).join(', ')}`;
  }

  $('pay').addEventListener('click', async () => {
    const m = $('msg4'); m.className = 'sea-msg';
    if (!C.endpoint) { m.className = 'sea-msg gut'; m.textContent = 'Vorschau: Hier geht es im Live-Betrieb zur Stripe-Zahlung. Der Auftrag geht mit allen Dateien an info@s-energies.de, sobald bezahlt ist.'; return; }
    const d = daten(), fd = new FormData();
    fd.append('daten', JSON.stringify(d));
    dateien().forEach(([k, f], i) => fd.append('datei' + i, f, k + '__' + f.name));
    $('pay').disabled = true; m.className = 'sea-msg gut'; m.textContent = 'Unterlagen werden übertragen …';
    try {
      const r = await fetch(C.endpoint, { method: 'POST', body: fd }); const j = await r.json().catch(() => ({}));
      if (!r.ok || !j.ok) throw new Error(j.fehler || '');
      const z = d.tarif === 'vergleich' ? C.zahlungslink_vergleich : C.zahlungslink;
      if (z) { m.textContent = 'Weiter zur Zahlung …'; location.href = z + (z.includes('?') ? '&' : '?') + 'client_reference_id=' + encodeURIComponent(j.id) + '&prefilled_email=' + encodeURIComponent(d.kontakt.email); return; }
      $('fertig').textContent = `Ihre Auftragsnummer ist ${j.id}. Ich melde mich per E-Mail mit dem Zahlungslink.`; show(5);
    } catch (e) { m.className = 'sea-msg'; m.textContent = (e.message || 'Die Übertragung hat nicht geklappt.') + ' Bitte versuchen Sie es noch einmal oder schreiben Sie an info@s-energies.de.'; $('pay').disabled = false; }
  });

  // ---------- Navigation ----------
  let step = 0;
  function show(n) {
    step = n;
    document.querySelectorAll('#sac [data-step]').forEach(s => s.hidden = +s.dataset.step !== n);
    $('steps').hidden = n < 1 || n > 4;
    document.querySelectorAll('#sac-steps li').forEach((li, i) => li.classList.toggle('on', i < n));
    if (n === 4) uebersicht();
    const top = $('f').getBoundingClientRect().top + scrollY - 90; if (scrollY > top) scrollTo({ top });
  }
  $('f').addEventListener('click', ev => {
    const t = ev.target;
    if (t.matches('[data-back]')) show(step - 1);
    if (t.matches('[data-next]') && check(step)) show(step + 1);
  });
  $('f').addEventListener('input', ev => { const x = ev.target; if (x.classList.contains('sea-err') && x.value) x.classList.remove('sea-err'); const l = x.closest('.sea-err'); if (l && (x.checked || x.files && x.files.length)) l.classList.remove('sea-err'); });
  $('f').addEventListener('submit', e => e.preventDefault());

  // ---------- Rückkehr von Stripe: Dankeseite und sofortige Zahlungsprüfung ----------
  { const u = new URLSearchParams(location.search);
    if (u.has('danke')) {
      document.querySelectorAll('#sac [data-step]').forEach(s => s.hidden = s.dataset.step !== '6');
      $('steps').hidden = false; document.querySelectorAll('#sac-steps li').forEach(li => li.classList.add('on'));
      const sid = u.get('session_id') || '';
      if (C.zahlung && /^cs_(live|test)_[A-Za-z0-9]+$/.test(sid)) fetch(C.zahlung + (C.zahlung.includes('?') ? '&' : '?') + 'sid=' + encodeURIComponent(sid)).catch(() => {});
    } }
  sync();

  if (C.preview) {
    const b = document.createElement('button'); b.type = 'button'; b.className = 'sea-sec'; b.textContent = 'Testdaten einfügen';
    b.style.cssText = 'margin-left:10px;padding:2px 10px;font-size:12px;color:#f2f1e5;border-color:rgba(242,241,229,.4)';
    $('tag').after(b);
    b.addEventListener('click', () => {
      Object.entries({ kgew: 'Heizung', kselbst: 'ja', kwe: 1, kalt: 'oel', bj: 1978, wfl: '145', we: 1, bjhz: 1998, verbr: '2400', plz: '91301', hfl: 'Heizkörper', unter: 'nein', vorname: 'Anna', nachname: 'Muster', email: 'anna.muster@example.de', tel: '09191 123456' }).forEach(([k, x]) => $(k).value = x);
      sync(); $('ksys').value = 'wp'; $('kgr').value = '9'; $('kpreis').value = '38.900';
      ['ds', 'widerruf'].forEach(k => $(k).checked = true); sync();
    });
  }
})();
